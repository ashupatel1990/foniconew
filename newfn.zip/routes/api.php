<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\MobileAppController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    Route::post('/login', [AuthController::class, 'login']);

    Route::middleware('auth.api')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/me', [AuthController::class, 'me']);

        Route::get('/dashboard', [MobileAppController::class, 'dashboard']);
        Route::get('/payment-methods', [MobileAppController::class, 'paymentMethods']);

        Route::get('/parties', [MobileAppController::class, 'parties']);
        Route::get('/parties/{id}', [MobileAppController::class, 'partyDetail']);

        Route::get('/transactions', [MobileAppController::class, 'transactions']);
        Route::post('/transactions', [MobileAppController::class, 'storeTransaction']);
        Route::delete('/transactions/{id}', [MobileAppController::class, 'deleteTransaction']);

        Route::get('/invoices', [MobileAppController::class, 'invoices']);
        Route::get('/invoices/{id}', [MobileAppController::class, 'invoiceDetail']);

        Route::get('/purchases', [MobileAppController::class, 'purchases']);
        Route::get('/expenses', [MobileAppController::class, 'expenses']);
    });
});
