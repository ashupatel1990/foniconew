<?php

namespace App\Services\Ledger;

use App\Models\LedgerEntry;
use App\Models\PartyLedger;
use App\Models\CashBankLedger;

class BalanceCalculationService
{
    /**
     * Calculate daily balance
     */
    public function calculateDailyBalance(string $date)
    {
        $cacheKey = "ledger.balance.{$date}";
        
        return \Cache::remember($cacheKey, 300, function () use ($date) {
            $totalDebit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                     ->sum('debit_amount');

            $totalCredit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                      ->sum('credit_amount');

            return [
                'date' => $date,
                'opening_balance' => 0,
                'total_in' => $totalCredit,
                'total_out' => $totalDebit,
                'closing_balance' => $totalCredit - $totalDebit,
            ];
        });
    }

    /**
     * Calculate party balance
     */
    public function calculatePartyBalance(int $partyId)
    {
        $cacheKey = "party.balance.{$partyId}";

        return \Cache::remember($cacheKey, 60, function () use ($partyId) {
            $partyLedger = PartyLedger::where('party_id', $partyId)->first();

            if (!$partyLedger) {
                return [
                    'party_id' => $partyId,
                    'opening_balance' => 0,
                    'total_credit' => 0,
                    'total_debit' => 0,
                    'closing_balance' => 0,
                ];
            }

            return [
                'party_id' => $partyId,
                'opening_balance' => $partyLedger->opening_balance,
                'total_credit' => $partyLedger->total_credit,
                'total_debit' => $partyLedger->total_debit,
                'closing_balance' => $partyLedger->closing_balance,
            ];
        });
    }

    /**
     * Calculate account balance
     */
    public function calculateAccountBalance(int $accountId)
    {
        $cacheKey = "account.balance.{$accountId}";

        return \Cache::remember($cacheKey, 300, function () use ($accountId) {
            $account = CashBankLedger::find($accountId);

            if (!$account) {
                return [
                    'account_id' => $accountId,
                    'balance' => 0,
                    'type' => null,
                ];
            }

            return [
                'account_id' => $accountId,
                'balance' => $account->current_balance,
                'type' => $account->account_type,
                'name' => $account->account_name,
            ];
        });
    }

    /**
     * Reconcile all balances
     */
    public function reconcileAllBalances()
    {
        $parties = \App\Models\Party::all();

        foreach ($parties as $party) {
            $totalCredit = LedgerEntry::where('party_id', $party->id)
                                      ->sum('credit_amount');
            
            $totalDebit = LedgerEntry::where('party_id', $party->id)
                                     ->sum('debit_amount');

            PartyLedger::updateOrCreate(
                ['party_id' => $party->id],
                [
                    'total_credit' => $totalCredit,
                    'total_debit' => $totalDebit,
                    'closing_balance' => $totalCredit - $totalDebit,
                ]
            );
        }

        return true;
    }

    /**
     * Get balance on specific date
     */
    public function getBalanceOnDate(string $date)
    {
        return $this->calculateDailyBalance($date);
    }

    /**
     * Get running balance for party
     */
    public function getPartyRunningBalance(int $partyId, string $from, string $to)
    {
        $entries = LedgerEntry::where('party_id', $partyId)
                              ->betweenDates($from, $to)
                              ->orderBy('entry_date')
                              ->get();

        $balance = 0;
        $result = [];

        foreach ($entries as $entry) {
            $balance += $entry->credit_amount - $entry->debit_amount;
            $result[] = [
                'date' => $entry->entry_date,
                'type' => $entry->entry_type,
                'credit' => $entry->credit_amount,
                'debit' => $entry->debit_amount,
                'running_balance' => $balance,
            ];
        }

        return $result;
    }

    /**
     * Validate balance consistency
     */
    public function validateBalanceConsistency(): array
    {
        $issues = [];

        // Check all parties have valid balances
        $parties = \App\Models\Party::all();
        foreach ($parties as $party) {
            $ledgerBalance = LedgerEntry::where('party_id', $party->id)
                                        ->sum(\DB::raw('credit_amount - debit_amount'));

            $partyLedger = PartyLedger::where('party_id', $party->id)->first();

            if ($partyLedger && abs($ledgerBalance - $partyLedger->closing_balance) > 0.01) {
                $issues[] = "Party {$party->id} balance mismatch";
            }
        }

        return $issues;
    }
}
