<?php

namespace App\Services\Ledger;

use App\Models\LedgerEntry;
use App\Models\PartyLedger;
use Illuminate\Support\Facades\DB;

class LedgerService
{
    /**
     * Create a new ledger entry
     */
    public function createEntry(array $data): LedgerEntry
    {
        DB::beginTransaction();
        try {
            // Validate: only one of debit or credit
            if ((($data['debit_amount'] ?? 0) > 0) && 
                (($data['credit_amount'] ?? 0) > 0)) {
                throw new \Exception('Cannot have both debit and credit amounts');
            }

            if ((($data['debit_amount'] ?? 0) <= 0) && 
                (($data['credit_amount'] ?? 0) <= 0)) {
                throw new \Exception('Either debit or credit amount is required');
            }

            $entry = LedgerEntry::create($data);

            // Update party balance
            $this->updatePartyBalance($entry->party_id);

            // Invalidate cache
            \Cache::forget("ledger.balance.{$entry->entry_date}");
            \Cache::forget("party.balance.{$entry->party_id}");

            DB::commit();
            return $entry;
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Update an existing ledger entry
     */
    public function updateEntry(int $id, array $data): LedgerEntry
    {
        DB::beginTransaction();
        try {
            $entry = LedgerEntry::findOrFail($id);

            // Validate
            if ((($data['debit_amount'] ?? 0) > 0) && 
                (($data['credit_amount'] ?? 0) > 0)) {
                throw new \Exception('Cannot have both debit and credit amounts');
            }

            $oldDate = $entry->entry_date;
            $entry->update($data);

            // Recalculate balances for both old and new dates if date changed
            $this->updatePartyBalance($entry->party_id);

            if ($oldDate !== $entry->entry_date) {
                \Cache::forget("ledger.balance.{$oldDate}");
            }

            \Cache::forget("ledger.balance.{$entry->entry_date}");
            \Cache::forget("party.balance.{$entry->party_id}");

            DB::commit();
            return $entry;
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Delete a ledger entry
     */
    public function deleteEntry(int $id): void
    {
        DB::beginTransaction();
        try {
            $entry = LedgerEntry::findOrFail($id);

            $partyId = $entry->party_id;
            $entryDate = $entry->entry_date;

            $entry->delete();

            // Recalculate balances
            $this->updatePartyBalance($partyId);

            // Invalidate cache
            \Cache::forget("ledger.balance.{$entryDate}");
            \Cache::forget("party.balance.{$partyId}");

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            throw $e;
        }
    }

    /**
     * Get filtered ledger entries
     */
    public function getFilteredEntries(array $filters)
    {
        $query = LedgerEntry::query();

        if (!empty($filters['date_from'])) {
            $query->whereDate('entry_date', '>=', $filters['date_from']);
        }

        if (!empty($filters['date_to'])) {
            $query->whereDate('entry_date', '<=', $filters['date_to']);
        }

        if (!empty($filters['party_id'])) {
            $query->where('party_id', $filters['party_id']);
        }

        if (!empty($filters['entry_type'])) {
            $query->where('entry_type', $filters['entry_type']);
        }

        if (!empty($filters['payment_method_id'])) {
            $query->where('payment_method_id', $filters['payment_method_id']);
        }

        return $query->with(['party', 'createdBy', 'paymentMethod'])
                     ->orderBy('entry_date', 'desc')
                     ->orderBy('created_at', 'desc')
                     ->get();
    }

    /**
     * Update party balance (recalculate)
     */
    public function updatePartyBalance(int $partyId): void
    {
        $totalCredit = LedgerEntry::where('party_id', $partyId)
                                  ->where('credit_amount', '>', 0)
                                  ->sum('credit_amount');
        
        $totalDebit = LedgerEntry::where('party_id', $partyId)
                                 ->where('debit_amount', '>', 0)
                                 ->sum('debit_amount');

        PartyLedger::updateOrCreate(
            ['party_id' => $partyId],
            [
                'total_credit' => $totalCredit,
                'total_debit' => $totalDebit,
                'closing_balance' => $totalCredit - $totalDebit,
                'last_transaction_date' => now()->toDateString(),
            ]
        );

        \Cache::forget("party.balance.{$partyId}");
    }

    /**
     * Validate balance consistency
     */
    public function validateBalance(string $date = null): bool
    {
        if (!$date) {
            $date = now()->toDateString();
        }

        $totalDebit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                 ->where('debit_amount', '>', 0)
                                 ->sum('debit_amount');

        $totalCredit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                  ->where('credit_amount', '>', 0)
                                  ->sum('credit_amount');

        return true; // Balance validation can be extended
    }

    /**
     * Get daily balance
     */
    public function getDailyBalance(string $date)
    {
        $totalDebit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                 ->where('debit_amount', '>', 0)
                                 ->sum('debit_amount');

        $totalCredit = LedgerEntry::whereDate('entry_date', '<=', $date)
                                  ->where('credit_amount', '>', 0)
                                  ->sum('credit_amount');

        return [
            'date' => $date,
            'total_debit' => $totalDebit,
            'total_credit' => $totalCredit,
            'balance' => $totalCredit - $totalDebit,
        ];
    }

    /**
     * Get entry count for date range
     */
    public function getEntryCount(string $from, string $to): int
    {
        return LedgerEntry::betweenDates($from, $to)->count();
    }

    /**
     * Get total in and out for date range
     */
    public function getTotals(string $from, string $to)
    {
        $entries = LedgerEntry::betweenDates($from, $to)->get();

        return [
            'total_in' => $entries->sum('credit_amount'),
            'total_out' => $entries->sum('debit_amount'),
            'count' => $entries->count(),
            'balance' => $entries->sum('credit_amount') - $entries->sum('debit_amount'),
        ];
    }
}
