<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Transaction;

class Party extends Model
{
    use HasFactory;

    protected $guarded = [];

    // === RELATIONSHIPS ===
    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }

    public function ledgerEntries()
    {
        return $this->hasMany(LedgerEntry::class);
    }

    public function ledger()
    {
        return $this->hasOne(PartyLedger::class);
    }

    public function recurringTransactions()
    {
        return $this->hasMany(RecurringTransaction::class);
    }

    // === ACCESSORS & MUTATORS ===
    public function getNameAttribute()
    {
        return $this->attributes['name'] ?? $this->attributes['party_name'] ?? null;
    }

    public function getBalanceAttribute()
    {
        return ($this->credit_total ?? 0) - ($this->debit_total ?? 0);
    }

    public function getLedgerBalanceAttribute()
    {
        return ($this->ledger?->total_credit ?? 0) - ($this->ledger?->total_debit ?? 0);
    }

    // === METHODS ===
    public function getTotalCredit()
    {
        return $this->ledgerEntries()->sum('credit_amount');
    }

    public function getTotalDebit()
    {
        return $this->ledgerEntries()->sum('debit_amount');
    }

    public function getCurrentBalance()
    {
        return $this->getTotalCredit() - $this->getTotalDebit();
    }

    public function getStatement($from, $to)
    {
        return $this->ledgerEntries()
                    ->betweenDates($from, $to)
                    ->orderBy('entry_date')
                    ->get();
    }
}
