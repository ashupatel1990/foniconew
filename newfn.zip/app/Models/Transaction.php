<?php
namespace App\Models;

use Carbon\Carbon;
use App\Models\{Party, DayOpeningBalance, Invoice, Purchase};
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Transaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'party_id',
        'payment_date',
        'transaction_type',
        'payment_method',
        'amount',
        'note',
        'opening_balance',
        'created_by',
    ];

    protected static function boot()
    {
        parent::boot();
    }

    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_method');
    }

    public function party()
    {
        return $this->belongsTo(Party::class);
    }

    /**
     * Retrieve transactions based on provided filters.
     *
     * @param array $columns Fields to retrieve
     * @param array $filters Filters to apply to the query
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getTransactions(array $columns = [], array $filters = [])
    {
        $query = $this->with('paymentMethod:id,method_name')
            ->select($columns ?: '*')
            ->orderBy('created_at', 'desc');

        // Apply date filters
        if (! empty($filters['date_from'])) {
            $query->where('payment_date', '>=', $filters['date_from']);
        }
        if (! empty($filters['date_to'])) {
            $query->where('payment_date', '<=', $filters['date_to']);
        }

        // Apply transaction type filter
        if (! empty($filters['transaction_type'])) {
            $query->where('transaction_type', $filters['transaction_type']);
        }

        // Apply payment method filter
        if (! empty($filters['payment_method'])) {
            $query->where('payment_method', $filters['payment_method']);
        }

        return $query->get();
    }

    /**
     * Get the opening balance for a given date.
     *
     * If no date is provided, uses the current date.
     * If only date_from is set, uses that date.
     * If only date_to is set, uses that date.
     *
     * @param array $filters ['date_from' => 'YYYY-MM-DD', 'date_to' => 'YYYY-MM-DD']
     * @return array Opening balance
     * [
     *     'balance'      => int,
     *     'cash_balance' => int,
     *     'bank_balance' => int,
     * ]
     */
    public function getOpeningBalance(array $filters = [])
    {
        // Determine the date to query
        $date = $filters['date_from'] ?? $filters['date_to'] ?? date('Y-m-d');

        // Try to get the opening balance for the given date
        $openingData = DayOpeningBalance::where('date', $date)->first();

        if ($openingData) {
            // Return the opening balance for the given date
            return [
                'balance'      => $openingData->balance ?? 0,
                'cash_balance' => $openingData->cash_balance ?? 0,
                'bank_balance' => $openingData->bank_balance ?? 0,
            ];
        }

        // If no opening balance exists for the given date, try to get the last known opening balance before the given date
        $lastData = DayOpeningBalance::where('date', '<', $date)
            ->orderByDesc('date')
            ->first();

        // Return the last known opening balance before the given date
        return [
            'balance'      => $lastData->balance ?? 0,
            'cash_balance' => $lastData->cash_balance ?? 0,
            'bank_balance' => $lastData->bank_balance ?? 0,
        ];
    }

    public function getLedgerEntries(array $filters = [])
    {
        $sortEntriesDesc = function ($entries) {
            return $entries->sortByDesc(function ($entry) {
                $paymentDate = strtotime((string) ($entry->payment_date ?? '1970-01-01')) ?: 0;
                $createdAt = strtotime((string) ($entry->created_at ?? $entry->payment_date ?? '1970-01-01 00:00:00')) ?: 0;

                return ($paymentDate * 100000) + $createdAt;
            })->values();
        };

        // Manual transactions
        $manualTransactions = $this->getTransactions([
            'id',
            'payment_date',
            'transaction_type',
            'payment_method',
            'amount',
            'note',
            'created_at',
        ], $filters)->map(function ($item) {
            $item->source = 'Manual';
            return $item;
        });

        // Sales (invoices)
        $salesQuery = Invoice::query()->where('deleted', 0);

        if (! empty($filters['date_from'])) {
            $salesQuery->where('invoice_date', '>=', $filters['date_from']);
        }
        if (! empty($filters['date_to'])) {
            $salesQuery->where('invoice_date', '<=', $filters['date_to']);
        }

        if (! empty($filters['transaction_type']) && $filters['transaction_type'] === 'debit') {
            $salesQuery->whereRaw('0=1'); // no debit entry in sales
        }

        $salesEntries = $salesQuery->get()->map(function ($invoice) {
            return (object) [
                'id'               => 'sale-' . $invoice->id,
                'payment_date'     => $invoice->invoice_date,
                'transaction_type' => 'credit',
                'payment_method'   => null,
                'paymentMethod'    => null,
                'amount'           => $invoice->net_amount ?: 0,
                'note'             => 'Sale Invoice #' . $invoice->invoice_no . ' (' . $invoice->customer_name . ')',
                'source'           => 'Sale',
                'created_at'       => $invoice->created_at,
            ];
        });

        // Purchases
        $purchaseQuery = Purchase::query()->where('deleted', 0);

        if (! empty($filters['date_from'])) {
            $purchaseQuery->where('purchase_date', '>=', $filters['date_from']);
        }
        if (! empty($filters['date_to'])) {
            $purchaseQuery->where('purchase_date', '<=', $filters['date_to']);
        }

        if (! empty($filters['transaction_type']) && $filters['transaction_type'] === 'credit') {
            $purchaseQuery->whereRaw('0=1'); // no credit entry in purchases
        }

        $purchaseEntries = $purchaseQuery->get()->map(function ($purchase) {
            return (object) [
                'id'               => 'purchase-' . $purchase->id,
                'payment_date'     => $purchase->purchase_date,
                'transaction_type' => 'debit',
                'payment_method'   => null,
                'paymentMethod'    => null,
                'amount'           => $purchase->purchase_cost ?: 0,
                'note'             => 'Purchase #' . $purchase->id . ' (' . $purchase->model . ')',
                'source'           => 'Purchase',
                'created_at'       => $purchase->created_at,
            ];
        });

        // Apply source filter if requested
        $sourceFilter = strtolower($filters['source'] ?? 'all');

        if (! empty($sourceFilter) && $sourceFilter !== 'all') {
            if ($sourceFilter === 'manual') {
                return $sortEntriesDesc($manualTransactions);
            }

            if ($sourceFilter === 'sale' || $sourceFilter === 'sales') {
                return $sortEntriesDesc($salesEntries);
            }

            if ($sourceFilter === 'purchase' || $sourceFilter === 'purchases') {
                return $sortEntriesDesc($purchaseEntries);
            }

            // unknown source: return empty
            return collect([]);
        }

        $allEntries = $manualTransactions->concat($salesEntries)->concat($purchaseEntries);

        return $sortEntriesDesc($allEntries);
    }
}
