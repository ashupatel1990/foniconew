<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Reconciliation extends Model
{
    use HasFactory;

    protected $table = 'reconciliations';

    protected $fillable = [
        'account_id',
        'reconciliation_date',
        'statement_date',
        'statement_balance',
        'system_balance',
        'difference',
        'reconciliation_status',
        'notes',
        'cleared_by_id',
    ];

    protected $casts = [
        'reconciliation_date' => 'date',
        'statement_date' => 'date',
        'statement_balance' => 'decimal:2',
        'system_balance' => 'decimal:2',
        'difference' => 'decimal:2',
    ];

    public function account()
    {
        return $this->belongsTo(CashBankLedger::class, 'account_id');
    }

    public function clearedBy()
    {
        return $this->belongsTo(User::class, 'cleared_by_id');
    }

    public function reconciliationItems()
    {
        return $this->hasMany(ReconciliationItem::class);
    }

    public function scopeComplete($query)
    {
        return $query->where('reconciliation_status', 'COMPLETE');
    }

    public function scopePending($query)
    {
        return $query->where('reconciliation_status', 'PENDING');
    }

    public function calculateDifference()
    {
        return abs($this->statement_balance - $this->system_balance);
    }

    public function updateStatus()
    {
        $totalItems = $this->reconciliationItems()->count();
        $clearedItems = $this->reconciliationItems()->where('is_cleared', true)->count();

        if ($clearedItems === 0) {
            $status = 'PENDING';
        } elseif ($clearedItems === $totalItems) {
            $status = 'COMPLETE';
        } else {
            $status = 'PARTIAL';
        }

        $this->update(['reconciliation_status' => $status]);
    }
}
