<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class RecurringTransaction extends Model
{
    use HasFactory;

    protected $table = 'recurring_transactions';

    protected $fillable = [
        'party_id',
        'frequency',
        'start_date',
        'end_date',
        'amount',
        'transaction_type',
        'description',
        'is_active',
        'next_due_date',
    ];

    protected $casts = [
        'start_date' => 'date',
        'end_date' => 'date',
        'next_due_date' => 'date',
        'amount' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function party()
    {
        return $this->belongsTo(Party::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeDue($query)
    {
        return $query->where('next_due_date', '<=', now()->toDateString())
                     ->where('is_active', true);
    }

    public function calculateNextDueDate()
    {
        $nextDate = $this->next_due_date;

        switch ($this->frequency) {
            case 'DAILY':
                $nextDate = $nextDate->addDay();
                break;
            case 'WEEKLY':
                $nextDate = $nextDate->addWeek();
                break;
            case 'MONTHLY':
                $nextDate = $nextDate->addMonth();
                break;
            case 'QUARTERLY':
                $nextDate = $nextDate->addMonths(3);
                break;
            case 'YEARLY':
                $nextDate = $nextDate->addYear();
                break;
        }

        return $nextDate;
    }

    public function processIfDue()
    {
        if ($this->next_due_date <= now()->toDateString() && $this->is_active) {
            LedgerEntry::create([
                'entry_date' => now()->toDateString(),
                'entry_type' => $this->transaction_type === 'CREDIT' ? 'RECEIPT' : 'PAYMENT',
                'party_id' => $this->party_id,
                'created_by' => 1,
                'debit_amount' => $this->transaction_type === 'DEBIT' ? $this->amount : 0,
                'credit_amount' => $this->transaction_type === 'CREDIT' ? $this->amount : 0,
                'payment_method_id' => 1,
                'description' => $this->description ?? 'Recurring: ' . $this->party->name,
            ]);

            $this->update(['next_due_date' => $this->calculateNextDueDate()]);

            // Check if end date has passed
            if ($this->end_date && $this->next_due_date > $this->end_date) {
                $this->update(['is_active' => false]);
            }
        }
    }
}
