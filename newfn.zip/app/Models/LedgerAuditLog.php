<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LedgerAuditLog extends Model
{
    protected $table = 'ledger_audit_logs';

    public $timestamps = false;

    protected $fillable = [
        'ledger_entry_id',
        'action',
        'old_values',
        'new_values',
        'user_id',
        'ip_address',
        'user_agent',
    ];

    protected $casts = [
        'old_values' => 'json',
        'new_values' => 'json',
        'created_at' => 'datetime',
    ];

    protected $dates = ['created_at'];

    public function ledgerEntry()
    {
        return $this->belongsTo(LedgerEntry::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($log) {
            $log->created_at = now();
        });
    }
}
