<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CashBankLedger extends Model
{
    use HasFactory;

    protected $table = 'cash_bank_ledgers';

    protected $fillable = [
        'account_type',
        'account_name',
        'opening_balance',
        'current_balance',
        'bank_name',
        'account_number',
        'ifsc_code',
        'branch_name',
        'is_active',
    ];

    protected $casts = [
        'opening_balance' => 'decimal:2',
        'current_balance' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function ledgerEntries()
    {
        return $this->hasMany(LedgerEntry::class, 'account_id');
    }

    public function reconciliations()
    {
        return $this->hasMany(Reconciliation::class, 'account_id');
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeForType($query, $type)
    {
        return $query->where('account_type', $type);
    }

    public function getBalance()
    {
        return $this->current_balance;
    }

    public function updateBalance($amount)
    {
        $this->update(['current_balance' => $this->current_balance + $amount]);
        \Cache::forget("account.balance.{$this->id}");
    }

    public function getFormattedBalanceAttribute()
    {
        return '₹ ' . number_format($this->current_balance, 2);
    }
}
