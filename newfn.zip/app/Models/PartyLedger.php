<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PartyLedger extends Model
{
    use HasFactory;

    protected $table = 'party_ledgers';

    protected $fillable = [
        'party_id',
        'opening_balance',
        'total_credit',
        'total_debit',
        'closing_balance',
        'balance_date',
        'last_transaction_date',
    ];

    protected $casts = [
        'opening_balance' => 'decimal:2',
        'total_credit' => 'decimal:2',
        'total_debit' => 'decimal:2',
        'closing_balance' => 'decimal:2',
        'balance_date' => 'date',
        'last_transaction_date' => 'date',
    ];

    public function party()
    {
        return $this->belongsTo(Party::class);
    }

    public function getBalance()
    {
        return ($this->total_credit ?? 0) - ($this->total_debit ?? 0);
    }

    public function getStatement($from, $to)
    {
        return $this->party->ledgerEntries()
                           ->betweenDates($from, $to)
                           ->orderBy('entry_date')
                           ->get();
    }

    public function getDueSince($days)
    {
        $cutoffDate = now()->subDays($days)->toDateString();
        return $this->party->ledgerEntries()
                           ->where('entry_date', '<', $cutoffDate)
                           ->where('is_reconciled', false)
                           ->sum('debit_amount');
    }
}
