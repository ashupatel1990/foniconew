<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ReconciliationItem extends Model
{
    use HasFactory;

    protected $table = 'reconciliation_items';

    protected $fillable = [
        'reconciliation_id',
        'ledger_entry_id',
        'is_cleared',
        'cleared_date',
    ];

    protected $casts = [
        'is_cleared' => 'boolean',
        'cleared_date' => 'datetime',
    ];

    public function reconciliation()
    {
        return $this->belongsTo(Reconciliation::class);
    }

    public function ledgerEntry()
    {
        return $this->belongsTo(LedgerEntry::class);
    }

    public function markAsCleared()
    {
        $this->update([
            'is_cleared' => true,
            'cleared_date' => now(),
        ]);

        $this->ledgerEntry()->update(['is_reconciled' => true]);
        $this->reconciliation()->updateStatus();
    }
}
