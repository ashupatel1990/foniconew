<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class LedgerEntry extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'ledger_entries';

    protected $fillable = [
        'entry_date',
        'entry_type',
        'transaction_id',
        'party_id',
        'created_by',
        'debit_amount',
        'credit_amount',
        'payment_method_id',
        'reference_number',
        'description',
        'notes',
        'attachment_url',
        'is_reconciled',
        'reconciliation_date',
    ];

    protected $casts = [
        'entry_date' => 'date',
        'debit_amount' => 'decimal:2',
        'credit_amount' => 'decimal:2',
        'is_reconciled' => 'boolean',
        'reconciliation_date' => 'datetime',
    ];

    // === RELATIONSHIPS ===
    public function party()
    {
        return $this->belongsTo(Party::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethod::class);
    }

    public function reconciliationItems()
    {
        return $this->hasMany(ReconciliationItem::class);
    }

    public function auditLogs()
    {
        return $this->hasMany(LedgerAuditLog::class);
    }

    // === SCOPES ===
    public function scopeForDate($query, $date)
    {
        return $query->whereDate('entry_date', $date);
    }

    public function scopeForParty($query, $party_id)
    {
        return $query->where('party_id', $party_id);
    }

    public function scopeForType($query, $type)
    {
        return $query->where('entry_type', $type);
    }

    public function scopeBetweenDates($query, $from, $to)
    {
        return $query->whereDate('entry_date', '>=', $from)
                     ->whereDate('entry_date', '<=', $to);
    }

    public function scopeUnreconciled($query)
    {
        return $query->where('is_reconciled', false);
    }

    public function scopeReconciled($query)
    {
        return $query->where('is_reconciled', true);
    }

    public function scopeCredits($query)
    {
        return $query->where('credit_amount', '>', 0);
    }

    public function scopeDebits($query)
    {
        return $query->where('debit_amount', '>', 0);
    }

    // === ACCESSORS & MUTATORS ===
    public function getAmountAttribute()
    {
        return $this->debit_amount ?? $this->credit_amount ?? 0;
    }

    public function getFormattedAmountAttribute()
    {
        $amount = $this->amount;
        $symbol = $this->credit_amount > 0 ? '+' : '-';
        return $symbol . number_format(abs($amount), 2);
    }

    // === METHODS ===
    public function reconcile()
    {
        $this->update([
            'is_reconciled' => true,
            'reconciliation_date' => now(),
        ]);
        \Cache::forget("ledger.balance.{$this->entry_date}");
    }

    public function getBalance()
    {
        $debit = abs($this->debit_amount ?? 0);
        $credit = abs($this->credit_amount ?? 0);
        return $credit - $debit;
    }

    // === EVENTS ===
    protected static function boot()
    {
        parent::boot();

        static::created(function ($entry) {
            LedgerAuditLog::create([
                'ledger_entry_id' => $entry->id,
                'action' => 'CREATE',
                'new_values' => $entry->toArray(),
                'user_id' => auth()->id() ?? 1,
                'ip_address' => request()->ip(),
            ]);

            // Clear cache
            \Cache::forget("ledger.balance.{$entry->entry_date}");
            \Cache::forget("party.balance.{$entry->party_id}");
        });

        static::updated(function ($entry) {
            LedgerAuditLog::create([
                'ledger_entry_id' => $entry->id,
                'action' => 'UPDATE',
                'old_values' => $entry->getOriginal(),
                'new_values' => $entry->getChanges(),
                'user_id' => auth()->id() ?? 1,
                'ip_address' => request()->ip(),
            ]);

            // Clear cache
            \Cache::forget("ledger.balance.{$entry->entry_date}");
            \Cache::forget("party.balance.{$entry->party_id}");
        });

        static::deleted(function ($entry) {
            LedgerAuditLog::create([
                'ledger_entry_id' => $entry->id,
                'action' => 'DELETE',
                'old_values' => $entry->toArray(),
                'user_id' => auth()->id() ?? 1,
                'ip_address' => request()->ip(),
            ]);

            // Clear cache
            \Cache::forget("ledger.balance.{$entry->entry_date}");
            \Cache::forget("party.balance.{$entry->party_id}");
        });
    }
}
