<?php

namespace App\Http\Requests\Ledger;

use Illuminate\Foundation\Http\FormRequest;

class StoreLedgerEntryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'party_id' => 'required|exists:parties,id',
            'entry_date' => 'required|date|before_or_equal:today',
            'entry_type' => 'required|in:SALE,PURCHASE,EXPENSE,PAYMENT,RECEIPT,TRANSFER,OPENING_BALANCE',
            'payment_method_id' => 'required|exists:payment_methods,id',
            'debit_amount' => 'nullable|numeric|min:0',
            'credit_amount' => 'nullable|numeric|min:0',
            'reference_number' => 'nullable|string|max:100',
            'description' => 'nullable|string|max:500',
            'notes' => 'nullable|string|max:1000',
        ];
    }

    public function messages(): array
    {
        return [
            'party_id.required' => 'Please select a party',
            'entry_date.before_or_equal' => 'Entry date cannot be in the future',
            'payment_method_id.required' => 'Please select a payment method',
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            $debit = $this->input('debit_amount', 0);
            $credit = $this->input('credit_amount', 0);

            if ($debit > 0 && $credit > 0) {
                $validator->errors()->add('amount',
                    'Cannot have both debit and credit amounts');
            }

            if ($debit <= 0 && $credit <= 0) {
                $validator->errors()->add('amount',
                    'Either debit or credit amount is required');
            }
        });
    }
}
