<?php

namespace App\Http\Middleware;

use App\Models\PersonalAccessToken;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class AuthenticateApiToken
{
    public function handle(Request $request, Closure $next): Response
    {
        $plainTextToken = $request->bearerToken();

        if (! $plainTextToken) {
            return response()->json([
                'message' => 'Unauthorized.',
            ], 401);
        }

        $accessToken = PersonalAccessToken::query()
            ->where('token', hash('sha256', $plainTextToken))
            ->where(function ($query) {
                $query->whereNull('expires_at')
                    ->orWhere('expires_at', '>', now());
            })
            ->with('tokenable')
            ->first();

        if (! $accessToken || ! $accessToken->tokenable) {
            return response()->json([
                'message' => 'Invalid or expired token.',
            ], 401);
        }

        $accessToken->forceFill([
            'last_used_at' => Carbon::now(),
        ])->save();

        Auth::setUser($accessToken->tokenable);
        $request->attributes->set('api_access_token', $accessToken);
        $request->setUserResolver(fn () => $accessToken->tokenable);

        return $next($request);
    }
}
