<?php

namespace App\Http\Controllers\Ledger;

use App\Http\Controllers\Controller;
use App\Models\CashBankLedger;
use App\Models\LedgerEntry;
use App\Models\Party;
use App\Models\PaymentMethod;
use App\Services\Ledger\LedgerService;
use App\Services\Ledger\BalanceCalculationService;
use Illuminate\Http\Request;

class LedgerEntryController extends Controller
{
    protected $ledgerService;
    protected $balanceService;

    public function __construct(
        LedgerService $ledgerService,
        BalanceCalculationService $balanceService
    ) {
        $this->ledgerService = $ledgerService;
        $this->balanceService = $balanceService;
    }

    /**
     * Display a listing of ledger entries
     */
    public function index(Request $request)
    {
        try {
            $parties = Party::query()->select('id', 'party_name')->get();
            $paymentMethods = PaymentMethod::all(['id', 'method_name']);
            $filters = [
                'date_from' => $request->date_from,
                'date_to' => $request->date_to,
                'party_id' => $request->party_id,
                'entry_type' => $request->entry_type,
                'payment_method_id' => $request->payment_method_id,
            ];

            if ($request->ajax()) {
                $data = $this->ledgerService->getFilteredEntries($filters);
                $recordsTotal = LedgerEntry::count();
                $summary = $this->buildSummary($data);

                $search = trim((string) $request->input('search.value', ''));
                if ($search !== '') {
                    $searchLower = mb_strtolower($search);
                    $data = $data->filter(function ($entry) use ($searchLower) {
                        $haystack = [
                            (string) $entry->entry_date,
                            (string) ($entry->party->name ?? $entry->party->party_name ?? ''),
                            (string) $entry->entry_type,
                            (string) $entry->reference_number,
                            (string) $entry->description,
                            (string) $entry->notes,
                        ];

                        foreach ($haystack as $value) {
                            if (str_contains(mb_strtolower($value), $searchLower)) {
                                return true;
                            }
                        }

                        return false;
                    })->values();
                }

                $recordsFiltered = $data->count();

                $columnMap = [
                    0 => 'id',
                    1 => 'entry_date',
                    2 => 'party_name',
                    3 => 'entry_type',
                    4 => 'debit_amount',
                    5 => 'credit_amount',
                    6 => null,
                ];

                $orderColumnIndex = (int) $request->input('order.0.column', 1);
                $orderDirection = strtolower((string) $request->input('order.0.dir', 'desc')) === 'asc' ? 'asc' : 'desc';
                $orderColumn = $columnMap[$orderColumnIndex] ?? 'entry_date';

                if ($orderColumn) {
                    $data = $data->sortBy(function ($entry) use ($orderColumn) {
                        if ($orderColumn === 'party_name') {
                            return (string) ($entry->party->name ?? $entry->party->party_name ?? '');
                        }

                        return $entry->{$orderColumn};
                    }, SORT_REGULAR, $orderDirection === 'desc')->values();
                }

                $start = max((int) $request->input('start', 0), 0);
                $length = (int) $request->input('length', 10);
                if ($length < 0) {
                    $length = 10;
                }

                $rows = $data->slice($start, $length)->values();

                $responseData = $rows->map(function ($entry, $index) use ($start) {
                    return [
                        'id' => $entry->id,
                        'DT_RowIndex' => $start + $index + 1,
                        'entry_date' => $entry->entry_date
                            ? $entry->entry_date->format('d/m/Y') . ' ' . optional($entry->created_at)->format('h:i')
                            : '-',
                        'party_name' => $entry->party->name ?? $entry->party->party_name ?? '-',
                        'entry_type' => $entry->entry_type,
                        'debit_display' => $entry->debit_amount > 0 ? '₹ ' . number_format($entry->debit_amount, 2) : '-',
                        'credit_display' => $entry->credit_amount > 0 ? '₹ ' . number_format($entry->credit_amount, 2) : '-',
                        'action' => '
                            <a href="' . route('ledger.show', $entry->id) . '" class="btn btn-sm btn-info">View</a>
                            <a href="' . route('ledger.edit', $entry->id) . '" class="btn btn-sm btn-warning">Edit</a>
                            <button type="button" class="btn btn-sm btn-danger delete-btn" data-id="' . $entry->id . '">Delete</button>
                        ',
                    ];
                })->values();

                return response()->json([
                    'draw' => (int) $request->input('draw', 1),
                    'recordsTotal' => $recordsTotal,
                    'recordsFiltered' => $recordsFiltered,
                    'data' => $responseData,
                    'summary' => $summary,
                ]);
            }

            $summary = $this->buildSummary($this->ledgerService->getFilteredEntries($filters));

            return view('ledger.index', compact('parties', 'paymentMethods', 'summary'));
        } catch (\Exception $e) {
            return redirect()->back()
                           ->with('error', 'Error loading ledger: ' . $e->getMessage());
        }
    }

    protected function buildSummary($entries): array
    {
        $totalIn = (float) $entries->sum('credit_amount');
        $totalOut = (float) $entries->sum('debit_amount');

        return [
            'total_balance' => $totalIn - $totalOut,
            'cash_balance' => (float) CashBankLedger::query()->active()->forType('CASH')->sum('current_balance'),
            'bank_balance' => (float) CashBankLedger::query()->active()->forType('BANK')->sum('current_balance'),
            'total_in' => $totalIn,
            'total_out' => $totalOut,
        ];
    }

    /**
     * Show the form for creating a new entry
     */
    public function create()
    {
        $parties = Party::all();
        $paymentMethods = PaymentMethod::all();
        
        return view('ledger.create', compact('parties', 'paymentMethods'));
    }

    /**
     * Store a newly created entry
     */
    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'party_id' => 'required|exists:parties,id',
                'entry_date' => 'required|date|before_or_equal:today',
                'entry_type' => 'required|in:SALE,PURCHASE,EXPENSE,PAYMENT,RECEIPT,TRANSFER,OPENING_BALANCE',
                'payment_method_id' => 'required|exists:payment_methods,id',
                'debit_amount' => 'nullable|numeric|min:0',
                'credit_amount' => 'nullable|numeric|min:0',
                'reference_number' => 'nullable|string|max:100',
                'description' => 'nullable|string|max:500',
                'notes' => 'nullable|string|max:1000',
            ]);

            $validated['created_by'] = auth()->id();

            $entry = $this->ledgerService->createEntry($validated);

            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Ledger entry created successfully',
                    'data' => $entry,
                ]);
            }

            return redirect()->route('ledger.index')
                           ->with('success', 'Entry created successfully');
        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                ], 400);
            }

            return redirect()->back()
                           ->with('error', 'Error creating entry: ' . $e->getMessage())
                           ->withInput();
        }
    }

    /**
     * Display the specified entry
     */
    public function show(LedgerEntry $entry)
    {
        $auditLogs = $entry->auditLogs()->latest()->get();
        return view('ledger.show', compact('entry', 'auditLogs'));
    }

    /**
     * Show the form for editing the specified entry
     */
    public function edit(LedgerEntry $entry)
    {
        $parties = Party::all();
        $paymentMethods = PaymentMethod::all();
        $auditLogs = $entry->auditLogs()->latest()->limit(10)->get();

        return view('ledger.edit', compact('entry', 'parties', 'paymentMethods', 'auditLogs'));
    }

    /**
     * Update the specified entry
     */
    public function update(Request $request, LedgerEntry $entry)
    {
        try {
            $validated = $request->validate([
                'party_id' => 'required|exists:parties,id',
                'entry_date' => 'required|date|before_or_equal:today',
                'entry_type' => 'required|in:SALE,PURCHASE,EXPENSE,PAYMENT,RECEIPT,TRANSFER,OPENING_BALANCE',
                'payment_method_id' => 'required|exists:payment_methods,id',
                'debit_amount' => 'nullable|numeric|min:0',
                'credit_amount' => 'nullable|numeric|min:0',
                'reference_number' => 'nullable|string|max:100',
                'description' => 'nullable|string|max:500',
                'notes' => 'nullable|string|max:1000',
            ]);

            $updatedEntry = $this->ledgerService->updateEntry($entry->id, $validated);

            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Entry updated successfully',
                    'data' => $updatedEntry,
                ]);
            }

            return redirect()->route('ledger.show', $entry)
                           ->with('success', 'Entry updated successfully');
        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                ], 400);
            }

            return redirect()->back()
                           ->with('error', 'Error updating entry: ' . $e->getMessage())
                           ->withInput();
        }
    }

    /**
     * Delete the specified entry
     */
    public function destroy(Request $request, LedgerEntry $entry)
    {
        try {
            $this->ledgerService->deleteEntry($entry->id);

            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Entry deleted successfully',
                ]);
            }

            return redirect()->route('ledger.index')
                           ->with('success', 'Entry deleted successfully');
        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                ], 400);
            }

            return redirect()->back()
                           ->with('error', 'Error deleting entry: ' . $e->getMessage());
        }
    }

    /**
     * Mark entry as reconciled
     */
    public function reconcile(Request $request, LedgerEntry $entry)
    {
        try {
            $entry->reconcile();

            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Entry reconciled successfully',
                ]);
            }

            return redirect()->back()
                           ->with('success', 'Entry reconciled successfully');
        } catch (\Exception $e) {
            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => $e->getMessage(),
                ], 400);
            }

            return redirect()->back()
                           ->with('error', 'Error reconciling entry: ' . $e->getMessage());
        }
    }

    /**
     * Get daily balance summary
     */
    public function getDailySummary(Request $request)
    {
        try {
            $date = $request->date ?? now()->toDateString();
            $balance = $this->balanceService->calculateDailyBalance($date);

            return response()->json([
                'success' => true,
                'data' => $balance,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }
}
