<?php
namespace App\Http\Controllers;

use App\Models\User;
use App\Services\JsonService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Spatie\Permission\Models\Role;
use Symfony\Component\HttpFoundation\Response;

class UserController extends Controller
{
    protected $jsonService;

    public function __construct()
    {
        $this->jsonService = new JsonService();
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = User::with('roles.permissions');

            $search = trim((string) $request->input('search.value', ''));
            if ($search !== '') {
                $query->where(function ($builder) use ($search) {
                    $builder->where('name', 'like', "%{$search}%")
                        ->orWhere('user_name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%")
                        ->orWhereHas('roles', function ($roleQuery) use ($search) {
                            $roleQuery->where('name', 'like', "%{$search}%");
                        });
                });
            }

            $recordsTotal = User::count();
            $recordsFiltered = (clone $query)->count();

            $columnMap = [
                0 => 'id',
                1 => null,
                2 => 'name',
                3 => 'user_name',
                4 => 'email',
                5 => null,
                6 => 'created_at',
                7 => null,
            ];

            $orderColumnIndex = (int) $request->input('order.0.column', 6);
            $orderDirection = strtolower((string) $request->input('order.0.dir', 'desc')) === 'asc' ? 'asc' : 'desc';
            $orderColumn = $columnMap[$orderColumnIndex] ?? 'created_at';

            if ($orderColumn) {
                $query->orderBy($orderColumn, $orderDirection);
            } else {
                $query->orderBy('created_at', 'desc');
            }

            $start = max((int) $request->input('start', 0), 0);
            $length = (int) $request->input('length', 10);
            if ($length < 0) {
                $length = 10;
            }

            $users = $query->skip($start)->take($length)->get();

            $data = $users->values()->map(function ($user, $index) use ($start) {
                return [
                    'id' => $user->id,
                    'DT_RowIndex' => $start + $index + 1,
                    'profile_image' => $user->profile_image,
                    'name' => $user->name,
                    'user_name' => $user->user_name,
                    'email' => $user->email,
                    'roles' => $user->roles->map(function ($role) {
                        return [
                            'name' => $role->name,
                            'permissions' => $role->permissions->pluck('name')->values()->all(),
                        ];
                    })->values()->all(),
                    'created_at' => optional($user->created_at)->toDateTimeString(),
                    'action' => '',
                ];
            });

            return response()->json([
                'draw' => (int) $request->input('draw', 1),
                'recordsTotal' => $recordsTotal,
                'recordsFiltered' => $recordsFiltered,
                'data' => $data,
            ]);
        }

        $roles = Role::all();
        return view('users.index', compact('roles'));
    }
    public function create()
    {
        return view('users.create', ['roles' => Role::all()]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'      => 'required|string|max:255',
            'email'     => 'required|email|unique:users,email,' . $request->id,
            'user_name' => 'required|string|unique:users,user_name,' . $request->id,
            'roles'     => 'required|array',
            'password'  => $request->id ? 'nullable|min:6|confirmed' : 'required|min:6|confirmed',
            'profile_image'    => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        // Handle avatar upload
        $avatarPath = null;
        if ($request->hasFile('profile_image')) {
            $avatarPath = $request->file('profile_image');
        }
// dd($avatarPath);
        if ($request->id) {
            // Update existing user
            $user = User::findOrFail($request->id);
            $user->update([
                'name'      => $request->name,
                'email'     => $request->email,
                'user_name' => $request->user_name,
                'profile_image'    => $avatarPath ?? $user->profile_image,
            ]);

            if ($request->filled('password')) {
                $user->update(['password' => bcrypt($request->password)]);
            }

            $user->syncRoles($request->roles);

            return response()->json([
                'status'  => true,
                'message' => 'User updated successfully!',
            ]);
        } else {
            // Create new user
            $user = User::create([
                'name'      => $request->name,
                'email'     => $request->email,
                'user_name' => $request->user_name,
                'password'  => bcrypt($request->password),
                'profile_image'    => $avatarPath,
            ]);

            $user->assignRole($request->roles);

            return response()->json([
                'status'  => true,
                'message' => 'User created successfully!',
            ]);
        }
    }

    public function edit($id)
    {
        try {
            $user = User::with('roles')->findOrFail($id);

            return $this->jsonService->sendResponse(
                true,
                [
                    'id'         => $user->id,
                    'name'       => $user->name,
                    'email'      => $user->email,
                    'user_name'  => $user->user_name,
                    'roles'      => $user->roles->map(function ($role) {
                        return [
                            'id'   => $role->id,
                            'name' => $role->name,
                        ];
                    }),
                    'avatar_url' => $user->avatar
                    ? asset('storage/' . $user->avatar)
                    : asset('assets/images/users/user-5.jpg'),
                ],
                'User fetched successfully',
                Response::HTTP_OK
            );
        } catch (\Exception $e) {
            return $this->jsonService->sendResponse(
                false,
                null,
                'User not found',
                Response::HTTP_NOT_FOUND
            );
        }
    }

    public function destroy($id)
    {
        try {
            $user = User::findOrFail($id);

            // Optional: Delete avatar file from storage
            if ($user->avatar && Storage::disk('public')->exists($user->avatar)) {
                Storage::disk('public')->delete($user->avatar);
            }

            $user->delete();

            return $this->jsonService->sendResponse(
                true,
                null,
                'User deleted successfully!',
                Response::HTTP_OK
            );
        } catch (\Exception $e) {
            return $this->jsonService->sendResponse(
                false,
                null,
                'Failed to delete user',
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }
}
