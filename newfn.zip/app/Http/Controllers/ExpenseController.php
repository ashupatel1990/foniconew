<?php

namespace App\Http\Controllers;

use App\Models\Expense;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ExpenseController extends Controller
{
    //
    public function index(Request $request)
    {
        $month = $request->input('month', Carbon::now()->format('F'));
        $year = (int) $request->input('year', Carbon::now()->year);

        $query = Expense::where('deleted', 0)->orderBy('entrydate', 'desc');

        if ($month === 'All') {
            $query->whereYear('entrydate', $year);
            $periodLabel = 'All Months';
        } else {
            $monthNumber = Carbon::parse("1 $month")->month;
            $startOfMonth = Carbon::create($year, $monthNumber, 1)->startOfMonth();
            $endOfMonth = Carbon::create($year, $monthNumber, 1)->endOfMonth();
            $query->whereBetween('entrydate', [$startOfMonth, $endOfMonth]);
            $periodLabel = $month;
        }

        $expenses = $query->get();
        $totalExpenseAmount = $expenses->sum('amount');

        return view('expenses.index', [
            'expenses' => $expenses,
            'year' => $year,
            'month' => $month,
            'periodLabel' => $periodLabel,
            'totalExpenseAmount' => number_format($totalExpenseAmount, 2, '.', ''),
        ]);
    }

    public function addExpense()
    {
        return redirect()->route('expenses', ['open' => 'add']);
    }

    public function saveExpense(Request $request)
    {
        // dd($request);
        $request->validate([
            'amount' => 'required|numeric',
            'entrydate' => 'required|date',
        ]);
        $expense = new Expense;
        $expense->amount = $request->amount;
        $expense->entrydate = $request->entrydate;
        $expense->expense_category = $request->expense_category;
        $expense->description = $request->description;
        $expense->added_by = auth()->user()->id;
        $expense->save();

        return redirect()->route('expenses')->withStatus('Expense Added Successfully..');
    }

    public function editExpense($id)
    {
        $expense = Expense::findOrFail($id);

        return view('expenses.expenseedit', ['expense' => $expense]);
    }

    public function updateExpense(Request $request, $id)
    {
        $request->validate([
            'amount' => 'required|numeric',
            'entrydate' => 'required|date',
        ]);
        $expense = Expense::findOrFail($id);
        $updateData = $request->all();
        $expense->update($updateData);

        return redirect()->route('expenses')->withStatus('Expense Updated Successfully..');
    }

    public function deleteExpense($id)
    {
        Expense::findOrFail($id)->update([
            'deleted' => 1,
        ]);

        return redirect()->route('expenses')->withStatus('Expense Deleted Successfully..');
    }
}
