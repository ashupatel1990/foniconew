<?php
namespace App\Http\Controllers;

use App\Services\JsonService;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Symfony\Component\HttpFoundation\Response;

class RoleController extends Controller
{
    protected $jsonService;

    public function __construct()
    {
        $this->jsonService = new JsonService();
    }
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = Role::with('permissions');

            $search = trim((string) $request->input('search.value', ''));
            if ($search !== '') {
                $query->where(function ($builder) use ($search) {
                    $builder->where('name', 'like', "%{$search}%")
                        ->orWhereHas('permissions', function ($permissionQuery) use ($search) {
                            $permissionQuery->where('name', 'like', "%{$search}%");
                        });
                });
            }

            $recordsTotal = Role::count();
            $recordsFiltered = (clone $query)->count();

            $columnMap = [
                0 => 'id',
                1 => 'name',
                2 => null,
                3 => null,
            ];

            $orderColumnIndex = (int) $request->input('order.0.column', 1);
            $orderDirection = strtolower((string) $request->input('order.0.dir', 'asc')) === 'desc' ? 'desc' : 'asc';
            $orderColumn = $columnMap[$orderColumnIndex] ?? 'id';

            if ($orderColumn) {
                $query->orderBy($orderColumn, $orderDirection);
            } else {
                $query->orderBy('id', 'desc');
            }

            $start = max((int) $request->input('start', 0), 0);
            $length = (int) $request->input('length', 10);
            if ($length < 0) {
                $length = 10;
            }

            $roles = $query->skip($start)->take($length)->get();

            $data = $roles->values()->map(function ($role, $index) use ($start) {
                return [
                    'id' => $role->id,
                    'DT_RowIndex' => $start + $index + 1,
                    'name' => $role->name,
                    'permissions' => $role->permissions->pluck('name')->values()->all(),
                    'action' => '',
                ];
            });

            return response()->json([
                'draw' => (int) $request->input('draw', 1),
                'recordsTotal' => $recordsTotal,
                'recordsFiltered' => $recordsFiltered,
                'data' => $data,
            ]);
        }

        $permissions = Permission::all();
        return view('roles.index', compact('permissions'));
    }

    public function create()
    {
        return view('roles.create', [
            'permissions' => Permission::all(),
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:roles,name,' . $request->id,
        ]);

        $newPermissions = array_filter($request->new_permissions ?? []);

        foreach ($newPermissions as $perm) {
            Permission::firstOrCreate(['name' => $perm]);
        }

        $allPermissions = array_merge($request->permissions ?? [], $newPermissions);

        if ($request->id) {
            $role = Role::findOrFail($request->id);
            $role->update(['name' => $request->name]);
            $role->syncPermissions($allPermissions);

            return $this->jsonService->sendResponse(
                true,
                null,
                'Role updated successfully!',
                Response::HTTP_OK
            );
        } else {
            $role = Role::create(['name' => $request->name]);
            $role->syncPermissions($allPermissions);

            return $this->jsonService->sendResponse(
                true,
                null,
                'Role created successfully!',
                Response::HTTP_CREATED
            );
        }
    }

    public function edit($id)
    {
        try {
            $role = Role::with('permissions')->findOrFail($id);

            return $this->jsonService->sendResponse(
                true,
                [
                    'id'          => $role->id,
                    'name'        => $role->name,
                    'permissions' => $role->permissions->pluck('name'),
                ],
                'Role fetched successfully',
                Response::HTTP_OK
            );
        } catch (\Exception $e) {
            return $this->jsonService->sendResponse(
                false,
                null,
                'Role not found',
                Response::HTTP_NOT_FOUND
            );
        }
    }

    public function destroy($id)
    {
        try {
            $role = Role::findOrFail($id);
            $role->delete();

            return $this->jsonService->sendResponse(
                true,
                null,
                'Role deleted successfully!',
                Response::HTTP_OK
            );
        } catch (\Exception $e) {
            return $this->jsonService->sendResponse(
                false,
                null,
                'Failed to delete role',
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }
}
