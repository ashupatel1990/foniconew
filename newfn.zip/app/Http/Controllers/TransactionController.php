<?php
namespace App\Http\Controllers;

use App\Constants\ResponseCode;
use App\Models\{Party, PaymentMethod};
use App\Models\Transaction;
use App\Services\JsonService;
use App\Services\OpeningBalanceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TransactionController extends Controller
{
    protected $jsonService;
    protected $openingBalanceService;

    public function __construct()
    {
        $this->jsonService           = new JsonService();
        $this->openingBalanceService = new OpeningBalanceService();
    }

    public function getFilter()
    {
        $filters = [
            'date_from'        => request('date_from'),
            'date_to'          => request('date_to'),
            'transaction_type' => request('transaction_type'),
            'payment_method'   => request('payment_method'),
            'source'          => request('source'),
        ];
        return $filters;
    }

    public function index()
    {
        try {
            $paymentMethods = PaymentMethod::all();
            $parties        = Party::all();
            if (\request()->ajax()) {
                $filters        = $this->getFilter();
                $data           = (new Transaction())->getLedgerEntries($filters);
                $openingBalance = (new Transaction())->getOpeningBalance($filters);

                // Calculate total IN and OUT
                $totalIn  = $data->where('transaction_type', 'credit')->sum('amount');
                $totalOut = $data->where('transaction_type', 'debit')->sum('amount');

                return $this->buildDataTableResponse($data, $openingBalance, $totalIn, $totalOut);
            }

            return view('finance.index', compact('paymentMethods', 'parties'));
        } catch (\Exception $e) {
            if (\request()->ajax()) {
                return $this->jsonService->sendResponse(false, null, 'Error loading transactions: ' . $e->getMessage(), ResponseCode::INTERNAL_SERVER_ERROR);
            }

            return redirect()->back()->with('error', 'Error loading transactions: ' . $e->getMessage());
        }
    }

    protected function buildDataTableResponse($data, array $openingBalance, $totalIn, $totalOut): JsonResponse
    {
        $request = request();
        $draw = (int) $request->input('draw', 0);
        $start = max((int) $request->input('start', 0), 0);
        $length = (int) $request->input('length', 10);
        $searchValue = trim((string) $request->input('search.value', ''));
        $orderColumnIndex = (int) $request->input('order.0.column', 1);
        $orderDirection = strtolower((string) $request->input('order.0.dir', 'desc')) === 'asc' ? 'asc' : 'desc';

        $columnMap = [
            1 => 'sort_timestamp',
            2 => 'transaction_type',
            3 => 'source',
            4 => 'payment_method_label',
            5 => 'amount',
            6 => 'note',
        ];

        $recordsTotal = $data->count();

        $normalizedData = $data->map(function ($row) {
            $paymentMethodLabel = '-';

            if (! empty($row->paymentMethod?->method_name)) {
                $paymentMethodLabel = $row->paymentMethod->method_name;
            } elseif (($row->source ?? null) === 'Sale') {
                $paymentMethodLabel = 'Invoice';
            } elseif (($row->source ?? null) === 'Purchase') {
                $paymentMethodLabel = 'Purchase';
            }

            return [
                'id' => $row->id,
                'payment_date' => $row->payment_date,
                'sort_timestamp' => ((strtotime((string) ($row->payment_date ?? '1970-01-01')) ?: 0) * 100000)
                    + (strtotime((string) ($row->created_at ?? $row->payment_date ?? '1970-01-01 00:00:00')) ?: 0),
                'transaction_type' => $row->transaction_type,
                'source' => $row->source,
                'payment_method' => $row->payment_method,
                'paymentMethod' => $row->paymentMethod,
                'payment_method_label' => $paymentMethodLabel,
                'amount' => $row->amount,
                'note' => $row->note,
                'created_at' => $row->created_at,
            ];
        });

        if ($searchValue !== '') {
            $searchTerm = mb_strtolower($searchValue);

            $normalizedData = $normalizedData->filter(function (array $row) use ($searchTerm) {
                $fields = [
                    $row['payment_date'],
                    $row['transaction_type'],
                    $row['source'],
                    $row['payment_method_label'],
                    $row['amount'],
                    $row['note'],
                ];

                foreach ($fields as $field) {
                    if (str_contains(mb_strtolower((string) $field), $searchTerm)) {
                        return true;
                    }
                }

                return false;
            })->values();
        }

        $recordsFiltered = $normalizedData->count();
        $sortKey = $columnMap[$orderColumnIndex] ?? 'payment_date';

        $normalizedData = $orderDirection === 'asc'
            ? $normalizedData->sortBy($sortKey, SORT_NATURAL)
            : $normalizedData->sortByDesc($sortKey, SORT_NATURAL);

        if ($length !== -1) {
            $normalizedData = $normalizedData->slice($start, $length)->values();
        } else {
            $normalizedData = $normalizedData->values();
        }

        $rowIndex = $start + 1;
        $responseData = $normalizedData->map(function (array $row) use (&$rowIndex) {
            $row['DT_RowIndex'] = $rowIndex++;
            return $row;
        });

        return response()->json([
            'draw' => $draw,
            'recordsTotal' => $recordsTotal,
            'recordsFiltered' => $recordsFiltered,
            'data' => $responseData,
            'openingBalance' => $openingBalance['balance'],
            'cashBalance' => $openingBalance['cash_balance'],
            'bankBalance' => $openingBalance['bank_balance'],
            'totalIn' => $totalIn,
            'totalOut' => $totalOut,
        ]);
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'party_id'         => 'required',
                'payment_date'     => 'required|date',
                'transaction_type' => 'required|string',
                'payment_method'   => 'required|string',
                'amount'           => 'required|numeric',
                'note'             => 'nullable|string',
            ]);

            if (! empty($request->id)) {
                $transaction = Transaction::find($request->id);
                if ($transaction) {
                    $transaction->update([
                        'party_id'         => $request->party_id,
                        'payment_date'     => $request->payment_date,
                        'transaction_type' => $request->transaction_type,
                        'payment_method'   => $request->payment_method,
                        'amount'           => $request->amount,
                        'note'             => $request->note,
                        'updated_by'       => Auth::id(),
                    ]);

                    $this->openingBalanceService->recalculateFrom($request->payment_date);

                    $filters        = $this->getFilter();
                    $openingBalance = (new Transaction())->getOpeningBalance($filters);

                    $data     = (new Transaction())->getLedgerEntries($filters);
                    $totalIn  = $data->where('transaction_type', 'credit')->sum('amount');
                    $totalOut = $data->where('transaction_type', 'debit')->sum('amount');

                    $responseData = [
                        'transaction'    => $transaction ?? null,
                        'openingBalance' => $openingBalance['balance'],
                        'cashBalance'    => $openingBalance['cash_balance'],
                        'bankBalance'    => $openingBalance['bank_balance'],
                        'totalIn'        => $totalIn,
                        'totalOut'       => $totalOut,
                    ];

                    return $this->jsonService->sendResponse(true, $responseData, 'Transaction updated successfully', ResponseCode::SUCCESS);
                } else {
                    return $this->jsonService->sendResponse(false, null, 'Transaction not found', ResponseCode::NOT_FOUND);
                }
            } else {
                $data               = $request->all();
                $data['created_by'] = Auth::id();
                $transaction        = Transaction::create($data);
                $this->openingBalanceService->recalculateFrom($request->payment_date);

                $filters        = $this->getFilter();
                $openingBalance = (new Transaction())->getOpeningBalance($filters);

                $data     = (new Transaction())->getLedgerEntries($filters);
                $totalIn  = $data->where('transaction_type', 'credit')->sum('amount');
                $totalOut = $data->where('transaction_type', 'debit')->sum('amount');

                $responseData = [
                    'transaction'    => $transaction ?? null,
                    'openingBalance' => $openingBalance['balance'],
                    'cashBalance'    => $openingBalance['cash_balance'],
                    'bankBalance'    => $openingBalance['bank_balance'],
                    'totalIn'        => $totalIn,
                    'totalOut'       => $totalOut,
                ];

                return $this->jsonService->sendResponse(true, $responseData, 'Transaction created successfully', ResponseCode::CREATED);
            }
        } catch (\Illuminate\Validation\ValidationException $e) {
            return $this->jsonService->sendResponse(false, $e->errors(), 'Validation failed', ResponseCode::UNPROCESSABLE_ENTITY);
        } catch (\Exception $e) {
            return $this->jsonService->sendResponse(false, null, 'Error saving transaction: ' . $e->getMessage(), ResponseCode::INTERNAL_SERVER_ERROR);
        }
    }

    public function delete($id)
    {
        try {
            $transaction = Transaction::find($id);

            if (! $transaction) {
                return $this->jsonService->sendResponse(false, null, 'Transaction not found', ResponseCode::NOT_FOUND);
            }

            $recalcFromDate = $transaction->payment_date;
            $transaction->delete();
            $this->openingBalanceService->recalculateFrom($recalcFromDate);

            $filters        = $this->getFilter();
            $openingBalance = (new Transaction())->getOpeningBalance($filters);
            $data           = (new Transaction())->getLedgerEntries($filters);
            $totalIn        = $data->where('transaction_type', 'credit')->sum('amount');
            $totalOut       = $data->where('transaction_type', 'debit')->sum('amount');

            return $this->jsonService->sendResponse(true, [
                'openingBalance' => $openingBalance,
                'totalIn'        => $totalIn,
                'totalOut'       => $totalOut,
            ], 'Transaction deleted successfully', ResponseCode::SUCCESS);
        } catch (\Exception $e) {
            return $this->jsonService->sendResponse(false, null, 'Error deleting transaction: ' . $e->getMessage(), ResponseCode::INTERNAL_SERVER_ERROR);
        }
    }

    public function edit($id)
    {
        try {
            $transaction = Transaction::find($id);

            if (! $transaction) {
                return $this->jsonService->sendResponse(false, null, 'Transaction not found', ResponseCode::NOT_FOUND);
            }

            return $this->jsonService->sendResponse(true, $transaction, 'Transaction retrieved successfully', ResponseCode::SUCCESS);
        } catch (\Exception $e) {
            return $this->jsonService->sendResponse(false, null, 'Error fetching transaction: ' . $e->getMessage(), ResponseCode::INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Resync all opening balances and redirect back with message
     * @return \Illuminate\Http\RedirectResponse
     */
    public function resyncBalances()
    {
        try {
            $result = $this->openingBalanceService->recalculateAll();

            if ($result['success']) {
                return redirect()->route('transactions.index')->with('status', $result['message']);
            } else {
                return redirect()->route('transactions.index')->with('error', $result['message']);
            }
        } catch (\Exception $e) {
            return redirect()->route('transactions.index')->with('error', 'Error resyncing balances: ' . $e->getMessage());
        }
    }
}
