<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\DayOpeningBalance;
use App\Models\Expense;
use App\Models\Invoice;
use App\Models\Purchase;
use App\Models\InvoiceItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Barryvdh\DomPDF\Facade\Pdf;

class ReportController extends Controller
{
    protected function purchaseReportDataset(Request $request, bool $paginate = true): array
    {
        $range = $this->resolvePeriodRange($request, 'thismonth');
        $search = trim((string) $request->input('search', ''));
        $status = (string) $request->input('status', '');
        $perPage = max((int) $request->input('per_page', 15), 1);

        $query = Purchase::query()
            ->where('deleted', 0)
            ->when($range['start'] && $range['end'], function ($query) use ($range) {
                $query->whereBetween('purchase_date', [$range['start'], $range['end']]);
            })
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($innerQuery) use ($search) {
                    $innerQuery->where('imei', 'like', "%{$search}%")
                        ->orWhere('model', 'like', "%{$search}%")
                        ->orWhere('purchase_from', 'like', "%{$search}%")
                        ->orWhere('contactno', 'like', "%{$search}%")
                        ->orWhere('remark', 'like', "%{$search}%");
                });
            })
            ->when($status === 'sold', function ($query) {
                $query->where('is_sold', 1);
            })
            ->when($status === 'available', function ($query) {
                $query->where('is_sold', 0);
            })
            ->orderBy('purchase_date', 'desc')
            ->orderBy('created_at', 'desc');

        $summaryRows = (clone $query)->get();

        return [
            'purchases' => $paginate ? $query->paginate($perPage)->appends($request->query()) : $query->get(),
            'period' => $range['period'],
            'fromdate' => $range['fromdate'],
            'todate' => $range['todate'],
            'timePeriod' => $range['timePeriod'],
            'search' => $search,
            'status' => $status,
            'totalItems' => $summaryRows->count(),
            'totalPurchaseAmount' => (float) $summaryRows->sum('purchase_cost'),
            'totalRepairingAmount' => (float) $summaryRows->sum('repairing_charge'),
            'totalStockValue' => (float) $summaryRows->sum('purchase_price'),
            'soldItems' => (int) $summaryRows->where('is_sold', 1)->count(),
            'availableItems' => (int) $summaryRows->where('is_sold', 0)->count(),
        ];
    }

    protected function purchaseReportFilename(string $extension): string
    {
        return 'purchase-report-' . now()->format('Ymd-His') . '.' . $extension;
    }

    protected function resolvePeriodRange(Request $request, string $defaultPeriod = 'thismonth'): array
    {
        $period = $request->input('period', $defaultPeriod);
        $fromDate = $request->input('fromdate');
        $toDate = $request->input('todate');
        $start = null;
        $end = null;
        $timePeriod = 'All Time';

        if ($period === 'today') {
            $start = Carbon::today()->toDateString();
            $end = Carbon::today()->toDateString();
            $timePeriod = 'Today (' . Carbon::today()->format('d M Y') . ')';
        } elseif ($period === 'week') {
            $start = Carbon::now()->startOfWeek()->toDateString();
            $end = Carbon::now()->toDateString();
            $timePeriod = Carbon::parse($start)->format('d M Y') . ' - ' . Carbon::parse($end)->format('d M Y');
        } elseif ($period === 'quarter') {
            $start = Carbon::now()->startOfQuarter()->toDateString();
            $end = Carbon::now()->toDateString();
            $timePeriod = 'Q' . Carbon::now()->quarter . ' ' . Carbon::now()->format('Y');
        } elseif ($period === 'month' || $period === 'thismonth') {
            $start = Carbon::now()->startOfMonth()->toDateString();
            $end = Carbon::now()->toDateString();
            $timePeriod = Carbon::now()->format('F Y');
        } elseif ($period === 'lastmonth') {
            $start = Carbon::now()->subMonth()->startOfMonth()->toDateString();
            $end = Carbon::now()->subMonth()->endOfMonth()->toDateString();
            $timePeriod = Carbon::now()->subMonth()->format('F Y');
        } elseif ($period === 'year' || $period === 'thisyear') {
            $start = Carbon::now()->startOfYear()->toDateString();
            $end = Carbon::now()->toDateString();
            $timePeriod = Carbon::now()->format('Y');
        } elseif ($period === 'lastyear') {
            $start = Carbon::now()->subYear()->startOfYear()->toDateString();
            $end = Carbon::now()->subYear()->endOfYear()->toDateString();
            $timePeriod = Carbon::now()->subYear()->format('Y');
        } elseif ($period === 'custom' && $fromDate && $toDate) {
            $start = Carbon::parse($fromDate)->toDateString();
            $end = Carbon::parse($toDate)->toDateString();
            $timePeriod = Carbon::parse($start)->format('d M Y') . ' - ' . Carbon::parse($end)->format('d M Y');
        } elseif ($period === 'alls') {
            $timePeriod = 'All Time';
        } else {
            $period = $defaultPeriod;
            $start = Carbon::now()->startOfMonth()->toDateString();
            $end = Carbon::now()->toDateString();
            $timePeriod = Carbon::now()->format('F Y');
        }

        return [
            'period' => $period,
            'fromdate' => $fromDate,
            'todate' => $toDate,
            'start' => $start,
            'end' => $end,
            'timePeriod' => $timePeriod,
        ];
    }

    public function dailyClosing(Request $request)
    {
        $selectedDate = $request->filled('date')
            ? Carbon::parse($request->input('date'))->toDateString()
            : Carbon::today()->toDateString();

        $openingBalance = DayOpeningBalance::whereDate('date', $selectedDate)->first()
            ?? DayOpeningBalance::whereDate('date', '<', $selectedDate)->latest('date')->first();

        $openingCash = (float) ($openingBalance->cash_balance ?? $openingBalance->balance ?? 0);
        $openingBank = (float) ($openingBalance->bank_balance ?? 0);

        $invoices = Invoice::with('items')
            ->where('deleted', 0)
            ->whereDate('invoice_date', $selectedDate)
            ->orderBy('invoice_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        $cashSales = (float) $invoices->where('payment_type', 'Cash')->sum('net_amount');
        $onlineSales = (float) $invoices->where('payment_type', 'Online')->sum('net_amount');
        $cardSales = (float) $invoices->where('payment_type', 'Credit Card')->sum('net_amount');
        $totalSales = (float) $invoices->sum('net_amount');
        $grossProfit = (float) $invoices->sum(function ($invoice) {
            return $invoice->items->where('deleted', 0)->sum('profit');
        });
        $itemsSold = (int) $invoices->sum(function ($invoice) {
            return $invoice->items->where('deleted', 0)->sum('quantity');
        });

        $expenses = Expense::where('deleted', 0)
            ->whereDate('entrydate', $selectedDate)
            ->orderBy('created_at', 'desc')
            ->get();

        $totalExpense = (float) $expenses->sum('amount');
        $netProfit = $grossProfit - $totalExpense;
        $closingCash = $openingCash + $cashSales - $totalExpense;
        $closingBank = $openingBank + $onlineSales + $cardSales;
        $closingBalance = $closingCash + $closingBank;

        return view('reports.daily-closing', [
            'selectedDate' => $selectedDate,
            'invoiceCount' => $invoices->count(),
            'itemsSold' => $itemsSold,
            'cashSales' => $cashSales,
            'onlineSales' => $onlineSales,
            'cardSales' => $cardSales,
            'totalSales' => $totalSales,
            'grossProfit' => $grossProfit,
            'totalExpense' => $totalExpense,
            'netProfit' => $netProfit,
            'openingCash' => $openingCash,
            'openingBank' => $openingBank,
            'openingBalance' => $openingCash + $openingBank,
            'closingCash' => $closingCash,
            'closingBank' => $closingBank,
            'closingBalance' => $closingBalance,
            'expenses' => $expenses,
            'invoices' => $invoices,
        ]);
    }

    public function profitLoss(Request $request)
    {
        $range = $this->resolvePeriodRange($request);

        $invoiceQuery = Invoice::with(['items' => function ($query) {
            $query->where('deleted', 0);
        }])->where('deleted', 0);
        $expenseQuery = Expense::where('deleted', 0);
        $purchaseQuery = Purchase::where('deleted', 0);

        if ($range['start'] && $range['end']) {
            $invoiceQuery->whereBetween('invoice_date', [$range['start'], $range['end']]);
            $expenseQuery->whereBetween('entrydate', [$range['start'], $range['end']]);
            $purchaseQuery->whereBetween('purchase_date', [$range['start'], $range['end']]);
        }

        $invoices = $invoiceQuery
            ->orderBy('invoice_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        $expenses = $expenseQuery
            ->orderBy('entrydate', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        $purchases = $purchaseQuery
            ->orderBy('purchase_date', 'desc')
            ->orderBy('created_at', 'desc')
            ->get();

        $totalRevenue = (float) $invoices->sum('net_amount');
        $grossProfit = (float) $invoices->sum(function ($invoice) {
            return $invoice->items->sum('profit');
        });
        $totalExpenses = (float) $expenses->sum('amount');
        $purchaseSpend = (float) $purchases->sum('purchase_cost');
        $netProfit = $grossProfit - $totalExpenses;
        $grossMargin = $totalRevenue > 0 ? ($grossProfit / $totalRevenue) * 100 : 0;
        $netMargin = $totalRevenue > 0 ? ($netProfit / $totalRevenue) * 100 : 0;

        $expenseBreakdown = $expenses
            ->groupBy(function ($expense) {
                return $expense->expense_name ?: ($expense->title ?: 'Other Expense');
            })
            ->map(function ($group, $label) {
                return [
                    'label' => $label,
                    'count' => $group->count(),
                    'amount' => (float) $group->sum('amount'),
                ];
            })
            ->sortByDesc('amount')
            ->values()
            ->take(8);

        $bucketFormat = 'Y-m-d';
        if ($range['start'] && $range['end']) {
            $diffInDays = Carbon::parse($range['start'])->diffInDays(Carbon::parse($range['end']));
            if ($diffInDays > 62) {
                $bucketFormat = 'Y-m';
            }
        } elseif ($range['period'] === 'alls') {
            $bucketFormat = 'Y-m';
        }

        $statementMap = [];

        foreach ($invoices as $invoice) {
            $key = Carbon::parse($invoice->invoice_date)->format($bucketFormat);
            $statementMap[$key] = $statementMap[$key] ?? ['revenue' => 0, 'gross_profit' => 0, 'expenses' => 0, 'purchase_spend' => 0];
            $statementMap[$key]['revenue'] += (float) $invoice->net_amount;
            $statementMap[$key]['gross_profit'] += (float) $invoice->items->sum('profit');
        }

        foreach ($expenses as $expense) {
            $key = Carbon::parse($expense->entrydate)->format($bucketFormat);
            $statementMap[$key] = $statementMap[$key] ?? ['revenue' => 0, 'gross_profit' => 0, 'expenses' => 0, 'purchase_spend' => 0];
            $statementMap[$key]['expenses'] += (float) $expense->amount;
        }

        foreach ($purchases as $purchase) {
            $key = Carbon::parse($purchase->purchase_date)->format($bucketFormat);
            $statementMap[$key] = $statementMap[$key] ?? ['revenue' => 0, 'gross_profit' => 0, 'expenses' => 0, 'purchase_spend' => 0];
            $statementMap[$key]['purchase_spend'] += (float) $purchase->purchase_cost;
        }

        $statementRows = collect($statementMap)
            ->map(function ($row, $key) use ($bucketFormat) {
                $label = $bucketFormat === 'Y-m'
                    ? Carbon::createFromFormat('Y-m', $key)->format('M Y')
                    : Carbon::createFromFormat('Y-m-d', $key)->format('d M Y');

                $row['label'] = $label;
                $row['net_profit'] = $row['gross_profit'] - $row['expenses'];

                return $row;
            })
            ->sortBy(function ($row, $key) {
                return $key;
            })
            ->values();

        return view('reports.profit-loss', [
            'period' => $range['period'],
            'fromdate' => $range['fromdate'],
            'todate' => $range['todate'],
            'timePeriod' => $range['timePeriod'],
            'totalRevenue' => $totalRevenue,
            'grossProfit' => $grossProfit,
            'totalExpenses' => $totalExpenses,
            'purchaseSpend' => $purchaseSpend,
            'netProfit' => $netProfit,
            'grossMargin' => $grossMargin,
            'netMargin' => $netMargin,
            'invoiceCount' => $invoices->count(),
            'expenseCount' => $expenses->count(),
            'purchaseCount' => $purchases->count(),
            'expenseBreakdown' => $expenseBreakdown,
            'statementRows' => $statementRows,
        ]);
    }

    public function sale(Request $request)
    {
        $allSales = Invoice::where('deleted', 0)->orderBy('invoice_date', 'desc')->get();
        $period = $request->input('period');
        $totalSalesAmount = $totalProfitAmount = 0;
        $fromDate = $toDate = '';
        if ($period === 'thismonth') {
            $startOfMonth = Carbon::now()->startOfMonth();
            $endOfMonth = Carbon::now();  // today's date)
            $allSales = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])
                ->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = InvoiceItem::whereHas('invoice', function ($query) use ($startOfMonth, $endOfMonth) {
                $query->whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        } elseif ($period === 'lastmonth') {
            $lastMonthStart = Carbon::now()->subMonth()->startOfMonth();
            $lastMonthEnd = Carbon::now()->subMonth()->endOfMonth();  // today's date)
            $allSales = Invoice::whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd])
                ->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = InvoiceItem::whereHas('invoice', function ($query) use ($lastMonthStart, $lastMonthEnd) {
                $query->whereBetween('invoice_date', [$lastMonthStart, $lastMonthEnd]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$lastMonthStart, $lastMonthEnd])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->subMonth()->format('F');
        } elseif ($period === 'thisyear') {
            $startOfYear = Carbon::now()->startOfYear();
            $endOfYear = Carbon::now();  // today's date)
            $allSales = Invoice::whereBetween('invoice_date', [$startOfYear, $endOfYear])
                ->where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [$startOfYear, $endOfYear])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = InvoiceItem::whereHas('invoice', function ($query) use ($startOfYear, $endOfYear) {
                $query->whereBetween('invoice_date', [$startOfYear, $endOfYear]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$startOfYear, $endOfYear])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('Y');
        } elseif ($period === 'lastyear') {
            $startOfLastYear = Carbon::now()->subYear()->startOfYear();
            $endOfLastYear = Carbon::now()->subYear()->endOfYear();
            $allSales = Invoice::whereBetween('invoice_date', [$startOfLastYear, $endOfLastYear])
                ->where('deleted', 0)
                ->orderBy('created_at', 'asc')->paginate(15);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [$startOfLastYear, $endOfLastYear])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = InvoiceItem::whereHas('invoice', function ($query) use ($startOfLastYear, $endOfLastYear) {
                $query->whereBetween('invoice_date', [$startOfLastYear, $endOfLastYear]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$startOfLastYear, $endOfLastYear])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->subYear()->format('Y');
        } elseif ($period === 'custom') {
            $fromDate = $request->input('fromdate');
            $toDate = $request->input('todate');
            $allSales = Invoice::whereBetween('invoice_date', [$fromDate, $toDate])->where('deleted', 0)->orderBy('created_at', 'desc')->paginate(15);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [$fromDate, $toDate])->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = InvoiceItem::whereHas('invoice', function ($query) use ($fromDate, $toDate) {
                $query->whereBetween('invoice_date', [$fromDate, $toDate]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [$fromDate, $toDate])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        } elseif ($period === 'alls') {
            $allSales = Invoice::where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()])
                ->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = InvoiceItem::whereHas('invoice', function ($query) {
                $query->whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        } else {
            $allSales = Invoice::where('deleted', 0)
                ->orderBy('created_at', 'desc')->paginate(10);
            $totalSalesAmount = Invoice::whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()])
                ->where('deleted', 0)->sum('net_amount');
            $totalProfitAmount = InvoiceItem::whereHas('invoice', function ($query) {
                $query->whereBetween('invoice_date', [Carbon::now()->startOfMonth(), Carbon::now()]);
            })->where('deleted', 0)->sum('profit');
            $totalExpenseAmount = Expense::whereBetween('entrydate', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
            $timePeriod = Carbon::now()->format('F');
        }

        return view('reports.sales', [
            'allSales' => $allSales,
            'period' => $period,
            'totalSalesAmount' => number_format((float) $totalSalesAmount, 2, '.', ''),
            'totalProfitAmount' => number_format((float) $totalProfitAmount, 2, '.', ''),
            'fromdate' => $fromDate,
            'todate' => $toDate,
            'totalItems' => $allSales->total(),
            'currentMonth' => Carbon::now()->format('F'),
            'timePeriod' => $timePeriod,
            'totalExpenseAmount' => number_format((float) $totalExpenseAmount, 2, '.', ''),
        ]);
    }

    /**
     * Download sales records using route(sale-export)
     */
    public function downloadExcel(Request $request)
    {
        $period = $request->input('period');
        $monthName = Carbon::now()->format('F');

        // Get sales data based on the selected period
        if ($period === 'thismonth') {
            $monthName = Carbon::now()->format('F');
            $start = Carbon::now()->startOfMonth();
            $end = Carbon::now();
        } elseif ($period === 'lastmonth') {
            $monthName = Carbon::now()->subMonth()->format('F');
            $start = Carbon::now()->subMonth()->startOfMonth();
            $end = Carbon::now()->subMonth()->endOfMonth();
        } elseif ($period === 'thisyear') {
            $monthName = Carbon::now()->format('Y');
            $start = Carbon::now()->startOfYear();
            $end = Carbon::now();
        } elseif ($period === 'custom') {
            $from = $request->input('fromdate');
            $to = $request->input('todate');
            $monthName = Carbon::parse($from)->format('d-M') . '_to_' . Carbon::parse($to)->format('d-M');
            $start = $from;
            $end = $to;
        } else {
            $start = null;
            $end = null;
        }

        // Query invoices with relationships eager loaded
        $query = Invoice::with(['items.purchase'])->where('deleted', 0);

        if ($start && $end) {
            $query->whereBetween('invoice_date', [$start, $end]);
        }

        $salesReport = $query->orderBy('created_at', 'asc')->get();

        // Prepare CSV headers
        $fileName = $monthName . '-sales.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=$fileName",
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];

        // CSV callback generator
        $callback = function () use ($salesReport) {
            $file = fopen('php://output', 'w+');

            // CSV header
            fputcsv($file, [
                'Sr No',
                'Invoice No.',
                'Invoice Date',
                'IMEI',
                'Model',
                'Storage (GB)',
                'Color',
                'Customer Name',
                'Mobile No.',
                'Sell Price',
                'Profit',
                'Payment Mode',
            ], ';');

            $count = 1;

            foreach ($salesReport as $invoice) {
                foreach ($invoice->items as $item) {
                    $purchase = $item->purchase; // Purchase related to this item

                    fputcsv($file, [
                        $count++,
                        $invoice->invoice_no,
                        $invoice->invoice_date ? Carbon::parse($invoice->invoice_date)->format('d-m-Y') : '',
                        $purchase->imei ?? '',
                        $purchase->model ?? '',
                        $purchase->storage ?? '',
                        $purchase->color ?? '',
                        $invoice->customer_name ?? '',
                        $invoice->customer_no ?? '',
                        $item->unit_price ?? 0, // prefer per-item price if available
                        $item->profit ?? 0,
                        $invoice->payment_type ?? '',
                    ], ';');
                }
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    public function downloadSalesPdf(Request $request)
    {
        $period = $request->input('period');
        $fromDate = $request->input('fromdate');
        $toDate = $request->input('todate');

        $query = Invoice::with(['items.purchase'])->where('deleted', 0)->orderBy('invoice_date', 'asc');
        $timePeriod = 'All Sales';

        if ($period === 'thismonth') {
            $start = Carbon::now()->startOfMonth();
            $end = Carbon::now();
            $query->whereBetween('invoice_date', [$start, $end]);
            $timePeriod = Carbon::now()->format('F');
        } elseif ($period === 'lastmonth') {
            $start = Carbon::now()->subMonth()->startOfMonth();
            $end = Carbon::now()->subMonth()->endOfMonth();
            $query->whereBetween('invoice_date', [$start, $end]);
            $timePeriod = Carbon::now()->subMonth()->format('F');
        } elseif ($period === 'thisyear') {
            $start = Carbon::now()->startOfYear();
            $end = Carbon::now();
            $query->whereBetween('invoice_date', [$start, $end]);
            $timePeriod = Carbon::now()->format('Y');
        } elseif ($period === 'lastyear') {
            $start = Carbon::now()->subYear()->startOfYear();
            $end = Carbon::now()->subYear()->endOfYear();
            $query->whereBetween('invoice_date', [$start, $end]);
            $timePeriod = Carbon::now()->subYear()->format('Y');
        } elseif ($period === 'custom' && $fromDate && $toDate) {
            $query->whereBetween('invoice_date', [$fromDate, $toDate]);
            $timePeriod = Carbon::parse($fromDate)->format('d M Y') . ' - ' . Carbon::parse($toDate)->format('d M Y');
        }

        $allSales = $query->get();

        $totalSalesAmount = (float) $allSales->sum('net_amount');
        $invoiceIds = $allSales->pluck('id');
        $totalProfitAmount = (float) InvoiceItem::whereIn('invoice_id', $invoiceIds)->where('deleted', 0)->sum('profit');

        if ($period === 'custom' && $fromDate && $toDate) {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [$fromDate, $toDate])->where('deleted', 0)->sum('amount');
        } elseif ($period === 'lastmonth') {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [Carbon::now()->subMonth()->startOfMonth(), Carbon::now()->subMonth()->endOfMonth()])->where('deleted', 0)->sum('amount');
        } elseif ($period === 'thisyear') {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [Carbon::now()->startOfYear(), Carbon::now()])->where('deleted', 0)->sum('amount');
        } elseif ($period === 'lastyear') {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [Carbon::now()->subYear()->startOfYear(), Carbon::now()->subYear()->endOfYear()])->where('deleted', 0)->sum('amount');
        } else {
            $totalExpenseAmount = (float) Expense::whereBetween('entrydate', [Carbon::now()->startOfMonth(), Carbon::now()])->where('deleted', 0)->sum('amount');
        }

        $pdf = Pdf::loadView('reports.sales-pdf', [
            'allSales' => $allSales,
            'timePeriod' => $timePeriod,
            'totalSalesAmount' => $totalSalesAmount,
            'totalProfitAmount' => $totalProfitAmount,
            'totalExpenseAmount' => $totalExpenseAmount,
        ])->setPaper('a4', 'landscape');

        return $pdf->download('sales-report-' . now()->format('Ymd-His') . '.pdf');
    }

    public function downloadPurchaseExcel(Request $request)
    {
        $report = $this->purchaseReportDataset($request, false);
        $allPurchases = $report['purchases'];
        $fileName = $this->purchaseReportFilename('csv');
        $headers = [
            'Content-type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=$fileName",
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];
        $callback = function () use ($allPurchases): void {
            $file = fopen('php://output', 'w+');

            fputcsv($file, ['Sr No', 'Purchase Date', 'IMEI', 'Model', 'Storage', 'Color', 'Supplier', 'Mobile No', 'Buy Cost', 'Repairing', 'Stock Value', 'Sell Date', 'Status', 'Remark']);

            foreach ($allPurchases as $index => $row) {
                fputcsv($file, [
                    $index + 1,
                    Carbon::parse($row->purchase_date)->format('d/m/Y'),
                    (string) $row->imei,
                    $row->model,
                    $row->storage,
                    $row->color,
                    $row->purchase_from,
                    $row->contactno,
                    $row->purchase_cost,
                    $row->repairing_charge ?: 0,
                    $row->purchase_price,
                    ($row->sell_date) ? Carbon::parse($row->sell_date)->format('d/m/Y') : '',
                    ($row->is_sold == 1) ? 'Yes' : 'No',
                    $row->remark,
                ]);
            }

            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }

    public function downloadPurchaseReport(Request $request)
    {
        $report = $this->purchaseReportDataset($request);

        return view('reports.purchase', [
            'allPurchased' => $report['purchases'],
            'period' => $report['period'],
            'fromdate' => $report['fromdate'],
            'todate' => $report['todate'],
            'timePeriod' => $report['timePeriod'],
            'search' => $report['search'],
            'status' => $report['status'],
            'totalItems' => $report['totalItems'],
            'totalPurchaseAmount' => $report['totalPurchaseAmount'],
            'totalRepairingAmount' => $report['totalRepairingAmount'],
            'totalStockValue' => $report['totalStockValue'],
            'soldItems' => $report['soldItems'],
            'availableItems' => $report['availableItems'],
        ]);
    }

    public function downloadPurchasePdf(Request $request)
    {
        $report = $this->purchaseReportDataset($request, false);

        $pdf = Pdf::loadView('reports.purchase-pdf', [
            'allPurchased' => $report['purchases'],
            'timePeriod' => $report['timePeriod'],
            'search' => $report['search'],
            'status' => $report['status'],
            'totalItems' => $report['totalItems'],
            'totalPurchaseAmount' => $report['totalPurchaseAmount'],
            'totalRepairingAmount' => $report['totalRepairingAmount'],
            'totalStockValue' => $report['totalStockValue'],
            'soldItems' => $report['soldItems'],
            'availableItems' => $report['availableItems'],
        ])->setPaper('a4', 'landscape');

        return $pdf->download($this->purchaseReportFilename('pdf'));
    }

    /**
     * display Sales & profit Charts
     */
    public function displayCharts()
    {
        $startOfMonth = Carbon::now()->startOfMonth();
        $endOfMonth = Carbon::now();
        $allSales = Invoice::with('items')
            ->whereBetween('invoice_date', [$startOfMonth, $endOfMonth])
            ->where('deleted', 0)
            ->orderBy('invoice_date', 'asc')
            ->get();

        $dailySales = $allSales
            ->groupBy(fn ($invoice) => Carbon::parse($invoice->invoice_date)->format('Y-m-d'))
            ->map(fn ($group) => round((float) $group->sum('net_amount'), 2));

        $dailyProfit = $allSales
            ->groupBy(fn ($invoice) => Carbon::parse($invoice->invoice_date)->format('Y-m-d'))
            ->map(function ($group) {
                return round((float) $group->sum(function ($invoice) {
                    return $invoice->items->sum('profit');
                }), 2);
            });

        $paymentModeData = $allSales
            ->groupBy(fn ($invoice) => $invoice->payment_type ?: 'Unknown')
            ->map(fn ($group) => $group->count());

        $dailyInvoiceCounts = $allSales
            ->groupBy(fn ($invoice) => Carbon::parse($invoice->invoice_date)->format('Y-m-d'))
            ->map(fn ($group) => $group->count());

        $topCustomers = $allSales
            ->groupBy(fn ($invoice) => $invoice->customer_name ?: 'Walk-in Customer')
            ->map(fn ($group) => round((float) $group->sum('net_amount'), 2))
            ->sortDesc()
            ->take(5);

        $totalSalesAmount = (float) $allSales->sum('net_amount');
        $totalProfitAmount = (float) $allSales->sum(function ($invoice) {
            return $invoice->items->sum('profit');
        });
        $timePeriod = Carbon::now()->format('F');
        $invoiceCount = $allSales->count();

        return view('reports.saleschart', [
            'timePeriod' => $timePeriod,
            'invoiceCount' => $invoiceCount,
            'totalSalesAmount' => $totalSalesAmount,
            'totalProfitAmount' => $totalProfitAmount,
            'dailySalesLabels' => $dailySales->keys()->values(),
            'dailySalesValues' => $dailySales->values(),
            'dailyProfitLabels' => $dailyProfit->keys()->values(),
            'dailyProfitValues' => $dailyProfit->values(),
            'paymentModeLabels' => $paymentModeData->keys()->values(),
            'paymentModeValues' => $paymentModeData->values(),
            'dailyInvoiceCountLabels' => $dailyInvoiceCounts->keys()->values(),
            'dailyInvoiceCountValues' => $dailyInvoiceCounts->values(),
            'topCustomerLabels' => $topCustomers->keys()->values(),
            'topCustomerValues' => $topCustomers->values(),
        ]);
    }

    public function customers()
    {
        $uniqueCustomers = Invoice::where('deleted', 0)
            ->select('customer_name', 'customer_no')
            ->distinct()
            ->orderBy('created_at', 'desc')->get();

        return view('reports.customers', ['customers' => $uniqueCustomers, 'totalcustomers' => $uniqueCustomers->count()]);
    }

    public function exportcustomers()
    {
        $uniqueCustomers = Invoice::where('deleted', 0)
            ->select('customer_name', 'customer_no')
            ->distinct()
            ->orderBy('created_at', 'desc')->get();
        $fileName = 'vision-customers.csv';
        $headers = [
            'Content-type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=$fileName",
            'Pragma' => 'no-cache',
            'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
            'Expires' => '0',
        ];
        $callback = function () use ($uniqueCustomers): void {
            $file = fopen('php://output', 'w+');

            // Add the CSV header (modify this based on your model)
            fputcsv($file,
                [
                    'ID',
                    'Customer Name',
                    'Contact Number',
                ],
                ';'
            );

            // Add the data rows
            foreach ($uniqueCustomers as $key => $row) {
                fputcsv($file, [
                    $key + 1,
                    $row->customer_name,
                    $row->customer_no,
                ], ';');
            }
            fclose($file);
        };

        return Response::stream($callback, 200, $headers);
    }
}
