<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Expense;
use App\Models\Invoice;
use App\Models\Party;
use App\Models\PaymentMethod;
use App\Models\Purchase;
use App\Models\Transaction;
use App\Services\OpeningBalanceService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MobileAppController extends Controller
{
    public function dashboard(Request $request): JsonResponse
    {
        $today = Carbon::today();
        $startOfMonth = Carbon::now()->startOfMonth();
        $endOfMonth = Carbon::now()->endOfDay();
        $sevenDaysAgo = Carbon::now()->subDays(7)->startOfDay();

        $recentInvoices = Invoice::query()
            ->where('deleted', 0)
            ->orderByDesc('invoice_date')
            ->limit(5)
            ->get([
                'id',
                'invoice_no',
                'customer_name',
                'invoice_date',
                'net_amount',
                'payment_type',
            ]);

        return response()->json([
            'summary' => [
                'stocks_in_hand' => Purchase::query()->where('is_sold', 0)->where('deleted', 0)->count(),
                'today_sales' => (float) Invoice::query()->whereDate('invoice_date', $today)->where('deleted', 0)->sum('net_amount'),
                'month_sales' => (float) Invoice::query()->whereBetween('invoice_date', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('net_amount'),
                'month_expenses' => (float) Expense::query()->whereBetween('entrydate', [$startOfMonth, $endOfMonth])->where('deleted', 0)->sum('amount'),
                'recent_sales_count' => Invoice::query()->whereBetween('invoice_date', [$sevenDaysAgo, $endOfMonth])->where('deleted', 0)->count(),
            ],
            'recent_invoices' => $recentInvoices,
        ]);
    }

    public function paymentMethods(): JsonResponse
    {
        return response()->json([
            'data' => PaymentMethod::query()->orderBy('id')->get(),
        ]);
    }

    public function parties(Request $request): JsonResponse
    {
        $perPage = min((int) $request->integer('per_page', 15), 100);

        $parties = Party::query()
            ->where('deleted', 0)
            ->withSum([
                'transactions as credit_total' => fn ($query) => $query->where('transaction_type', 'credit'),
            ], 'amount')
            ->withSum([
                'transactions as debit_total' => fn ($query) => $query->where('transaction_type', 'debit'),
            ], 'amount')
            ->latest()
            ->paginate($perPage);

        $parties->getCollection()->transform(function (Party $party) {
            return [
                'id' => $party->id,
                'party_name' => $party->party_name,
                'phone' => $party->phone,
                'email' => $party->email,
                'address' => $party->address,
                'party_type' => $party->party_type,
                'credit_total' => (float) ($party->credit_total ?? 0),
                'debit_total' => (float) ($party->debit_total ?? 0),
                'balance' => (float) $party->balance,
            ];
        });

        return response()->json($parties);
    }

    public function partyDetail(int $id): JsonResponse
    {
        $party = Party::query()
            ->where('deleted', 0)
            ->whereKey($id)
            ->with(['transactions' => function ($query) {
                $query->orderBy('payment_date')->orderBy('id');
            }])
            ->firstOrFail();

        $runningBalance = 0;
        $transactions = $party->transactions->map(function ($transaction) use (&$runningBalance) {
            $runningBalance += $transaction->transaction_type === 'credit'
                ? $transaction->amount
                : -$transaction->amount;

            return [
                'id' => $transaction->id,
                'payment_date' => $transaction->payment_date,
                'transaction_type' => $transaction->transaction_type,
                'payment_method' => $transaction->payment_method,
                'amount' => (float) $transaction->amount,
                'note' => $transaction->note,
                'running_balance' => (float) $runningBalance,
            ];
        })->values();

        return response()->json([
            'data' => [
                'id' => $party->id,
                'party_name' => $party->party_name,
                'phone' => $party->phone,
                'email' => $party->email,
                'address' => $party->address,
                'party_type' => $party->party_type,
                'transactions' => $transactions,
            ],
        ]);
    }

    public function invoices(Request $request): JsonResponse
    {
        $perPage = min((int) $request->integer('per_page', 15), 100);

        $invoices = Invoice::query()
            ->where('deleted', 0)
            ->orderByDesc('invoice_date')
            ->paginate($perPage);

        return response()->json($invoices);
    }

    public function invoiceDetail(int $id): JsonResponse
    {
        $invoice = Invoice::query()
            ->with(['items.purchase'])
            ->where('deleted', 0)
            ->findOrFail($id);

        return response()->json([
            'data' => $invoice,
        ]);
    }

    public function purchases(Request $request): JsonResponse
    {
        $perPage = min((int) $request->integer('per_page', 15), 100);

        $purchases = Purchase::query()
            ->where('deleted', 0)
            ->orderByDesc('purchase_date')
            ->paginate($perPage);

        return response()->json($purchases);
    }

    public function expenses(Request $request): JsonResponse
    {
        $perPage = min((int) $request->integer('per_page', 15), 100);

        $expenses = Expense::query()
            ->where('deleted', 0)
            ->orderByDesc('entrydate')
            ->paginate($perPage);

        return response()->json($expenses);
    }

    public function transactions(Request $request): JsonResponse
    {
        $filters = [
            'date_from' => $request->input('date_from'),
            'date_to' => $request->input('date_to'),
            'transaction_type' => $request->input('transaction_type'),
            'payment_method' => $request->input('payment_method'),
            'source' => $request->input('source'),
        ];

        $entries = (new Transaction())->getLedgerEntries($filters)->values();
        $openingBalance = (new Transaction())->getOpeningBalance($filters);
        $perPage = min((int) $request->integer('per_page', 20), 100);
        $page = max((int) $request->integer('page', 1), 1);

        $paginatedItems = $entries->forPage($page, $perPage)->values();

        return response()->json([
            'data' => $paginatedItems,
            'meta' => [
                'current_page' => $page,
                'per_page' => $perPage,
                'total' => $entries->count(),
                'last_page' => (int) ceil(max($entries->count(), 1) / $perPage),
            ],
            'summary' => [
                'opening_balance' => (float) ($openingBalance['balance'] ?? 0),
                'cash_balance' => (float) ($openingBalance['cash_balance'] ?? 0),
                'bank_balance' => (float) ($openingBalance['bank_balance'] ?? 0),
                'total_in' => (float) $entries->where('transaction_type', 'credit')->sum('amount'),
                'total_out' => (float) $entries->where('transaction_type', 'debit')->sum('amount'),
            ],
        ]);
    }

    public function storeTransaction(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'party_id' => ['required', 'exists:parties,id'],
            'payment_date' => ['required', 'date'],
            'transaction_type' => ['required', 'in:credit,debit'],
            'payment_method' => ['required'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'note' => ['nullable', 'string'],
        ]);

        $validated['created_by'] = $request->user()->id;

        $transaction = Transaction::create($validated);

        app(OpeningBalanceService::class)->recalculateFrom($validated['payment_date']);

        return response()->json([
            'message' => 'Transaction created successfully.',
            'data' => $transaction,
        ], 201);
    }

    public function deleteTransaction(Request $request, int $id): JsonResponse
    {
        $transaction = Transaction::query()->findOrFail($id);

        $recalculateFrom = $transaction->payment_date;
        $transaction->delete();

        app(OpeningBalanceService::class)->recalculateFrom($recalculateFrom);

        return response()->json([
            'message' => 'Transaction deleted successfully.',
        ]);
    }
}
