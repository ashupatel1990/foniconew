@extends('layout.app')

@section('title')
    Invoice #{{$invoice->invoice_no}}
@endsection
@section('content')
    <style>
        body {
            font-family: "Cerebri Sans", Arial, sans-serif;
            color: #243447;
            background: #eef3f8;
        }

        .page-container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            background: #eef3f8;
            padding: 24px 20px;
        }

        .invoice-admin-actions {
            max-width: 900px;
            margin: 0 auto 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .invoice-admin-actions__group {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .invoice-admin-actions__btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-height: 42px;
            padding: 10px 16px;
            border-radius: 10px;
            font-weight: 700;
            text-decoration: none !important;
            border: 0;
            box-shadow: 0 10px 20px rgba(15, 23, 42, 0.10);
            cursor: pointer;
        }

        .invoice-admin-actions__btn--print {
            background: #17324d;
            color: #fff;
        }

        .invoice-admin-actions__btn--back {
            background: #fff;
            color: #17324d;
            border: 1px solid #d7e1ec;
        }

        .invoice-admin-actions__btn--pdf {
            background: #ef4444;
            color: #fff;
        }

        .invoice-admin-actions__btn--wa {
            background: #25D366;
            color: #fff;
        }

        .invoice-admin-actions__btn:hover {
            opacity: 0.92;
            color: inherit;
        }

        .invoice-box {
            max-width: 900px;
            margin: auto;
            padding: 30px 32px;
            border: 1px solid #dde7f0;
            box-shadow: 0 22px 45px rgba(15, 23, 42, 0.10);
            background: #fff;
            border-radius: 18px;
        }

        .invoice-box h2 {
            text-align: center;
            margin-bottom: 28px;
            color: #17324d;
            letter-spacing: 2px;
            font-size: 22px;
            font-weight: 800;
        }

        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 18px;
            padding-bottom: 18px;
            border-bottom: 1px solid #dbe6ef;
            margin-bottom: 20px;
        }

        .company-block {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .company-logo {
            max-height: 50px;
            margin-bottom: 10px;
            border-radius: 4px;
        }

        .company-address p {
            margin: 0;
            font-size: 13px;
            line-height: 21px;
            color: #516173;
        }

        .invoice-details {
            background: #f7fafc;
            padding: 14px 18px;
            border-radius: 14px;
            border: 1px solid #e3ebf3;
            font-size: 14px;
            line-height: 22px;
            min-width: 220px;
            box-shadow: 0 8px 18px rgba(15, 23, 42, 0.04);
        }

        .invoice-details p {
            margin: 4px 0;
        }

        .invoice-details b {
            color: #17324d;
        }

        .bill-to-box {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 16px;
            padding: 16px 18px;
            margin-bottom: 18px;
            border-radius: 16px;
            background: #f7fafc;
            border: 1px solid #e5edf5;
        }

        .bill-to-box__label {
            color: #7b8798;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 8px;
        }

        .bill-to-box__name {
            color: #17324d;
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .bill-to-box__meta {
            color: #516173;
            font-size: 14px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th {
            background: #17324d;
            color: #fff;
            padding: 12px 10px;
            text-align: center;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
        }

        table td {
            border: 1px solid #e6edf5;
            padding: 12px 12px;
            font-size: 14px;
        }

        table tr:nth-child(even) {
            background: #fbfdff;
        }

        .totals td {
            text-align: right;
            font-weight: bold;
            background: #f7fafc;
        }

        .item-particulars {
            line-height: 1.55;
            color: #2c3e50;
        }

        .item-particulars small {
            color: #607086;
            font-size: 12px;
        }

        .net-total-row td {
            background: #17324d;
            color: #fff;
            border-color: #17324d;
        }

        .amount-words {
            padding: 14px 16px;
            background: #f7fafc;
            font-weight: bold;
            margin-bottom: 20px;
            border-left: 4px solid #17324d;
            border-radius: 10px;
            font-size: 14px;
        }

        .footer {
            text-align: center;
            font-weight: 700;
            margin-top: 32px;
            font-size: 14px;
            color: #516173;
        }

        .thanks-text {
            text-align: center;
            font-weight: 700;
            font-size: 15px;
            margin-top: 25px;
            margin-bottom: 10px;
            color: #17324d;
        }


        /* ---------- PRINT FIXES ---------- */
        @media print {
            @page {
                size: A4;
                margin: 10mm; /* give clean page margins */
            }

            body {
                -webkit-print-color-adjust: exact !important;
                color-adjust: exact !important;
                margin: 0;
                background: #fff !important;
            }

            .page-container {
                /* display: block !important; */
                /* padding: 0 !important; */
                background: #fff !important;
                /* min-height: auto !important; */
            }

            .invoice-box {
                /* margin: 0 auto !important; */
                /* box-shadow: none !important; */
                border: none !important;
                /* border-radius: 0 !important; */
                /* width: 100% !important; */
                /* padding: 10mm; controlled padding inside */
            }

            .invoice-details,
            table th,
            .amount-words,
            .net-total-row td {
                -webkit-print-color-adjust: exact !important;
                color-adjust: exact !important;
            }

            .thanks-text {
                margin-top: 15px !important;
            }

            .no-print {
                display: none !important;
            }
        }
    </style>

    <div class="page-container">
        <div style="width: 100%;">
            <div class="invoice-admin-actions no-print">
                <div class="invoice-admin-actions__group">
                    <button type="button" class="invoice-admin-actions__btn invoice-admin-actions__btn--back"
                        onclick="window.history.back()">
                        <i class="mdi mdi-arrow-left"></i>
                        <span>Back</span>
                    </button>
                </div>

                <div class="invoice-admin-actions__group">
                    <button type="button" class="invoice-admin-actions__btn invoice-admin-actions__btn--print"
                        onclick="window.print()">
                        <i class="mdi mdi-printer"></i>
                        <span>Print</span>
                    </button>

                    <a href="{{ route('download-pdf', $invoice->id) }}"
                        class="invoice-admin-actions__btn invoice-admin-actions__btn--pdf">
                        <i class="mdi mdi-file-pdf-box"></i>
                        <span>Download</span>
                    </a>

                    @if($invoice->customer_no)
                        <a href="{{ route('send-whatsapp', ['id' => $invoice->id]) }}" target="_blank"
                            class="invoice-admin-actions__btn invoice-admin-actions__btn--wa">
                            <i class="mdi mdi-whatsapp"></i>
                            <span>WhatsApp</span>
                        </a>
                    @endif
                </div>
            </div>

        <div class="invoice-box">
            <h2>RECEIPT</h2>

            <div class="invoice-header">
                <!-- Left Side (Logo + Address) -->
                <div class="company-block">
                    <img src="{{asset('assets/images/new_logo/fonico_mobiles.jpg')}}" alt="Logo" class="company-logo">
                    <div class="company-address">
                        <p>
                            Bodakdev, Ahmedabad - 380054<br>
                            <b>Mo:</b> +91 99934 76489
                        </p>
                    </div>
                </div>

                <!-- Right Side (Invoice Details) -->
                <div class="invoice-details">
                    <p><b>Receipt No:</b> #{{ $invoice->invoice_no }}</p>
                    <p><b>Date:</b> {{ date("d/m/Y", strtotime($invoice->invoice_date)) }}</p>
                </div>
            </div>

            <div class="bill-to-box">
                <div>
                    <div class="bill-to-box__label">Bill To</div>
                    <div class="bill-to-box__name">{{ $invoice->customer_name }}</div>
                    <div class="bill-to-box__meta">
                        @if($invoice->customer_no)
                            Mobile: {{ $invoice->customer_no }}
                        @else
                            Mobile: N/A
                        @endif
                    </div>
                </div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Particulars</th>
                        <th>Qty</th>
                        <th>Rate</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($invoice->items as $index => $item)
                        <tr>
                            <td align="center">{{ $index + 1 }}</td>
                            <td class="item-particulars">
                                @php echo nl2br($item->item_description) @endphp
                                <!-- @if($item->purchase && $item->purchase->imei)
                                    <br><small><b>IMEI:</b> {{ $item->purchase->imei }}</small>
                                @endif -->
                                @if($item->warranty_expiry_date)
                                    <br><small><b>Warranty:</b> {{ date("d/m/Y", strtotime($item->warranty_expiry_date)) }}</small>
                                @endif
                            </td>
                            <td align="center">{{ $item->quantity }}</td>
                            <td align="right">₹{{ number_format($item->unit_price, 2) }}</td>
                            <td align="right">₹{{ number_format($item->total_amount, 2) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            <table>
                <tbody>
                    <tr class="totals">
                        <td colspan="4">Total</td>
                        <td>₹{{ number_format($invoice->total_amount, 2) }}</td>
                    </tr>
                    @if($invoice->cgst_amount)
                        <tr>
                            <td colspan="4" align="right">CGST ({{$invoice->cgst_rate}}%)</td>
                            <td align="right">₹{{ number_format($invoice->cgst_amount, 2) }}</td>
                        </tr>
                    @endif
                    @if($invoice->sgst_amount)
                        <tr>
                            <td colspan="4" align="right">SGST ({{$invoice->sgst_rate}}%)</td>
                            <td align="right">₹{{ number_format($invoice->sgst_amount, 2) }}</td>
                        </tr>
                    @endif
                    @if($invoice->igst_amount)
                        <tr>
                            <td colspan="4" align="right">IGST ({{$invoice->igst_rate}}%)</td>
                            <td align="right">₹{{ number_format($invoice->igst_amount, 2) }}</td>
                        </tr>
                    @endif
                    @if($invoice->discount)
                        <tr>
                            <td colspan="4" align="right">Discount</td>
                            <td align="right">₹{{ number_format($invoice->discount, 2) }}</td>
                        </tr>
                    @endif
                    <tr class="totals net-total-row">
                        <td colspan="4">Net Total</td>
                        <td>₹{{ number_format($invoice->net_amount, 2) }}</td>
                    </tr>
                </tbody>
            </table>

            <div class="amount-words">
                Amount (in words): {{ $amountInWords }}
            </div>

            <div class="terms-image" style="margin-top: 10px; border-top: 2px solid #0986c6; padding-top: 10px;">
                <img src="{{ asset('assets/images/terms.png') }}" alt="Terms & Conditions" style="width: 100%; max-width: 100%;">
            </div>

            <!-- <div class="gst-notes">
                <h4>GST & HSN Notes</h4>
                <ul>
                    <li>GST on Refurbished mobile phone (HSN Code 8517) and Refurbished Laptop / Desktop (HSN Code: 8471) has been
                        charged under the margin scheme of GST.</li>
                    <li>For HSN code: 8517 (Refurbished Mobile phones) and HSN Code: 8471 (Refurbished Laptop / Desktop), value of
                        supply is determined in accordance with Section 15(5) of the Central Goods and Services Tax Act read with
                        Rule 32(5) of “Determination of the value of supply”. The credit for GST input shall not be available to the
                        buyer if buyer follows the same valuation rule.</li>
                    <li>For HSN code 8517 (other than refurbished Mobile), GST is charged as per the prescribed rate on the full
                        value of the product, for which input credit shall be available to the registered buyer.</li>
                </ul>
            </div> -->

            <div class="thanks-text">
                ✨ Thanks for Visit! ✨
            </div>
            <div class="footer">
                Authorised Signatory<br><b>FONICO Mobile</b>
            </div>
        </div>
        </div>
    </div>

    <script>
        // window.onload = function() {
        //     window.print();
        // }
    </script>
@endsection
