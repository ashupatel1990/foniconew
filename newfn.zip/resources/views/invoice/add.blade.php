@extends('layout.app')

@section('title')
    Create Invoice
@endsection

@section('css')
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/ui-lightness/jquery-ui.css">
    <style>
        .invoice-create-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.10), transparent 26%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .invoice-create-hero {
            position: relative;
            overflow: hidden;
            border-radius: 26px;
            padding: 28px 30px;
            margin-bottom: 24px;
            background: linear-gradient(135deg, #163447 0%, #204e65 58%, #1abc9c 100%);
            box-shadow: 0 24px 50px rgba(22, 52, 71, 0.18);
            color: #fff;
        }

        .invoice-create-hero::after {
            content: "";
            position: absolute;
            right: -72px;
            bottom: -96px;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .invoice-create-hero__eyebrow {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 14px;
        }

        .invoice-create-hero__title {
            color: #fff;
            font-size: 31px;
            line-height: 1.15;
            margin-bottom: 8px;
        }

        .invoice-create-hero__subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            max-width: 560px;
            margin-bottom: 0;
        }

        .invoice-create-hero__badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 14px 18px;
            border-radius: 18px;
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(6px);
            color: #fff;
            font-weight: 700;
            font-size: 18px;
            min-width: 240px;
        }

        .invoice-create-card {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .invoice-create-card .card-body {
            padding: 26px;
        }

        .invoice-create-section + .invoice-create-section {
            margin-top: 24px;
        }

        .invoice-create-section__eyebrow {
            color: #1abc9c;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 8px;
        }

        .invoice-create-section__title {
            color: #18324b;
            font-size: 24px;
            margin-bottom: 6px;
        }

        .invoice-create-section__subtitle {
            color: #7b8798;
            margin-bottom: 18px;
        }

        .invoice-create-label {
            color: #2d4056;
            font-weight: 700;
            font-size: 13px;
            margin-bottom: 10px;
        }

        .invoice-create-label .text-danger {
            margin-left: 2px;
        }

        .invoice-create-input.form-control,
        .invoice-create-input.form-select,
        .invoice-create-input {
            min-height: 46px;
            border-radius: 12px;
            border: 1px solid #d7e1ec;
            box-shadow: none;
            font-size: 14px;
        }

        textarea.invoice-create-input {
            min-height: 110px;
            resize: vertical;
        }

        .invoice-create-input:focus {
            border-color: #1abc9c;
            box-shadow: 0 0 0 0.15rem rgba(26, 188, 156, 0.12);
        }

        .invoice-create-panel {
            border: 1px solid #e6edf5;
            border-radius: 18px;
            background: #f7fafc;
            padding: 18px;
        }

        .invoice-create-summary {
            border: 1px solid #d9e6f1;
            border-radius: 18px;
            background: linear-gradient(180deg, #ffffff 0%, #f7fafc 100%);
            padding: 18px;
            height: 100%;
        }

        .invoice-create-summary__row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 8px 0;
            color: #607086;
            font-size: 14px;
        }

        .invoice-create-summary__row strong {
            color: #17324d;
        }

        .invoice-create-summary__row--total {
            margin-top: 8px;
            padding-top: 14px;
            border-top: 1px solid #dde7f0;
            font-size: 16px;
            font-weight: 700;
        }

        .invoice-create-summary__row--total span:last-child {
            color: #169c82;
            font-size: 22px;
            font-weight: 700;
        }

        .invoice-create-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 26px;
        }

        .invoice-create-btn {
            border-radius: 12px;
            padding: 11px 18px;
            font-weight: 700;
            box-shadow: none !important;
        }

        .invoice-create-btn.btn-primary {
            background: linear-gradient(135deg, #1abc9c 0%, #128a73 100%);
            border-color: transparent;
        }

        .invoice-create-btn.btn-outline-danger {
            border-color: #d8e2ec;
            color: #607086;
        }

        .item-row {
            position: relative;
            border: 1px solid #e6edf5;
            border-radius: 18px;
            background: #fff;
            padding: 18px;
            margin-bottom: 16px;
            box-shadow: 0 12px 24px rgba(15, 23, 42, 0.04);
        }

        .item-row:hover {
            border-color: rgba(26, 188, 156, 0.35);
        }

        .item-row .form-label {
            color: #2d4056;
            font-weight: 700;
            font-size: 13px;
            margin-bottom: 10px;
        }

        .item-row .form-control {
            min-height: 44px;
            border-radius: 12px;
            border: 1px solid #d7e1ec;
            box-shadow: none;
            font-size: 14px;
        }

        .item-row textarea.form-control {
            min-height: 110px;
        }

        .item-row .form-control:focus {
            border-color: #1abc9c;
            box-shadow: 0 0 0 0.15rem rgba(26, 188, 156, 0.12);
        }

        .imei_suggestions {
            position: absolute;
            z-index: 1000;
            width: calc(100% - 30px);
            max-height: 220px;
            overflow-y: auto;
            background: #fff;
            border: 1px solid #d7e1ec;
            border-radius: 12px;
            box-shadow: 0 14px 28px rgba(15, 23, 42, 0.10);
            display: none;
        }

        .imei_suggestions.show {
            display: block;
        }

        .imei_suggestions .list-group-item {
            border: 0;
            border-bottom: 1px solid #eef3f8;
            padding: 10px 12px;
        }

        .imei_suggestions .list-group-item:last-child {
            border-bottom: 0;
        }

        .invoice-create-add {
            border-radius: 12px;
            padding: 11px 16px;
            font-weight: 700;
        }

        @media (max-width: 991.98px) {
            .invoice-create-hero__badge {
                margin-top: 18px;
                min-width: 100%;
            }
        }

        @media (max-width: 767.98px) {
            .invoice-create-shell {
                padding-top: 18px;
            }

            .invoice-create-hero {
                padding: 24px 22px;
            }

            .invoice-create-hero__title {
                font-size: 26px;
            }

            .invoice-create-card .card-body {
                padding: 20px;
            }

            .invoice-create-actions {
                flex-direction: column;
            }
        }
    </style>
@endsection

@section('content')
    <div class="container-fluid invoice-create-shell">
        <div class="invoice-create-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="invoice-create-hero__eyebrow">Billing Workspace</div> -->
                    <h1 class="invoice-create-hero__title">Create Invoice</h1>
                    <p class="invoice-create-hero__subtitle"></p>
                </div>
                <div class="col-lg-4 text-lg-right">
                    <div class="invoice-create-hero__badge">Invoice #{{ $lastId }}</div>
                </div>
            </div>
        </div>

        <div class="card invoice-create-card">
            <div class="card-body">
                @include('include.alert')

                <form action="{{ route('create-invoice') }}" method="post"
                    class="@if(count($errors)) was-validated @endif">
                    @csrf
                    <input type="hidden" name="invoice_no" value="{{ $lastId }}" />

                    <div class="invoice-create-section">
                        <div class="invoice-create-section__eyebrow">Customer Details</div>
                        <h2 class="invoice-create-section__title">Invoice Information</h2>
                        <p class="invoice-create-section__subtitle"></p>

                        <div class="invoice-create-panel">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="invoice-create-label">Customer Name <span class="text-danger">*</span></label>
                                    <input type="text" required placeholder="Customer Name" name="customer_name"
                                        class="form-control invoice-create-input @error('customer_name') parsley-error @enderror"
                                        id="customer_name" value="{{ old('customer_name') }}">
                                    @error('customer_name')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="col-md-3 mb-3">
                                    <label class="invoice-create-label" for="customer_no">Contact No <span class="text-danger">*</span></label>
                                    <input type="text" name="customer_no" class="form-control invoice-create-input"
                                        id="customer_no" maxlength="10" placeholder="Customer mobile"
                                        value="{{ old('customer_no') }}">
                                </div>

                                <div class="col-md-3 mb-3">
                                    <label class="invoice-create-label">Invoice Date</label>
                                    <input type="text" name="invoice_date" class="form-control invoice-create-input"
                                        id="invoicedate" placeholder="dd/mm/yyyy"
                                        value="{{ old('invoice_date', date('d/m/Y')) }}">
                                </div>

                                <div class="col-md-2 mb-3">
                                    <label class="invoice-create-label">Payment Mode <span class="text-danger">*</span></label>
                                    <select name="payment_type"
                                        class="form-control invoice-create-input @error('payment_type') parsley-error @enderror"
                                        id="payment_type" required>
                                        <option value="">Select</option>
                                        <option value="Cash" {{ old('payment_type') === 'Cash' ? 'selected' : '' }}>Cash</option>
                                        <option value="Online" {{ old('payment_type') === 'Online' ? 'selected' : '' }}>Online/UPI</option>
                                        <option value="Credit Card" {{ old('payment_type') === 'Credit Card' ? 'selected' : '' }}>Credit Card</option>
                                    </select>
                                </div>

                                <div class="col-md-12">
                                    <label class="invoice-create-label">Address</label>
                                    <input type="text" name="customer_address" class="form-control invoice-create-input"
                                        id="customer_address" placeholder="Customer Address"
                                        value="{{ old('customer_address') }}">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="invoice-create-section">
                        <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">
                            <div>
                                <div class="invoice-create-section__eyebrow">Items</div>
                                <h2 class="invoice-create-section__title mb-1">Invoice Items</h2>
                                <p class="invoice-create-section__subtitle mb-0">Search by IMEI, fill prices, and let the totals update automatically.</p>
                            </div>
                            <button type="button" class="btn btn-outline-success invoice-create-add mt-3 mt-md-0" id="addItemBtn">
                                <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Item
                            </button>
                        </div>

                        <div id="itemsContainer" class="mb-2"></div>
                    </div>

                    <div class="invoice-create-section">
                        <div class="invoice-create-section__eyebrow">Totals</div>
                        <h2 class="invoice-create-section__title">Tax & Summary</h2>
                        <!-- <p class="invoice-create-section__subtitle">Apply taxes and discounts to compute the final net amount.</p> -->

                        <div class="row">
                            <div class="col-lg-8">
                                <div class="invoice-create-panel">
                                    <div class="row">
                                        <div class="col-md-3 mb-3 mb-md-0">
                                            <label class="invoice-create-label">CGST (%)</label>
                                            <input type="text" class="form-control invoice-create-input" placeholder="CGST Rate"
                                                name="cgst_rate" id="cgst" value="{{ old('cgst_rate') }}">
                                            <input type="hidden" id="cgstAmount" name="cgst_amount" value="{{ old('cgst_amount', 0) }}">
                                        </div>
                                        <div class="col-md-3 mb-3 mb-md-0">
                                            <label class="invoice-create-label">SGST (%)</label>
                                            <input type="text" class="form-control invoice-create-input" placeholder="SGST Rate"
                                                name="sgst_rate" id="sgst" value="{{ old('sgst_rate') }}">
                                            <input type="hidden" id="sgstAmount" name="sgst_amount" value="{{ old('sgst_amount', 0) }}">
                                        </div>
                                        <div class="col-md-3 mb-3 mb-md-0">
                                            <label class="invoice-create-label">IGST (%)</label>
                                            <input type="text" class="form-control invoice-create-input" placeholder="IGST Rate"
                                                name="igst_rate" id="igst" value="{{ old('igst_rate') }}">
                                            <input type="hidden" id="igstAmount" name="igst_amount" value="{{ old('igst_amount', 0) }}">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="invoice-create-label">Discount Amount</label>
                                            <input type="number" class="form-control invoice-create-input" placeholder="Discount"
                                                name="discount_amount" id="discAmount" min="0" value="{{ old('discount_amount') }}">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 mt-3 mt-lg-0">
                                <div class="invoice-create-summary">
                                    <div class="invoice-create-summary__row">
                                        <span>Total Amount</span>
                                        <strong>₹ <span id="totalAmountDisplay">{{ old('total_amount', 0) }}</span></strong>
                                    </div>
                                    <div class="invoice-create-summary__row">
                                        <span>Discount</span>
                                        <strong>₹ <span id="discountAmount">{{ old('discount_amount', 0) }}</span></strong>
                                    </div>
                                    <div class="invoice-create-summary__row">
                                        <span>Tax</span>
                                        <strong>₹ <span id="taxDisplay">{{ old('tax_amount', 0) }}</span></strong>
                                    </div>
                                    <div class="invoice-create-summary__row invoice-create-summary__row--total">
                                        <span>Net Amount</span>
                                        <span>₹ <span id="netAmountDisplay">{{ old('net_amount', 0) }}</span></span>
                                    </div>

                                    <input type="hidden" name="total_amount" id="totalAmountInput" value="{{ old('total_amount', 0) }}">
                                    <input type="hidden" name="tax_amount" id="taxAmount" value="{{ old('tax_amount', 0) }}">
                                    <input type="hidden" name="net_amount" id="netAmount" value="{{ old('net_amount', 0) }}">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="invoice-create-section">
                        <div class="invoice-create-section__eyebrow">Notes</div>
                        <h2 class="invoice-create-section__title">Declaration</h2>
                        <p class="invoice-create-section__subtitle">Add any optional note or declaration to appear with this invoice.</p>
                        <input type="text" name="declaration" class="form-control invoice-create-input"
                            placeholder="Add any declaration or note" value="{{ old('declaration') }}">
                    </div>

                    <div class="invoice-create-actions">
                        <a href="{{ route('allinvoices') }}" class="btn btn-outline-danger invoice-create-btn">
                            <i class="mdi mdi-keyboard-backspace mr-1"></i>Back
                        </a>
                        <button type="submit" class="btn btn-primary invoice-create-btn">
                            <i class="mdi mdi-check-circle-outline mr-1"></i>Submit Invoice
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script>
        let itemCounter = 0;
        $(document).ready(function () {
            $("#invoicedate").datepicker({ dateFormat: 'dd/mm/yy' });

            $('#customer_no').on('blur', function() {
                let contactNo = $(this).val().trim();
                contactNo = contactNo.replace(/\D/g, '');
                if (contactNo.length >= 10) {
                    fetchCustomerByContact(contactNo);
                }
            });

            const oldItems = @json(old('items', []));
            if (oldItems && Object.keys(oldItems).length > 0) {
                Object.keys(oldItems).forEach(function (key) {
                    const item = oldItems[key] || {};
                    addItemRow();
                    const $row = $('#itemsContainer .item-row').last();
                    if (item.item_id) $row.find('.item-id').val(item.item_id);
                    if (item.item_description) $row.find('.item-description').val(item.item_description);
                    if (item.quantity) $row.find('.item-quantity').val(item.quantity);
                    if (item.unit_price) $row.find('.item-price').val(item.unit_price);
                    if (item.warranty_expiry_date) $row.find('.item-warranty').val(item.warranty_expiry_date);
                    if (item.item_id) $row.find('.item-imei').val(item.imei);
                    calculateItemTotal($row);
                });
            } else {
                addItemRow();
            }

            $(document).on('click', '#addItemBtn', addItemRow);
            $(document).on('click', '.remove-item', function () {
                if ($('.item-row').length <= 1) {
                    alert('At least one item is required in the invoice');
                    return;
                }
                $(this).closest('.item-row').remove();
                calculateTotals();
            });

            $('form').on('submit', function (e) {
                if ($('.item-row').length === 0) {
                    e.preventDefault();
                    alert('Please add at least one item to the invoice');
                    return false;
                }
            });

            $(document).on('keyup', '.item-imei', function () {
                searchIMEI($(this).closest('.item-row'));
            });

            $(document).on('input', '.item-imei', function () {
                const $row = $(this).closest('.item-row');
                const imei = $(this).val();
                $row.find('.imei-error').hide();

                let duplicateFound = false;
                $('.item-row').each(function () {
                    const currentRow = $(this);
                    if (currentRow[0] === $row[0]) return;

                    const otherImei = currentRow.find('.item-imei').val();
                    if (otherImei && otherImei === imei) {
                        duplicateFound = true;
                        return false;
                    }
                });

                if (duplicateFound && imei) {
                    $row.find('.imei-error').text('This IMEI is already added in another item').show();
                }
            });

            $(document).on('keydown', '.item-imei', function (e) {
                if (e.which === 13) {
                    e.preventDefault();
                    searchIMEI($(this).closest('.item-row'));
                }
            });

            $(document).on('input keyup change', '.item-price, .item-quantity', function () {
                calculateItemTotal($(this).closest('.item-row'));
            });

            $(document).on('input keyup change', '#cgst, #sgst, #igst, #discAmount', function () {
                calculateNetAmount();
            });

            calculateTotals();
        });

        function fetchCustomerByContact(contactNo) {
            if (!contactNo || contactNo.length < 10) {
                return;
            }

            $.ajax({
                url: `/admin/fetchcustomer/${contactNo}`,
                type: 'GET',
                beforeSend: function() {
                    $('#customer_no').css('border-color', '#1abc9c');
                },
                success: function (data) {
                    if (data.customer) {
                        $('#customer_name').val(data.customer.customer_name || '');
                        $('#customer_address').val(data.customer.customer_address || '');
                        $('#customer_no_sync').prop('checked', false);
                        $('#customer_no').css('border-color', '#28a745');
                        setTimeout(function() {
                            $('#customer_no').css('border-color', '');
                        }, 2000);
                    }
                },
                error: function (xhr) {
                    $('#customer_no').css('border-color', '');
                    if (xhr.status !== 404 && xhr.responseJSON && xhr.responseJSON.error) {
                        console.log('Customer fetch error:', xhr.responseJSON.error);
                    }
                }
            });
        }

        function addItemRow() {
            itemCounter++;
            const rowHtml = `
                <div class="item-row" data-index="${itemCounter}">
                    <div class="row g-2 align-items-end">
                        <div class="col-md-4">
                            <label class="form-label">IMEI <span class="text-danger">*</span> <small class="text-danger imei-error" style="display:none;"></small></label>
                            <input type="text" class="form-control item-imei" placeholder="Search IMEI..">
                            <div class="list-group imei_suggestions"></div>
                            <input type="hidden" class="item-id" name="items[${itemCounter}][item_id]">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Warranty Expiry</label>
                            <input type="text" class="form-control item-warranty"
                                name="items[${itemCounter}][warranty_expiry_date]" placeholder="dd/mm/yyyy">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Qty <span class="text-danger">*</span></label>
                            <input type="number" class="form-control item-quantity"
                                name="items[${itemCounter}][quantity]" value="1" min="1">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Unit Price <span class="text-danger">*</span></label>
                            <input type="number" class="form-control item-price"
                                name="items[${itemCounter}][unit_price]" step="0.01" min="0" placeholder="0.00">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Total</label>
                            <input type="text" class="form-control item-total" readonly value="0.00">
                        </div>
                    </div>
                    <div class="row g-2 mt-2">
                        <div class="col-md-10">
                            <label class="form-label">Description</label>
                            <textarea class="form-control item-description"
                                name="items[${itemCounter}][item_description]" rows="4"
                                placeholder="Enter item description..."></textarea>
                        </div>
                        <div class="col-md-2 d-flex align-items-end justify-content-end mt-2">
                            <button type="button" class="btn btn-outline-danger remove-item">
                                <i class="mdi mdi-delete mr-1"></i>Remove
                            </button>
                        </div>
                    </div>
                </div>`;
            $('#itemsContainer').append(rowHtml);
            $('.item-imei').last().focus();
            $('.item-warranty').last().datepicker({ dateFormat: 'dd/mm/yy' });
        }

        function searchIMEI($row) {
            const suggestions = $row.find(".imei_suggestions")[0];
            const imei = $row.find('.item-imei').val();
            if (!imei) return;

            let duplicateFound = false;
            $('.item-row').each(function () {
                const currentRow = $(this);
                if (currentRow[0] === $row[0]) return;

                const otherImei = currentRow.find('.item-imei').val();
                if (otherImei && otherImei === imei) {
                    duplicateFound = true;
                    return false;
                }
            });

            if (duplicateFound) {
                $row.find('.imei-error').text('This IMEI is already added in another item').show();
                $row.find('.item-id').val('');
                $row.find('.item-description').val('');
                $row.find('.item-price').val('0.00');
                return;
            }

            $.ajax({
                url: `/admin/fetchstockonimei/${imei}`,
                type: 'GET',
                success: function (data) {
                    suggestions.innerHTML = "";
                    $row.find('.imei-error').hide();

                    const selectedImeis = [];
                    $('.item-row').each(function () {
                        const currentRow = $(this);
                        if (currentRow[0] === $row[0]) return;

                        const selectedImei = (currentRow.find('.item-imei').val() || '').trim();
                        if (selectedImei) {
                            selectedImeis.push(selectedImei);
                        }
                    });

                    const filteredData = (data || []).filter(item => !selectedImeis.includes((item['imei'] || '').trim()));

                    if (filteredData.length === 0) {
                        $row.find('.imei-error').text('No available IMEI found for this search').show();
                        suggestions.classList.remove("show");
                        return;
                    }

                    filteredData.forEach(item => {
                        let option = document.createElement("a");
                        option.classList.add("list-group-item", "list-group-item-action");
                        option.textContent = item['imei'] + " - " + item['model'];
                        option.href = "#";

                        option.addEventListener("click", function (e) {
                            e.preventDefault();
                            $row.find('.item-imei').val(item['imei']);
                            $row.find('.item-id').val(item['id']);

                            let desc = `Model: ${item['model']}\n`;
                            if (item['color']) desc += `Color: ${item['color']}\n`;
                            if (item['storage']) desc += `Storage: ${item['storage']}\n`;
                            if (item['imei']) desc += `IMEI: ${item['imei']}`;
                            $row.find('.item-description').val(desc);

                            suggestions.classList.remove("show");
                            suggestions.innerHTML = "";
                            const imeiInput = $row.find('.item-imei')[0];
                            const length = imeiInput.value.length;
                            imeiInput.focus();
                            imeiInput.setSelectionRange(length, length);
                        });

                        suggestions.appendChild(option);
                    });

                    suggestions.classList.add("show");
                }
            });
        }

        function calculateItemTotal($row) {
            const qty = parseFloat($row.find('.item-quantity').val()) || 1;
            const price = parseFloat($row.find('.item-price').val()) || 0;
            const total = qty * price;
            $row.find('.item-total').val(total.toFixed(2));
            calculateTotals();
        }

        function calculateTotals() {
            let total = 0;
            $('.item-total').each(function () {
                total += parseFloat($(this).val()) || 0;
            });
            $('#totalAmountInput').val(total.toFixed(2));
            $('#totalAmountDisplay').text(total.toFixed(2));
            calculateNetAmount();
        }

        function calculateNetAmount() {
            const total = parseFloat($('#totalAmountInput').val()) || 0;
            const cgst = parseFloat($('#cgst').val()) || 0;
            const sgst = parseFloat($('#sgst').val()) || 0;
            const igst = parseFloat($('#igst').val()) || 0;
            const discount = parseFloat($('#discAmount').val()) || 0;
            const cgstAmt = (cgst / 100) * total;
            const sgstAmt = (sgst / 100) * total;
            const igstAmt = (igst / 100) * total;
            const tax = cgstAmt + sgstAmt + igstAmt;
            const net = total + tax - discount;
            $('#cgstDisplay').text(cgstAmt.toFixed(2));
            $('#sgstDisplay').text(sgstAmt.toFixed(2));
            $('#igstDisplay').text(igstAmt.toFixed(2));
            $('#cgstAmount').val(cgstAmt.toFixed(2));
            $('#sgstAmount').val(sgstAmt.toFixed(2));
            $('#igstAmount').val(igstAmt.toFixed(2));
            $('#taxDisplay').text(tax.toFixed(2));
            $('#taxAmount').val(tax.toFixed(2));
            $('#discountAmount').text(discount.toFixed(2));
            $('#netAmountDisplay').text(net.toFixed(2));
            $('#netAmount').val(net.toFixed(2));
        }
    </script>
@endsection
