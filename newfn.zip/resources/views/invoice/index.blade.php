@extends('layout.app')

@section('title')
    Manage Invoices
@endsection

@section('content')
    <style>
        .invoice-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.10), transparent 26%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .invoice-hero {
            position: relative;
            overflow: hidden;
            border-radius: 26px;
            padding: 20px 25px;
            margin-bottom: 24px;
            background: linear-gradient(135deg, #163447 0%, #204e65 58%, #1abc9c 100%);
            box-shadow: 0 24px 50px rgba(22, 52, 71, 0.18);
            color: #fff;
        }

        .invoice-hero::after {
            content: "";
            position: absolute;
            right: -72px;
            bottom: -96px;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .invoice-hero__eyebrow {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 14px;
        }

        .invoice-hero__title {
            color: #fff;
            font-size: 31px;
            line-height: 1.15;
            margin-bottom: 8px;
        }

        .invoice-hero__subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            max-width: 560px;
            margin-bottom: 0;
        }

        .invoice-hero__actions {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            height: 100%;
        }

        .invoice-hero__btn {
            border-radius: 12px;
            padding: 11px 18px;
            font-weight: 700;
            color: #17324d;
            background: #ffffff;
            border: 0;
            box-shadow: 0 14px 30px rgba(15, 23, 42, 0.16);
            z-index: 9;
        }

        .invoice-hero__btn:hover {
            color: #17324d;
            background: #f7fafc;
        }

        .invoice-section {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .invoice-section .card-body {
            padding: 26px;
        }

        .invoice-section__eyebrow {
            color: #1abc9c;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 8px;
        }

        .invoice-section__title {
            color: #18324b;
            font-size: 24px;
            margin-bottom: 6px;
        }

        .invoice-section__subtitle {
            color: #7b8798;
            margin-bottom: 18px;
        }

        .invoice-table {
            margin-bottom: 0;
        }

        .invoice-table thead th {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #ebf6ff;
            background: #17324d;
            border-top: 0;
            border-bottom: 0;
            padding: 14px 16px;
            white-space: nowrap;
        }

        .invoice-table tbody td {
            padding: 18px 16px;
            border-top: 1px solid #eef3f8;
            vertical-align: top !important;
        }

        .invoice-index {
            font-weight: 700;
            color: #4f46e5;
        }

        .invoice-number {
            color: #18324b;
            font-weight: 700;
        }

        .invoice-customer__name {
            color: #18324b;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .invoice-customer__contact a {
            color: #1abc9c;
            font-weight: 600;
        }

        .invoice-customer__meta {
            color: #7e8b9c;
            font-size: 12px;
            margin-top: 6px;
        }

        .invoice-customer__meta div + div {
            margin-top: 4px;
        }

        .invoice-billing {
            text-align: right;
        }

        .invoice-billing__item + .invoice-billing__item {
            margin-top: 8px;
        }

        .invoice-billing__label {
            display: block;
            color: #7b8798;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 2px;
        }

        .invoice-billing__value {
            color: #18324b;
            font-size: 15px;
            font-weight: 700;
            white-space: nowrap;
        }

        .invoice-billing__value--net {
            font-size: 18px;
        }

        .invoice-date {
            color: #5f7188;
            font-weight: 600;
            white-space: nowrap;
        }

        .invoice-actions {
            white-space: nowrap;
            text-align: right;
        }

        .invoice-actions-menu .dropdown-toggle {
            border-radius: 12px;
            min-width: 96px;
            min-height: 40px;
            font-weight: 600;
            color: #fff;
            background: #17324d;
            border: 0;
            box-shadow: 0 12px 24px rgba(23, 50, 77, 0.18);
        }

        .invoice-actions-menu .dropdown-toggle::after {
            margin-left: 8px;
        }

        .invoice-actions-menu .dropdown-toggle:hover,
        .invoice-actions-menu .dropdown-toggle:focus {
            color: #fff;
            background: #214767;
        }

        .invoice-actions-menu .dropdown-menu {
            min-width: 170px;
            border: 1px solid #e4ebf3;
            border-radius: 14px;
            box-shadow: 0 18px 35px rgba(15, 23, 42, 0.12);
            padding: 8px;
        }

        .invoice-actions-menu .dropdown-item {
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 600;
            color: #17324d;
            padding: 10px 12px;
        }

        .invoice-actions-menu .dropdown-item i {
            font-size: 16px;
            color: #70839a;
        }

        .invoice-actions-menu .dropdown-item:hover {
            background: #f7fafc;
            color: #17324d;
        }

        .invoice-actions-menu .dropdown-item--danger {
            color: #d63c49;
        }

        .invoice-actions-menu .dropdown-item--danger i {
            color: #d63c49;
        }

        .invoice-empty {
            text-align: center;
            padding: 56px 20px;
        }

        .invoice-empty__icon {
            width: 78px;
            height: 78px;
            margin: 0 auto 18px;
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(26, 188, 156, 0.12);
            color: #169c82;
            font-size: 30px;
        }

        .invoice-empty h4 {
            color: #17324d;
            margin-bottom: 8px;
        }

        .invoice-empty p {
            color: #8190a5;
            margin-bottom: 0;
        }

        @media (max-width: 767.98px) {
            .invoice-shell {
                padding-top: 18px;
            }

            .invoice-hero {
                padding: 24px 22px;
            }

            .invoice-hero__title {
                font-size: 26px;
            }

            .invoice-hero__actions {
                justify-content: flex-start;
                margin-top: 18px;
            }

            .invoice-table {
                min-width: 1080px;
            }

            .invoice-section .card-body {
                padding: 20px;
            }
        }
    </style>

    <div class="container-fluid invoice-shell">
        <div class="invoice-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="invoice-hero__title">Manage Invoices</h1>

                </div>
                <div class="col-lg-4">
                    <div class="invoice-hero__actions">
                        <a href="{{ route('newinvoice') }}" class="btn invoice-hero__btn">
                            <i class="mdi mdi-plus-circle-outline mr-1"></i>New Invoice
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="card invoice-section">
            <div class="card-body">
                <h2 class="invoice-section__title">All Invoices</h2>
                <p class="invoice-section__subtitle"></p>

                <div class="table-responsive">
                    @if (count($allInvoices))
                        <table class="table invoice-table" id="invoice-table">
                            <thead>
                                <tr>
                                    <th>Sr No</th>
                                    <th>Invoice No.</th>
                                    <th>Customer Detail</th>
                                    <th class="text-right">Billing Info</th>
                                    <th>Invoice Date</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($allInvoices as $key => $invoice)
                                    <tr>
                                        <td>
                                            <a href="{{ route('invoice-detail', $invoice->id) }}" class="invoice-index">
                                                #{{ $key + 1 }}
                                            </a>
                                        </td>
                                        <td>
                                            <a href="{{ route('invoice-detail', $invoice->id) }}" class="invoice-number">
                                                #{{ $invoice->invoice_no }}
                                            </a>
                                        </td>
                                        <td>
                                            <div class="invoice-customer__name">{{ ucfirst($invoice->customer_name) }}</div>
                                            <div class="invoice-customer__contact">
                                                @if($invoice->customer_no)
                                                    <a href="tel:{{ $invoice->customer_no }}">{{ $invoice->customer_no }}</a>
                                                @else
                                                    <span class="text-muted">N/A</span>
                                                @endif
                                            </div>
                                            <div class="invoice-customer__meta">
                                                @foreach($invoice->items as $item)
                                                    @if($item->purchase && $item->purchase->imei)
                                                        <div>IMEI: {{ $item->purchase->imei }}</div>
                                                    @endif
                                                @endforeach
                                            </div>
                                        </td>
                                        <td class="invoice-billing">
                                            <!-- @if($invoice->total_amount)
                                                <div class="invoice-billing__item">
                                                    <span class="invoice-billing__label">Total Amount</span>
                                                    <span class="invoice-billing__value">₹{{ number_format($invoice->total_amount, 2) }}</span>
                                                </div>
                                            @endif -->
                                            @if($invoice->tax_amount)
                                                <div class="invoice-billing__item">
                                                    <span class="invoice-billing__label">Tax</span>
                                                    <span class="invoice-billing__value">₹{{ number_format($invoice->tax_amount, 2) }}</span>
                                                </div>
                                            @endif
                                            @if($invoice->discount)
                                                <div class="invoice-billing__item">
                                                    <span class="invoice-billing__label">Discount</span>
                                                    <span class="invoice-billing__value">₹{{ number_format($invoice->discount, 2) }}</span>
                                                </div>
                                            @endif
                                            @if($invoice->net_amount)
                                                <div class="invoice-billing__item">
                                                    <span class="invoice-billing__label">Net Amount</span>
                                                    <span class="invoice-billing__value invoice-billing__value--net">₹{{ number_format($invoice->net_amount, 2) }}</span>
                                                </div>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="invoice-date">{{ date('d-m-Y', strtotime($invoice->invoice_date)) }}</span>
                                        </td>
                                        <td class="invoice-actions">
                                            <div class="dropdown invoice-actions-menu">
                                                <button class="btn btn-light btn-sm dropdown-toggle" type="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    Actions
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a href="{{ route('invoice-edit', $invoice->id) }}" class="dropdown-item">
                                                        <i class="mdi mdi-pencil-outline"></i>
                                                        <span>Edit</span>
                                                    </a>
                                                    <a href="{{ route('print-invoice', $invoice->id) }}" class="dropdown-item">
                                                        <i class="mdi mdi-printer"></i>
                                                        <span>Print</span>
                                                    </a>
                                                    @if($invoice->customer_no)
                                                        <a href="{{ route('send-whatsapp', ['id' => $invoice->id]) }}" target="_blank"
                                                            class="dropdown-item">
                                                            <i class="mdi mdi-whatsapp"></i>
                                                            <span>WhatsApp</span>
                                                        </a>
                                                    @endif
                                                    <button type="button" class="dropdown-item dropdown-item--danger delete-invoice"
                                                        data-id="{{ $invoice->id }}">
                                                        <i class="mdi mdi-delete-outline"></i>
                                                        <span>Delete</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="invoice-empty">
                            <div class="invoice-empty__icon">
                                <i class="mdi mdi-receipt-text-outline"></i>
                            </div>
                            <h4>No invoices found</h4>
                            <p>No billing records are available yet.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endSection

@section('scripts')
    <script>
        $(document).ready(function () {
            $('.delete-invoice').on('click', function () {
                var invoiceId = $(this).data('id');
                var deleteUrl = '/admin/invoice/delete/' + invoiceId;

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        var form = $('<form method="POST" action="' + deleteUrl + '"></form>');
                        form.append('<input type="hidden" name="_token" value="{{ csrf_token() }}">');
                        $('body').append(form);
                        form.submit();
                    }
                });
            });
        });
    </script>
@endsection
