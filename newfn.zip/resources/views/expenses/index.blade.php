@extends('layout.app')

@section('title')
    Expenses List
@endsection

@section('content')
@php
    $expenseCount = $expenses->count();
    $averageExpense = $expenseCount ? $expenses->avg('amount') : 0;
    $todayExpense = $expenses->filter(function ($expense) {
        return \Carbon\Carbon::parse($expense->entrydate)->isToday();
    })->sum('amount');

    $years = range(now()->year, now()->year - 3);
    $months = [
        'All',
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December',
    ];

    $oldExpenseId = old('expense_id');
    $oldEditExpense = $oldExpenseId ? $expenses->firstWhere('id', (int) $oldExpenseId) : null;
@endphp

<style>
    .expenses-page {
        padding: 24px 24px;
    }

    .expenses-hero {
        position: relative;
        overflow: hidden;
        border-radius: 26px;
        padding: 30px;
        margin-bottom: 24px;
        background: linear-gradient(145deg, #112939 0%, #18384d 55%, #23a184 100%);
        color: #fff;
        box-shadow: 0 24px 60px rgba(17, 41, 57, 0.18);
    }

    .expenses-hero::before,
    .expenses-hero::after {
        content: "";
        position: absolute;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.08);
    }

    .expenses-hero::before {
        width: 240px;
        height: 240px;
        top: -110px;
        right: -70px;
    }

    .expenses-hero::after {
        width: 160px;
        height: 160px;
        bottom: -70px;
        left: 34%;
    }

    .expenses-hero > * {
        position: relative;
        z-index: 1;
    }

    .expenses-hero__eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        border-radius: 999px;
        padding: 8px 12px;
        background: rgba(255, 255, 255, 0.12);
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
    }

    .expenses-hero__title {
        margin: 18px 0 10px;
        font-size: clamp(1.9rem, 3vw, 2.8rem);
        font-weight: 800;
        color: #fff;
        letter-spacing: -0.03em;
    }

    .expenses-hero__subtitle {
        max-width: 620px;
        margin: 0;
        color: rgba(255, 255, 255, 0.76);
        font-size: 15px;
        line-height: 1.8;
    }

    .expenses-hero__actions {
        display: flex;
        justify-content: flex-end;
        align-items: flex-start;
        height: 100%;
    }

    .expenses-primary-btn {
        border: 0;
        border-radius: 16px;
        padding: 14px 20px;
        font-weight: 700;
        background: #fff;
        color: #123040;
        box-shadow: 0 18px 36px rgba(0, 0, 0, 0.14);
    }

    .expenses-primary-btn:hover,
    .expenses-primary-btn:focus {
        color: #123040;
        transform: translateY(-1px);
    }

    .expenses-stat {
        height: 100%;
        border: 1px solid rgba(17, 41, 57, 0.08);
        border-radius: 22px;
        background: #fff;
        padding: 22px;
        box-shadow: 0 18px 40px rgba(17, 41, 57, 0.06);
    }

    .expenses-stat__label {
        display: flex;
        align-items: center;
        justify-content: space-between;
        color: #6b8593;
        font-size: 13px;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        margin-bottom: 12px;
    }

    .expenses-stat__value {
        font-size: 1.9rem;
        font-weight: 500;
        color: #112939;
        letter-spacing: -0.03em;
        line-height: 1.1;
    }

    .expenses-stat__meta {
        margin-top: 8px;
        color: #6f8791;
        font-size: 13px;
    }

    .expenses-panel {
        border: 1px solid rgba(17, 41, 57, 0.08);
        border-radius: 24px;
        background: #fff;
        box-shadow: 0 20px 48px rgba(17, 41, 57, 0.06);
        overflow: hidden;
    }

    .expenses-panel__header {
        padding: 24px 24px 14px;
        border-bottom: 1px solid rgba(17, 41, 57, 0.07);
    }

    .expenses-panel__title {
        margin: 0;
        font-size: 1.2rem;
        font-weight: 800;
        color: #112939;
    }

    .expenses-panel__subtitle {
        margin: 6px 0 0;
        color: #6f8791;
        font-size: 14px;
    }

    .expenses-filter-form {
        padding: 20px 24px 6px;
    }

    .expenses-filter-form label,
    .expense-modal label {
        color: #244457;
        font-size: 13px;
        font-weight: 700;
        letter-spacing: 0.02em;
        margin-bottom: 8px;
    }

    .expenses-filter-form .form-control,
    .expense-modal .form-control {
        height: 48px;
        border-radius: 14px;
        border-color: rgba(17, 41, 57, 0.12);
        box-shadow: none;
    }

    .expense-modal textarea.form-control {
        height: auto;
        min-height: 110px;
    }

    .expenses-table-wrap {
        padding: 0 24px 24px;
    }

    .expenses-table {
        margin-bottom: 0;
    }

    .expenses-table thead th {
        border-top: 0;
        border-bottom: 1px solid rgba(17, 41, 57, 0.08);
        color: #698290;
        font-size: 12px;
        font-weight: 800;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        padding: 16px 14px;
        white-space: nowrap;
    }

    .expenses-table tbody td {
        padding: 18px 14px;
        vertical-align: middle;
        border-color: rgba(17, 41, 57, 0.06);
        color: #173648;
    }

    .expenses-table tbody tr:hover {
        background: #f8fbfa;
    }

    .expense-category-pill {
        display: inline-flex;
        align-items: center;
        padding: 8px 12px;
        border-radius: 999px;
        background: #ecf7f3;
        color: #1d8169;
        font-weight: 700;
        text-transform: capitalize;
        font-size: 13px;
    }

    .expense-amount {
        font-weight: 800;
        color: #112939;
        white-space: nowrap;
    }

    .expense-date {
        font-weight: 700;
        color: #21465a;
    }

    .expense-date small {
        display: block;
        margin-top: 4px;
        color: #7a919d;
        font-weight: 600;
    }

    .expense-note {
        max-width: 260px;
        color: #6a8290;
    }

    .expense-empty {
        margin: 0 24px 24px;
        border: 1px dashed rgba(17, 41, 57, 0.16);
        border-radius: 22px;
        padding: 42px 24px;
        text-align: center;
        color: #6f8791;
        background: linear-gradient(180deg, #fbfcfc 0%, #f3f8f6 100%);
    }

    .expense-actions {
        display: inline-flex;
        align-items: center;
        gap: 10px;
    }

    .expense-actions .btn {
        border-radius: 12px;
    }

    .expense-edit-link {
        width: 38px;
        height: 38px;
        border-radius: 12px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: #edf5f2;
        color: #15384a;
    }

    .expense-edit-link:hover {
        background: #dff0eb;
        color: #15384a;
    }

    .expense-modal .modal-content {
        border: 0;
        border-radius: 24px;
        overflow: hidden;
        box-shadow: 0 28px 80px rgba(17, 41, 57, 0.18);
    }

    .expense-modal .modal-header {
        padding: 22px 24px 14px;
        border-bottom: 1px solid rgba(17, 41, 57, 0.08);
    }

    .expense-modal .modal-title {
        font-weight: 800;
        color: #112939;
    }

    .expense-modal .modal-subtitle {
        margin-top: 4px;
        color: #6f8791;
        font-size: 14px;
    }

    .expense-modal .modal-body {
        padding: 20px 24px 24px;
    }

    .expense-modal .modal-footer {
        border-top: 1px solid rgba(17, 41, 57, 0.08);
        padding: 16px 24px 24px;
    }

    .expense-modal .btn-light {
        border-radius: 14px;
        padding: 11px 16px;
    }

    .expense-modal .btn-success {
        border-radius: 14px;
        padding: 11px 18px;
        background: linear-gradient(135deg, #3ec7a6 0%, #23a184 100%);
        border: 0;
    }

    .expenses-alert {
        margin-bottom: 18px;
        border-radius: 16px;
    }

    @media (max-width: 991.98px) {
        .expenses-hero {
            padding: 24px;
        }

        .expenses-hero__actions {
            justify-content: flex-start;
            margin-top: 18px;
        }
    }

    @media (max-width: 767.98px) {
        .expenses-page {
            padding-bottom: 12px;
        }

        .expenses-hero,
        .expenses-panel {
            border-radius: 20px;
        }

        .expenses-hero,
        .expenses-filter-form,
        .expenses-panel__header,
        .expenses-table-wrap {
            padding-left: 18px;
            padding-right: 18px;
        }

        .expense-note {
            max-width: none;
        }
    }
</style>

<div class="container-fluid expenses-page">
    <div class="expenses-hero">
        <div class="row align-items-center">
            <div class="col-lg-8 mt-2">
                <div class="expenses-hero__eyebrow">
                    <i class="mdi mdi-wallet-outline"></i>
                    Expense Tracker
                </div>
                <!-- <h1 class="expenses-hero__title">Track business spending with a cleaner, faster workflow.</h1> -->
                <!-- <p class="expenses-hero__subtitle">
                    Review monthly expenses, filter records quickly, and add new spend entries without leaving the list.
                </p> -->
            </div>
            <div class="col-lg-4">
                <div class="expenses-hero__actions">
                    @can('expenses.create')
                        <button type="button" class="btn expenses-primary-btn" data-toggle="modal" data-target="#addExpenseModal">
                            <i class="mdi mdi-plus mr-1"></i> Add Expense
                        </button>
                    @endcan
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="expenses-stat">
                <div class="expenses-stat__label">
                    <span>Total Expense</span>
                    <i class="mdi mdi-currency-inr"></i>
                </div>
                <div class="expenses-stat__value">₹{{ number_format((float) $totalExpenseAmount, 2) }}</div>
                <div class="expenses-stat__meta">{{ $periodLabel }} {{ $year }} total</div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="expenses-stat">
                <div class="expenses-stat__label">
                    <span>Entries</span>
                    <i class="mdi mdi-format-list-bulleted"></i>
                </div>
                <div class="expenses-stat__value">{{ $expenseCount }}</div>
                <div class="expenses-stat__meta">Expense records in the current result set</div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="expenses-stat">
                <div class="expenses-stat__label">
                    <span>Avg / Today</span>
                    <i class="mdi mdi-chart-line"></i>
                </div>
                <div class="expenses-stat__value">₹{{ number_format((float) $averageExpense, 2) }}</div>
                <div class="expenses-stat__meta">Today: ₹{{ number_format((float) $todayExpense, 2) }}</div>
            </div>
        </div>
    </div>

    @if (session('status'))
        <div class="alert alert-success expenses-alert" id="statusMessage">
            {{ session('status') }}
        </div>
    @endif

    <div class="expenses-panel">
        <div class="expenses-panel__header">
            <h4 class="expenses-panel__title">Expense Register</h4>
            <p class="expenses-panel__subtitle">Filter by month and year, then manage entries from one place.</p>
        </div>

        <form action="{{ route('expenses') }}" method="GET" id="filterexpense" class="expenses-filter-form">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="selectyear">Select Year</label>
                    <select name="year" class="form-control" id="selectyear">
                        @foreach($years as $selectableYear)
                            <option value="{{ $selectableYear }}" @selected((int) $year === (int) $selectableYear)>{{ $selectableYear }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group col-md-3">
                    <label for="selectmonth">Select Month</label>
                    <select name="month" class="form-control" id="selectmonth">
                        @foreach($months as $selectableMonth)
                            <option value="{{ $selectableMonth }}" @selected($month === $selectableMonth)>{{ $selectableMonth }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </form>

        @if(count($expenses) > 0)
            <div class="table-responsive expenses-table-wrap">
                <table class="table expenses-table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Category</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Note</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($expenses as $key => $expense)
                            <tr>
                                <td>{{ $key + 1 }}</td>
                                <td>
                                    <span class="expense-category-pill">{{ $expense->expense_category }}</span>
                                </td>
                                <td class="expense-amount">₹{{ number_format($expense->amount, 2) }}</td>
                                <td class="expense-date">
                                    {{ \Carbon\Carbon::parse($expense->entrydate)->format('d M Y') }}
                                    <small>{{ \Carbon\Carbon::parse($expense->entrydate)->format('h:i A') }}</small>
                                </td>
                                <td class="expense-note">{{ $expense->description ?: '-' }}</td>
                                <td class="text-right">
                                    <div class="expense-actions">
                                        @can('expenses.edit')
                                            <button
                                                type="button"
                                                class="btn expense-edit-link js-edit-expense"
                                                title="Update"
                                                data-toggle="modal"
                                                data-target="#editExpenseModal"
                                                data-id="{{ $expense->id }}"
                                                data-category="{{ strtolower($expense->expense_category) }}"
                                                data-amount="{{ $expense->amount }}"
                                                data-entrydate="{{ \Carbon\Carbon::parse($expense->entrydate)->format('Y-m-d\TH:i') }}"
                                                data-description="{{ $expense->description }}">
                                                <i class="mdi mdi-square-edit-outline font-18"></i>
                                            </button>
                                        @endcan
                                        @can('expenses.delete')
                                            <form method="post" action="{{ route('delete-expense', $expense->id) }}" style="display:inline;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="sureToDelete(event)" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        @endcan
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div class="expense-empty">
                <h5 class="mb-2">No expenses found</h5>
                <p class="mb-0">Try a different filter or add a new expense record to get started.</p>
            </div>
        @endif
    </div>
</div>

@can('expenses.create')
    <div class="modal fade expense-modal" id="addExpenseModal" tabindex="-1" role="dialog" aria-labelledby="addExpenseModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="addExpenseModalLabel">Add Expense</h5>
                        <div class="modal-subtitle">Capture a new business expense without leaving this page.</div>
                    </div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="{{ route('save-expense') }}" id="addExpenseForm">
                    @csrf
                    <div class="modal-body">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="category">Expense Category</label>
                                <select id="category" class="form-control" name="expense_category">
                                    <option value="general" @selected(old('expense_category') === 'general')>General</option>
                                    <option value="petrol" @selected(old('expense_category') === 'petrol')>Petrol</option>
                                    <option value="food" @selected(old('expense_category') === 'food')>Food</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="amount">Amount</label>
                                <input
                                    type="number"
                                    id="amount"
                                    class="form-control @error('amount') parsley-error @enderror"
                                    name="amount"
                                    placeholder="Enter amount"
                                    value="{{ old('amount') }}"
                                    required
                                    min="0"
                                    step="0.01">
                                @error('amount')
                                    <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                        <li class="parsley-required">{{ $message }}</li>
                                    </ul>
                                @enderror
                            </div>
                            <div class="form-group col-md-6">
                                <label for="expensedate">Expense Date</label>
                                <input
                                    type="datetime-local"
                                    id="expensedate"
                                    class="form-control @error('entrydate') parsley-error @enderror"
                                    name="entrydate"
                                    value="{{ old('entrydate', now()->format('Y-m-d\TH:i')) }}"
                                    required>
                                @error('entrydate')
                                    <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                        <li class="parsley-required">{{ $message }}</li>
                                    </ul>
                                @enderror
                            </div>
                            <div class="form-group col-md-6">
                                <label for="description">Note</label>
                                <textarea class="form-control" id="description" rows="4" name="description" placeholder="Add a short note">{{ old('description') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Save Expense</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endcan

@can('expenses.edit')
    <div class="modal fade expense-modal" id="editExpenseModal" tabindex="-1" role="dialog" aria-labelledby="editExpenseModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h5 class="modal-title" id="editExpenseModalLabel">Edit Expense</h5>
                        <div class="modal-subtitle">Update an existing expense entry without leaving this page.</div>
                    </div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="{{ $oldEditExpense ? route('expenseedit', $oldEditExpense->id) : '#' }}" id="editExpenseForm">
                    @csrf
                    <input type="hidden" name="expense_id" id="edit_expense_id" value="{{ old('expense_id') }}">
                    <div class="modal-body">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="edit_category">Expense Category</label>
                                <select id="edit_category" class="form-control" name="expense_category">
                                    <option value="general" @selected(old('expense_category', strtolower($oldEditExpense->expense_category ?? 'general')) === 'general')>General</option>
                                    <option value="petrol" @selected(old('expense_category', strtolower($oldEditExpense->expense_category ?? '')) === 'petrol')>Petrol</option>
                                    <option value="food" @selected(old('expense_category', strtolower($oldEditExpense->expense_category ?? '')) === 'food')>Food</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="edit_amount">Amount</label>
                                <input
                                    type="number"
                                    id="edit_amount"
                                    class="form-control @error('amount') parsley-error @enderror"
                                    name="amount"
                                    placeholder="Enter amount"
                                    value="{{ old('amount', $oldEditExpense->amount ?? '') }}"
                                    required
                                    min="0"
                                    step="0.01">
                                @if($errors->any() && old('expense_id'))
                                    @error('amount')
                                        <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                            <li class="parsley-required">{{ $message }}</li>
                                        </ul>
                                    @enderror
                                @endif
                            </div>
                            <div class="form-group col-md-6">
                                <label for="edit_expensedate">Expense Date</label>
                                <input
                                    type="datetime-local"
                                    id="edit_expensedate"
                                    class="form-control @if($errors->any() && old('expense_id')) @error('entrydate') parsley-error @enderror @endif"
                                    name="entrydate"
                                    value="{{ old('entrydate', $oldEditExpense ? \Carbon\Carbon::parse($oldEditExpense->entrydate)->format('Y-m-d\TH:i') : '') }}"
                                    required>
                                @if($errors->any() && old('expense_id'))
                                    @error('entrydate')
                                        <ul class="parsley-errors-list filled mt-2 mb-0" aria-hidden="false">
                                            <li class="parsley-required">{{ $message }}</li>
                                        </ul>
                                    @enderror
                                @endif
                            </div>
                            <div class="form-group col-md-6">
                                <label for="edit_description">Note</label>
                                <textarea class="form-control" id="edit_description" rows="4" name="description" placeholder="Add a short note">{{ old('description', $oldEditExpense->description ?? '') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Update Expense</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endcan

<script>
    setTimeout(function() {
        document.getElementById('statusMessage')?.remove();
    }, 5000);

    document.getElementById('selectyear')?.addEventListener('change', function () {
        document.getElementById('filterexpense').submit();
    });

    document.getElementById('selectmonth')?.addEventListener('change', function () {
        document.getElementById('filterexpense').submit();
    });

    @can('expenses.create')
        $(function () {
            const shouldOpenAddModal = {{ $errors->any() && !$oldExpenseId || request('open') === 'add' ? 'true' : 'false' }};
            if (shouldOpenAddModal) {
                $('#addExpenseModal').modal('show');
            }

            const addExpenseForm = document.getElementById('addExpenseForm');
            if (addExpenseForm) {
                addExpenseForm.addEventListener('submit', function (event) {
                    if (!this.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                        $('#addExpenseModal').modal('show');
                        this.reportValidity();
                    }
                });
            }
        });
    @endcan

    @can('expenses.edit')
        $(function () {
            const editExpenseForm = document.getElementById('editExpenseForm');
            const editExpenseId = document.getElementById('edit_expense_id');
            const editCategory = document.getElementById('edit_category');
            const editAmount = document.getElementById('edit_amount');
            const editEntrydate = document.getElementById('edit_expensedate');
            const editDescription = document.getElementById('edit_description');

            $('#editExpenseModal').on('show.bs.modal', function (event) {
                const trigger = event.relatedTarget;
                if (!trigger || !editExpenseForm) {
                    return;
                }

                const expenseId = trigger.getAttribute('data-id');
                editExpenseForm.action = "{{ url('/admin/expenses/update') }}/" + expenseId;
                editExpenseId.value = expenseId || '';
                editCategory.value = trigger.getAttribute('data-category') || 'general';
                editAmount.value = trigger.getAttribute('data-amount') || '';
                editEntrydate.value = trigger.getAttribute('data-entrydate') || '';
                editDescription.value = trigger.getAttribute('data-description') || '';
            });

            if (editExpenseForm) {
                editExpenseForm.addEventListener('submit', function (event) {
                    if (!this.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                        $('#editExpenseModal').modal('show');
                        this.reportValidity();
                    }
                });
            }

            const shouldOpenEditModal = {{ $errors->any() && $oldExpenseId ? 'true' : 'false' }};
            if (shouldOpenEditModal) {
                $('#editExpenseModal').modal('show');
            }
        });
    @endcan
</script>
@endsection
