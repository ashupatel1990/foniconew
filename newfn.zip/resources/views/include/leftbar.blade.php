@php
    $user = auth()->user();
    $profileImage = !empty($user->profile_image)
        ? asset('admin/users/' . $user->profile_image)
        : asset('assets/images/users/user-1.jpg');

    $stocksOpen = request()->routeIs('allpurchases', 'purchase.create', 'purchase.create.multiple', 'purchase.edit', 'purchase-detail', 'purchase.importform');
    $salesOpen = request()->routeIs('allsales', 'new-sale', 'saledetail');
    $invoiceOpen = request()->routeIs('allinvoices', 'newinvoice', 'invoice-detail');
    $reportsOpen = request()->routeIs('sale-report', 'profit-loss', 'daily-closing', 'purchase-report', 'saleschart', 'customers');
    $expensesOpen = request()->routeIs('expenses', 'add-expense');
    $partyOpen = request()->routeIs('parties.*', 'transactions.*');
    $ledgerOpen = request()->routeIs('ledger.*');
    $adminOpen = request()->routeIs('roles.*', 'users.*');
@endphp

<style>
    .left-side-menu {
        background: linear-gradient(180deg, #112939 0%, #163447 100%);
        box-shadow: 12px 0 35px rgba(17, 41, 57, 0.16);
    }

    .left-side-menu .simplebar-content {
        display: flex;
        flex-direction: column;
        min-height: 100%;
    }

    .sidebar-brand-card {
        margin: 18px 18px 10px;
        padding: 18px;
        border-radius: 20px;
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.14) 0%, rgba(26, 188, 156, 0.18) 100%);
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: #fff;
    }

    .sidebar-brand-card__logo {
        width: 48px;
        height: 48px;
        border-radius: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, 0.12);
        margin-bottom: 14px;
        overflow: hidden;
    }

    .sidebar-brand-card__logo img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .sidebar-brand-card__title {
        color: #fff;
        font-size: 16px;
        font-weight: 700;
        margin-bottom: 4px;
    }

    .sidebar-brand-card__text {
        color: rgba(255, 255, 255, 0.7);
        font-size: 13px;
        margin-bottom: 0;
        line-height: 1.5;
    }

    .sidebar-user-card {
        margin: 0 18px 16px;
        padding: 14px;
        border-radius: 18px;
        background: rgba(255, 255, 255, 0.06);
        border: 1px solid rgba(255, 255, 255, 0.06);
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .sidebar-user-card__avatar {
        width: 48px;
        height: 48px;
        border-radius: 14px;
        object-fit: cover;
        border: 2px solid rgba(255, 255, 255, 0.12);
        flex-shrink: 0;
    }

    .sidebar-user-card__name {
        color: #fff;
        font-weight: 700;
        line-height: 1.2;
        margin-bottom: 4px;
    }

    .sidebar-user-card__role {
        color: rgba(255, 255, 255, 0.65);
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.08em;
    }

    .left-side-menu #sidebar-menu {
        padding: 0 12px 18px;
    }

    .left-side-menu #side-menu > li {
        margin-bottom: 6px;
    }

    .left-side-menu #side-menu > li > a {
        min-height: 50px;
        padding: 13px 16px;
        border-radius: 14px;
        color: rgba(255, 255, 255, 0.72);
        display: flex;
        align-items: center;
        font-weight: 600;
        transition: all 0.2s ease;
    }

    .left-side-menu #side-menu > li > a:hover,
    .left-side-menu #side-menu > li.menuitem-active > a,
    .left-side-menu #side-menu > li.menuitem-open > a {
        background: rgba(255, 255, 255, 0.08);
        color: #fff;
        box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.05);
    }

    .left-side-menu #side-menu > li > a i,
    .left-side-menu #side-menu > li > a svg {
        color: #7ed8c7;
        margin-right: 12px;
    }

    .left-side-menu #side-menu > li > a .menu-arrow {
        margin-left: auto;
        color: rgba(255, 255, 255, 0.45);
    }

    .left-side-menu .nav-second-level,
    .left-side-menu .nav-thrid-level {
        padding: 8px 0 6px 16px;
    }

    .left-side-menu .nav-second-level li a {
        color: rgba(255, 255, 255, 0.62);
        border-radius: 12px;
        padding: 10px 14px 10px 18px;
        font-size: 13px;
        margin-bottom: 4px;
        position: relative;
    }

    .left-side-menu .nav-second-level li a:hover,
    .left-side-menu .nav-second-level li a.active {
        color: #fff;
        background: rgba(26, 188, 156, 0.16);
    }

    .left-side-menu .nav-second-level li a::before {
        content: "";
        position: absolute;
        left: 8px;
        top: 50%;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        transform: translateY(-50%);
        background: rgba(126, 216, 199, 0.5);
    }

    .left-side-menu .nav-second-level li a.active::before {
        background: #7ed8c7;
    }

    body[data-sidebar-size="condensed"] .sidebar-brand-card,
    body[data-sidebar-size="condensed"] .sidebar-user-card {
        display: none;
    }

    body[data-sidebar-size="condensed"] .left-side-menu #sidebar-menu {
        padding-left: 8px;
        padding-right: 8px;
    }

    body[data-sidebar-size="condensed"] .left-side-menu #side-menu > li > a {
        justify-content: center;
        padding: 14px 0 !important;
        min-height: 54px;
    }

    body[data-sidebar-size="condensed"] .left-side-menu #side-menu > li > a i,
    body[data-sidebar-size="condensed"] .left-side-menu #side-menu > li > a svg {
        display: inline-flex !important;
        align-items: center;
        justify-content: center;
        width: 20px !important;
        min-width: 20px;
        height: 20px !important;
        margin: 0 !important;
        color: #7ed8c7 !important;
        opacity: 1 !important;
        visibility: visible !important;
    }

    body[data-sidebar-size="condensed"] .left-side-menu #side-menu > li.menuitem-active > a i,
    body[data-sidebar-size="condensed"] .left-side-menu #side-menu > li.menuitem-active > a svg,
    body[data-sidebar-size="condensed"] .left-side-menu #side-menu > li > a:hover i,
    body[data-sidebar-size="condensed"] .left-side-menu #side-menu > li > a:hover svg {
        color: #ffffff !important;
    }

    @media (max-width: 991.98px) {
        .sidebar-brand-card,
        .sidebar-user-card {
            margin-left: 12px;
            margin-right: 12px;
        }
    }
</style>

<div class="left-side-menu">
    <div class="h-100" data-simplebar>
        <!-- <div class="sidebar-brand-card">
            <div class="sidebar-brand-card__logo">
                <img src="{{ asset('assets/images/new_logo/fonico_mobiles.jpg') }}" alt="Fonico">
            </div>
            <div class="sidebar-brand-card__title">Fonico Mobile</div>
            <p class="sidebar-brand-card__text">Inventory, billing, and reporting in one focused workspace.</p>
        </div> -->
<!-- 
        <div class="sidebar-user-card">
            <img src="{{ $profileImage }}" alt="{{ $user->name ?? $user->user_name }}" class="sidebar-user-card__avatar">
            <div>
                <div class="sidebar-user-card__name">{{ $user->name ?? ucfirst($user->user_name) }}</div>
                <div class="sidebar-user-card__role">Signed In</div>
            </div>
        </div> -->

        <div id="sidebar-menu">
            <ul id="side-menu">
                @can('dashboard.view')
                    <li class="{{ request()->routeIs('dashboard') ? 'menuitem-active' : '' }}">
                        <a href="{{ route('dashboard') }}">
                            <i data-feather="airplay"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                @endcan

                @canany(['purchases.view', 'purchases.create', 'purchase.create.multiple', 'purchases.import'])
                    <li class="{{ $stocksOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#stocksMenu" role="button" aria-expanded="{{ $stocksOpen ? 'true' : 'false' }}" aria-controls="stocksMenu">
                            <i data-feather="shopping-cart"></i>
                            <span>Stocks</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $stocksOpen ? 'show' : '' }}" id="stocksMenu">
                            <ul class="nav-second-level">
                                @can('purchases.view')
                                    <li><a href="{{ route('allpurchases') }}" class="{{ request()->routeIs('allpurchases') ? 'active' : '' }}">All Stocks</a></li>
                                @endcan
                                @can('purchases.import')
                                    <li><a href="{{ route('purchase.importform') }}" class="{{ request()->routeIs('purchase.importform') ? 'active' : '' }}">Import Stocks</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['sales.view', 'sales.create'])
                    <li class="{{ $salesOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#salesMenu" role="button" aria-expanded="{{ $salesOpen ? 'true' : 'false' }}" aria-controls="salesMenu">
                            <i data-feather="briefcase"></i>
                            <span>Sell</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $salesOpen ? 'show' : '' }}" id="salesMenu">
                            <ul class="nav-second-level">
                                @can('sales.view')
                                    <li><a href="{{ route('allsales') }}" class="{{ request()->routeIs('allsales', 'saledetail') ? 'active' : '' }}">Sold Items</a></li>
                                @endcan
                                @can('sales.create')
                                    <li><a href="{{ route('new-sale') }}" class="{{ request()->routeIs('new-sale') ? 'active' : '' }}">New Sale</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['invoices.view', 'invoices.create'])
                    <li class="{{ $invoiceOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#invoiceMenu" role="button" aria-expanded="{{ $invoiceOpen ? 'true' : 'false' }}" aria-controls="invoiceMenu">
                            <i class="fa fa-file-invoice"></i>
                            <span>Invoice</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $invoiceOpen ? 'show' : '' }}" id="invoiceMenu">
                            <ul class="nav-second-level">
                                @can('invoices.view')
                                    <li><a href="{{ route('allinvoices') }}" class="{{ request()->routeIs('allinvoices', 'invoice-detail') ? 'active' : '' }}">Manage Invoice</a></li>
                                @endcan
                                @can('invoices.create')
                                    <li><a href="{{ route('newinvoice') }}" class="{{ request()->routeIs('newinvoice') ? 'active' : '' }}">New Invoice</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['reports.sales.view', 'reports.purchases.view', 'reports.customers.view', 'reports.charts.view'])
                    <li class="{{ $reportsOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#reportsMenu" role="button" aria-expanded="{{ $reportsOpen ? 'true' : 'false' }}" aria-controls="reportsMenu">
                            <i class="fa fa-chart-line"></i>
                            <span>Reports</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $reportsOpen ? 'show' : '' }}" id="reportsMenu">
                            <ul class="nav-second-level">
                                @can('reports.sales.view')
                                    <li><a href="{{ route('sale-report') }}" class="{{ request()->routeIs('sale-report') ? 'active' : '' }}">Sales</a></li>
                                    <li><a href="{{ route('profit-loss') }}" class="{{ request()->routeIs('profit-loss') ? 'active' : '' }}">Profit & Loss</a></li>
                                    <li><a href="{{ route('daily-closing') }}" class="{{ request()->routeIs('daily-closing') ? 'active' : '' }}">Daily Closing</a></li>
                                @endcan
                                @can('reports.purchases.view')
                                    <li><a href="{{ route('purchase-report') }}" class="{{ request()->routeIs('purchase-report') ? 'active' : '' }}">Purchase</a></li>
                                @endcan
                                @can('reports.charts.view')
                                    <li><a href="{{ route('saleschart') }}" class="{{ request()->routeIs('saleschart') ? 'active' : '' }}">Chart</a></li>
                                @endcan
                                @can('reports.customers.view')
                                    <li><a href="{{ route('customers') }}" class="{{ request()->routeIs('customers') ? 'active' : '' }}">Customers</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['expenses.view', 'expenses.create'])
                    <li class="{{ $expensesOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#expensesMenu" role="button" aria-expanded="{{ $expensesOpen ? 'true' : 'false' }}" aria-controls="expensesMenu">
                            <i class="fa fa-wallet"></i>
                            <span>Expense Tracker</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $expensesOpen ? 'show' : '' }}" id="expensesMenu">
                            <ul class="nav-second-level">
                                @can('expenses.view')
                                    <li><a href="{{ route('expenses') }}" class="{{ request()->routeIs('expenses') ? 'active' : '' }}">Expenses</a></li>
                                @endcan
                                <!-- @can('expenses.create')
                                    <li><a href="{{ route('expenses', ['open' => 'add']) }}" class="{{ request()->has('open') && request('open') === 'add' ? 'active' : '' }}">Add Expense</a></li>
                                @endcan -->
                            </ul>
                        </div>
                    </li>
                @endcanany

                @can(['parties.view', 'transactions.view'])
                    <li class="{{ $partyOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#partyMenu" role="button" aria-expanded="{{ $partyOpen ? 'true' : 'false' }}" aria-controls="partyMenu">
                            <i class="mdi mdi-account-cash-outline"></i>
                            <span>Party</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $partyOpen ? 'show' : '' }}" id="partyMenu">
                            <ul class="nav-second-level">
                                <li><a href="{{ route('parties.listparties') }}" class="{{ request()->routeIs('parties.listparties') ? 'active' : '' }}">Party List</a></li>
                                @can('transactions.view')
                                    <li><a href="{{ route('transactions.index') }}" class="{{ request()->routeIs('transactions.index') ? 'active' : '' }}">Transactions</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcan

                @canany(['ledger.view', 'ledger.create'])
                    <li class="{{ $ledgerOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#ledgerMenu" role="button" aria-expanded="{{ $ledgerOpen ? 'true' : 'false' }}" aria-controls="ledgerMenu">
                            <i class="fa fa-book"></i>
                            <span>Ledger</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $ledgerOpen ? 'show' : '' }}" id="ledgerMenu">
                            <ul class="nav-second-level">
                                @can('ledger.view')
                                    <li><a href="{{ route('ledger.index') }}" class="{{ request()->routeIs('ledger.index', 'ledger.index.alias') ? 'active' : '' }}">Ledger List</a></li>
                                @endcan
                                @can('ledger.create')
                                    <li><a href="{{ route('ledger.create') }}" class="{{ request()->routeIs('ledger.create') ? 'active' : '' }}">New Entry</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany

                @canany(['roles.view', 'roles.create', 'users.view', 'users.create'])
                    <li class="{{ $adminOpen ? 'menuitem-open menuitem-active' : '' }}">
                        <a data-toggle="collapse" href="#adminMenu" role="button" aria-expanded="{{ $adminOpen ? 'true' : 'false' }}" aria-controls="adminMenu">
                            <i class="fa fa-user-shield"></i>
                            <span>Admin Tools</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse {{ $adminOpen ? 'show' : '' }}" id="adminMenu">
                            <ul class="nav-second-level">
                                @can('roles.view')
                                    <li><a href="{{ route('roles.index') }}" class="{{ request()->routeIs('roles.*') ? 'active' : '' }}">Role List</a></li>
                                @endcan
                                @can('users.view')
                                    <li><a href="{{ route('users.index') }}" class="{{ request()->routeIs('users.*') ? 'active' : '' }}">Users List</a></li>
                                @endcan
                            </ul>
                        </div>
                    </li>
                @endcanany
            </ul>
        </div>

        <div class="clearfix"></div>
    </div>
</div>
