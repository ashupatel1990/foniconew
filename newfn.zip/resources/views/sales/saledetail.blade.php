@extends('layout.app')
@section('title', 'Sale Details')

@php
    use Carbon\Carbon;

    $expirydate = $sale->warranty_expiry_date ? Carbon::parse($sale->warranty_expiry_date) : null;
    $currentDate = Carbon::now();
@endphp

@section('content')
    <style>
        .sale-detail-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.10), transparent 28%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .sale-detail-wrap {
            max-width: 1180px;
            margin: 0 auto;
        }

        .sale-detail-hero {
            position: relative;
            overflow: hidden;
            border-radius: 26px;
            padding: 28px 30px;
            margin-bottom: 24px;
            background: linear-gradient(135deg, #163447 0%, #204e65 58%, #1abc9c 100%);
            color: #fff;
            box-shadow: 0 24px 50px rgba(22, 52, 71, 0.18);
        }

        .sale-detail-hero::after {
            content: "";
            position: absolute;
            right: -80px;
            bottom: -96px;
            width: 250px;
            height: 250px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .sale-detail-hero__eyebrow {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 14px;
        }

        .sale-detail-hero__title {
            color: #fff;
            font-size: 30px;
            line-height: 1.15;
            margin-bottom: 8px;
        }

        .sale-detail-hero__subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            margin-bottom: 0;
            max-width: 560px;
        }

        .sale-detail-hero__meta {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: flex-end;
        }

        .sale-detail-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 13px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: #fff;
            font-size: 12px;
            font-weight: 600;
        }

        .sale-detail-back {
            border-radius: 12px;
            padding: 10px 16px;
            font-weight: 600;
            background: rgba(255, 255, 255, 0.16);
            border: 1px solid rgba(255, 255, 255, 0.15);
            color: #fff;
            z-index: 9;
        }

        .sale-detail-back:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.22);
        }

        .sale-detail-grid {
            display: grid;
            grid-template-columns: 1.2fr 0.8fr;
            gap: 22px;
            margin-bottom: 22px;
        }

        .sale-detail-card {
            border: 0;
            border-radius: 22px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
            height: 100%;
        }

        .sale-detail-card .card-body {
            padding: 24px;
        }

        .sale-detail-card__eyebrow {
            color: #1abc9c;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 8px;
        }

        .sale-detail-card__title {
            color: #18324b;
            font-size: 22px;
            margin-bottom: 4px;
        }

        .sale-detail-card__subtitle {
            color: #7b8798;
            margin-bottom: 18px;
        }

        .sale-detail-info-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }

        .sale-detail-info {
            border: 1px solid #e6edf5;
            border-radius: 16px;
            background: #f7fafc;
            padding: 16px;
        }

        .sale-detail-info__label {
            color: #7b8798;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 6px;
        }

        .sale-detail-info__value {
            color: #18324b;
            font-size: 16px;
            font-weight: 700;
            line-height: 1.35;
        }

        .sale-detail-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            padding: 6px 12px;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 0.02em;
        }

        .sale-detail-badge--info {
            background: rgba(37, 99, 235, 0.12);
            color: #1d4ed8;
        }

        .sale-detail-badge--success {
            background: rgba(26, 188, 156, 0.12);
            color: #169c82;
        }

        .sale-detail-badge--danger {
            background: rgba(239, 68, 68, 0.12);
            color: #d63c49;
        }

        .sale-detail-badge--warning {
            background: rgba(245, 158, 11, 0.14);
            color: #b97700;
        }

        .sale-detail-summary-list {
            display: grid;
            gap: 12px;
        }

        .sale-detail-summary-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 14px 16px;
            border-radius: 16px;
            border: 1px solid #e6edf5;
            background: #f7fafc;
        }

        .sale-detail-summary-item__label {
            color: #607086;
            font-size: 13px;
            font-weight: 600;
        }

        .sale-detail-summary-item__value {
            color: #17324d;
            font-size: 20px;
            font-weight: 700;
            text-align: right;
        }

        .sale-detail-table-card {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .sale-detail-table-card .card-body {
            padding: 24px;
        }

        .sale-detail-table {
            margin-bottom: 0;
        }

        .sale-detail-table thead th {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #6f7f92;
            background: #f7fafc;
            border-top: 0;
            border-bottom: 1px solid #e6edf5;
            padding: 14px 16px;
            white-space: nowrap;
        }

        .sale-detail-table tbody td {
            padding: 18px 16px;
            border-top: 1px solid #eef3f8;
            vertical-align: top !important;
        }

        .sale-detail-index {
            color: #4f46e5;
            font-weight: 700;
        }

        .sale-detail-product {
            color: #18324b;
            font-weight: 700;
        }

        .sale-detail-submeta {
            color: #7b8798;
            font-size: 12px;
            margin-top: 5px;
        }

        .sale-detail-text-right {
            text-align: right;
        }

        .sale-detail-amount {
            color: #17324d;
            font-weight: 700;
            white-space: nowrap;
        }

        .sale-detail-empty {
            text-align: center;
            padding: 42px 20px;
            color: #7b8798;
        }

        @media (max-width: 991.98px) {
            .sale-detail-grid {
                grid-template-columns: 1fr;
            }

            .sale-detail-hero__meta {
                justify-content: flex-start;
                margin-top: 18px;
            }
        }

        @media (max-width: 767.98px) {
            .sale-detail-shell {
                padding-top: 18px;
            }

            .sale-detail-hero {
                padding: 24px 22px;
            }

            .sale-detail-hero__title {
                font-size: 25px;
            }

            .sale-detail-info-grid {
                grid-template-columns: 1fr;
            }

            .sale-detail-table {
                min-width: 920px;
            }

            .sale-detail-card .card-body,
            .sale-detail-table-card .card-body {
                padding: 20px;
            }
        }
    </style>

    <div class="container-fluid sale-detail-shell">
        <div class="sale-detail-wrap">
            <div class="sale-detail-hero">
                <div class="row align-items-center">
                    <div class="col-lg-8">
                        <div class="sale-detail-hero__eyebrow">Sales Overview</div>
                        <h1 class="sale-detail-hero__title">Sale #{{ $sale->invoice_no }}</h1>
                        <p class="sale-detail-hero__subtitle">
                            Review invoice details, sold items, payment information, and sale profitability from one organized screen.
                        </p>
                    </div>
                    <div class="col-lg-4">
                        <div class="sale-detail-hero__meta">
                            <span class="sale-detail-pill">
                                <i class="mdi mdi-calendar-month-outline"></i>
                                {{ $sale->invoice_date ? Carbon::parse($sale->invoice_date)->format('d M Y') : '-' }}
                            </span>
                            <a href="javascript:history.back();" class="btn sale-detail-back">
                                <i class="mdi mdi-arrow-left mr-1"></i>Back
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="sale-detail-grid">
                <div class="card sale-detail-card">
                    <div class="card-body">
                        <div class="sale-detail-card__eyebrow">Invoice Information</div>
                        <h2 class="sale-detail-card__title">Customer & Billing</h2>
                        <!-- <p class="sale-detail-card__subtitle">The key transaction and customer details for this completed sale.</p> -->

                        <div class="sale-detail-info-grid">
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Invoice No</div>
                                <div class="sale-detail-info__value">#{{ $sale->invoice_no }}</div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Sale Date</div>
                                <div class="sale-detail-info__value">
                                    {{ $sale->invoice_date ? Carbon::parse($sale->invoice_date)->format('d-m-Y') : '-' }}
                                </div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Customer Name</div>
                                <div class="sale-detail-info__value">{{ $sale->customer_name ?? '-' }}</div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Customer No</div>
                                <div class="sale-detail-info__value">{{ $sale->customer_no ?? '-' }}</div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Payment Type</div>
                                <div class="sale-detail-info__value">
                                    <span class="sale-detail-badge sale-detail-badge--info">
                                        {{ strtoupper($sale->payment_type ?? '-') }}
                                    </span>
                                </div>
                            </div>
                            <div class="sale-detail-info">
                                <div class="sale-detail-info__label">Sold By</div>
                                <div class="sale-detail-info__value">{{ $soldBy->name ?? '-' }}</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card sale-detail-card">
                    <div class="card-body">
                        <div class="sale-detail-card__eyebrow">Summary</div>
                        <h2 class="sale-detail-card__title">Financial Snapshot</h2>
                        <!-- <p class="sale-detail-card__subtitle">Quick view of totals, warranty status, and profitability.</p> -->

                        <div class="sale-detail-summary-list">
                            <div class="sale-detail-summary-item">
                                <div class="sale-detail-summary-item__label">Warranty Expiry</div>
                                <div class="sale-detail-summary-item__value">
                                    @if($sale->warranty_expiry_date)
                                        @if($expirydate && $expirydate->lt($currentDate))
                                            <span class="sale-detail-badge sale-detail-badge--danger">
                                                {{ Carbon::parse($sale->warranty_expiry_date)->format('d-m-Y') }} Expired
                                            </span>
                                        @else
                                            <span class="sale-detail-badge sale-detail-badge--success">
                                                {{ Carbon::parse($sale->warranty_expiry_date)->format('d-m-Y') }}
                                            </span>
                                        @endif
                                    @else
                                        <span class="sale-detail-badge sale-detail-badge--warning">Not Available</span>
                                    @endif
                                </div>
                            </div>

                            <div class="sale-detail-summary-item">
                                <div class="sale-detail-summary-item__label">Net Amount</div>
                                <div class="sale-detail-summary-item__value">₹{{ number_format($sale->net_amount ?? 0, 2) }}</div>
                            </div>

                            @if(in_array('super-admin', Auth::user()->roles->pluck('name')->toArray()))
                                <div class="sale-detail-summary-item">
                                    <div class="sale-detail-summary-item__label">Total Profit</div>
                                    <div class="sale-detail-summary-item__value" style="color:#169c82;">
                                        ₹{{ number_format($totalProfit ?? 0, 2) }}
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <div class="card sale-detail-table-card">
                <div class="card-body">
                    <div class="sale-detail-card__eyebrow">Sold Products</div>
                    <h2 class="sale-detail-card__title">Product Details</h2>
                    <!-- <p class="sale-detail-card__subtitle">Line-item breakdown of the devices included in this sale.</p> -->

                    <div class="table-responsive">
                        <table class="table sale-detail-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Product</th>
                                    <th>IMEI</th>
                                    <th>Color</th>
                                    <th>Storage</th>
                                    <th class="sale-detail-text-right">Purchase Price</th>
                                    <th class="sale-detail-text-right">Sell Price</th>
                                    <th class="sale-detail-text-right">Profit</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($sale->items as $index => $item)
                                    <tr>
                                        <td><span class="sale-detail-index">#{{ $index + 1 }}</span></td>
                                        <td>
                                            <div class="sale-detail-product">{{ $item->purchase->model ?? '-' }}</div>
                                            <div class="sale-detail-submeta">Invoice item {{ $index + 1 }}</div>
                                        </td>
                                        <td>{{ $item->purchase->imei ?? '-' }}</td>
                                        <td>{{ $item->purchase->color ?? '-' }}</td>
                                        <td>{{ $item->purchase->storage ?? '-' }} GB</td>
                                        <td class="sale-detail-text-right">
                                            <span class="sale-detail-amount">₹{{ number_format($item->purchase->purchase_price ?? 0, 2) }}</span>
                                        </td>
                                        <td class="sale-detail-text-right">
                                            <span class="sale-detail-amount">₹{{ number_format($item->unit_price ?? 0, 2) }}</span>
                                        </td>
                                        <td class="sale-detail-text-right">
                                            <span class="sale-detail-amount" style="color:#169c82;">
                                                ₹{{ number_format($item->profit ?? 0, 2) }}
                                            </span>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="8" class="sale-detail-empty">No items found for this sale.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
