@extends('layout.app')

@section('title')
    Dashboard
@endsection

@section('css')
    <style>
        .showdefault {
            display: block !important;
        }

        .dashboard-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.12), transparent 28%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .dashboard-hero {
            background: linear-gradient(135deg, #163447 0%, #204e65 55%, #1abc9c 100%);
            border-radius: 24px;
            padding: 28px 30px;
            color: #fff;
            box-shadow: 0 24px 50px rgba(22, 52, 71, 0.18);
            position: relative;
            overflow: hidden;
            margin-bottom: 24px;
        }

        .dashboard-hero::after {
            content: "";
            position: absolute;
            inset: auto -60px -90px auto;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .dashboard-hero__eyebrow {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            margin-bottom: 14px;
        }

        .dashboard-hero__title {
            color: #fff;
            font-size: 30px;
            line-height: 1.2;
            margin-bottom: 8px;
        }

        .dashboard-hero__subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            max-width: 540px;
            margin-bottom: 0;
        }

        .dashboard-clock {
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 18px;
            padding: 18px 20px;
            min-width: 240px;
            backdrop-filter: blur(6px);
        }

        .dashboard-clock__label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 8px;
        }

        .dashboard-clock__time {
            font-size: 28px;
            font-weight: 700;
            line-height: 1;
            margin-bottom: 8px;
        }

        .dashboard-clock__date {
            color: rgba(255, 255, 255, 0.85);
            margin-bottom: 0;
        }

        .dashboard-stat {
            border: 0;
            border-radius: 20px;
            box-shadow: 0 14px 35px rgba(15, 23, 42, 0.08);
            /* height: 100%; */
            display: flex;
            overflow: hidden;
        }

        .dashboard-stat .card-body {
            padding: 22px;
            min-height: 150px;
            display: flex;
            flex-direction: column;
            width: 100%;
        }

        .dashboard-stat__top {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 14px;
        }

        .dashboard-stat__icon {
            width: 56px;
            height: 56px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 16px;
            font-size: 24px;
            flex-shrink: 0;
        }

        .dashboard-stat__label {
            font-size: 13px;
            color: #6b7a90;
            margin-bottom: 0;
        }

        .dashboard-stat__value {
            font-size: 22px;
            line-height: 1;
            font-weight: 700;
            color: #17324d;
            text-align: center;
        }

        .dashboard-stat__meta {
            font-size: 13px;
            color: #8c98aa;
            margin-bottom: 0;
            margin-top: auto;
        }

        .dashboard-stat--teal .dashboard-stat__icon {
            background: rgba(26, 188, 156, 0.14);
            color: #169c82;
        }

        .dashboard-stat--indigo .dashboard-stat__icon {
            background: rgba(102, 88, 221, 0.14);
            color: #5c4bd1;
        }

        .dashboard-stat--cyan .dashboard-stat__icon {
            background: rgba(2, 192, 206, 0.14);
            color: #099eb0;
        }

        .dashboard-stat--amber .dashboard-stat__icon {
            background: rgba(255, 188, 0, 0.16);
            color: #c38b00;
        }

        .dashboard-section {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .dashboard-section .card-body {
            padding: 26px;
        }

        .dashboard-section__top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 22px;
        }

        .dashboard-section__eyebrow {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #1abc9c;
            margin-bottom: 8px;
        }

        .dashboard-section__title {
            font-size: 24px;
            color: #18324b;
            margin-bottom: 6px;
        }

        .dashboard-section__subtitle {
            margin-bottom: 0;
            color: #7b8798;
        }

        .dashboard-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: flex-end;
        }

        .dashboard-actions > * {
            min-width: 0;
        }

        .dashboard-btn {
            border-radius: 12px;
            padding: 10px 16px;
            font-weight: 600;
            box-shadow: none !important;
        }

        .dashboard-btn,
        .dashboard-btn.dropdown-toggle {
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .dashboard-btn.btn-primary {
            background: linear-gradient(135deg, #1abc9c 0%, #128a73 100%);
            border-color: transparent;
        }

        .dashboard-btn.btn-outline-primary {
            color: #18324b;
            border-color: #c8d5e3;
            background: #fff;
        }

        .dashboard-filter {
            background: #f7fafc;
            border: 1px solid #e4ebf3;
            border-radius: 18px;
            padding: 18px;
            margin-bottom: 22px;
        }

        .dashboard-filter .form-control,
        .dashboard-filter .btn {
            min-height: 46px;
            border-radius: 12px;
        }

        .dashboard-filter .form-control {
            border-color: #d7e1ec;
            box-shadow: none;
        }

        .dashboard-filter__label {
            display: block;
            color: #637289;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .dashboard-filter__date-group.is-hidden {
            display: none;
        }

        .dashboard-filter__row {
            align-items: end;
        }

        .sales-table {
            margin-bottom: 0;
        }

        .sales-table thead th {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #6f7f92;
            background: #f7fafc;
            border-top: 0;
            border-bottom: 1px solid #e6edf5;
            padding: 14px 16px;
        }

        .sales-table tbody td {
            padding: 18px 16px;
            border-top: 1px solid #eef3f8;
            vertical-align: top !important;
        }

        .sales-index {
            font-weight: 700;
            color: #19324b;
        }

        .sales-product {
            background: #f7fafc;
            border: 1px solid #e8eef5;
            border-radius: 14px;
            padding: 12px 14px;
        }

        .sales-product + .sales-product {
            margin-top: 10px;
        }

        .sales-product__title {
            font-weight: 700;
            color: #17324d;
            margin-bottom: 6px;
        }

        .sales-product__meta {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .sales-chip {
            display: inline-flex;
            align-items: center;
            background: #fff;
            border: 1px solid #dde7f0;
            color: #607086;
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 12px;
        }

        .sales-customer__name {
            font-weight: 700;
            color: #17324d;
            margin-bottom: 4px;
        }

        .sales-customer__contact a {
            color: #1abc9c;
            font-weight: 600;
        }

        .sales-date {
            color: #5f7188;
            font-weight: 600;
        }

        .sales-amount {
            text-align: right;
            white-space: nowrap;
        }

        .sales-amount__value {
            display: block;
            font-size: 20px;
            font-weight: 700;
            color: #17324d;
        }

        .sales-amount__label {
            color: #8a98aa;
            font-size: 12px;
        }

        .sales-actions {
            white-space: nowrap;
        }

        .sales-actions .btn {
            border-radius: 10px;
        }

        .sales-empty {
            padding: 56px 20px;
            text-align: center;
        }

        .sales-empty__icon {
            width: 76px;
            height: 76px;
            margin: 0 auto 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 20px;
            background: rgba(26, 188, 156, 0.12);
            color: #169c82;
            font-size: 30px;
        }

        .sales-empty h4 {
            color: #17324d;
            margin-bottom: 8px;
        }

        .sales-empty p {
            color: #8190a5;
            margin-bottom: 0;
        }

        .pagination-links {
            margin-top: 24px;
        }

        @media (max-width: 991.98px) {
            .dashboard-hero {
                padding: 24px 22px;
            }

            .dashboard-section__top {
                flex-direction: column;
            }

            .dashboard-actions {
                width: 100%;
                justify-content: flex-start;
            }
        }

        @media (max-width: 767.98px) {
            .dashboard-shell {
                padding-top: 18px;
            }

            .dashboard-hero__title {
                font-size: 24px;
            }

            .dashboard-clock {
                min-width: 100%;
                margin-top: 18px;
            }

            .dashboard-section .card-body {
                padding: 20px;
            }

            .dashboard-actions {
                width: 100%;
                gap: 12px;
            }

            .dashboard-actions > * {
                flex: 1 1 calc(50% - 6px);
            }

            .dashboard-actions .btn-group {
                display: flex;
            }

            .dashboard-actions .btn-group .dropdown-toggle,
            .dashboard-actions > .dashboard-btn {
                width: 100%;
            }

            .sales-table {
                min-width: 860px;
            }
        }
    </style>
@endsection

@section('content')
    <div class="container-fluid dashboard-shell">
        <div class="dashboard-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <span class="dashboard-hero__eyebrow">Business Overview</span> -->
                    <h1 class="dashboard-hero__title">
                        <span id="greeting">Hello</span>, {{ Auth()->user()->name }}
                    </h1>
                </div>
                <div class="col-lg-4">
                    <div class="dashboard-clock float-lg-right">
                        <!-- <div class="dashboard-clock__label">Live Dashboard Time</div> -->
                        <div class="dashboard-clock__time" id="currentTime">--:--:--</div>
                        <p class="dashboard-clock__date mb-0">
                            <i class="mdi mdi-calendar-month-outline mr-1"></i>{{ now()->format('d M Y') }}
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-xl-3 mb-3">
                <a href="{{ route('allpurchases') }}" class="d-block text-decoration-none">
                    <div class="card dashboard-stat dashboard-stat--teal">
                        <div class="card-body">
                            <div class="dashboard-stat__top">
                                <div class="dashboard-stat__icon">
                                    <i class="fe-layers"></i>
                                </div>
                                <div class="dashboard-stat__label">Stocks in Hand</div>
                            </div>
                            <div class="dashboard-stat__value">
                                <span data-plugin="counterup">{{ $stocksInHand }}</span>
                            </div>
                            <!-- <p class="dashboard-stat__meta mb-0">Current inventory available for sale</p> -->
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card dashboard-stat dashboard-stat--indigo">
                    <div class="card-body">
                        <div class="dashboard-stat__top">
                            <div class="dashboard-stat__icon">
                                <i class="fe-calendar"></i>
                            </div>
                            <div class="dashboard-stat__label">{{ $currentMonth }} Sales</div>
                        </div>
                        <div class="dashboard-stat__value">
                            ₹<span data-plugin="counterup">{{ $currentMonthSales }}</span>
                        </div>
                        <!-- <p class="dashboard-stat__meta mb-0">Total sales value recorded this month</p> -->
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card dashboard-stat dashboard-stat--cyan">
                    <div class="card-body">
                        <div class="dashboard-stat__top">
                            <div class="dashboard-stat__icon">
                                <i class="fe-shopping-bag"></i>
                            </div>
                            <div class="dashboard-stat__label">Items Sold in {{ $currentMonth }}</div>
                        </div>
                        <div class="dashboard-stat__value">
                            <span data-plugin="counterup">{{ $numberOfProductsSoldInMonth }}</span>
                        </div>
                        <!-- <p class="dashboard-stat__meta mb-0">Units billed successfully this month</p> -->
                    </div>
                </div>
            </div>

            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card dashboard-stat dashboard-stat--amber">
                    <div class="card-body">
                        <div class="dashboard-stat__top">
                            <div class="dashboard-stat__icon">
                                <i class="fe-dollar-sign"></i>
                            </div>
                            <div class="dashboard-stat__label">Today's Sales</div>
                        </div>
                        <div class="dashboard-stat__value">
                            <span data-plugin="counterup">{{ $totalSales }}</span>
                        </div>
                        <!-- <p class="dashboard-stat__meta mb-0">Revenue booked for the current day</p> -->
                    </div>
                </div>
            </div>
        </div>

        <div class="card dashboard-section">
            <div class="card-body">
                <div class="dashboard-section__top">
                    <div>
                        <div class="dashboard-section__eyebrow">Recent Activity</div>
                        <h2 class="dashboard-section__title">Sales Records [{{ $totalRecords }}]</h2>
                        <!-- <p class="dashboard-section__subtitle">
                            Review the latest transactions, filter by date, and jump into daily actions quickly.
                        </p> -->
                    </div>

                    <div class="dashboard-actions">
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-primary dashboard-btn dropdown-toggle"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Stock
                            </button>
                            <div class="dropdown-menu dropdown-menu-right mt-2">
                                <a class="dropdown-item" href="{{ route('purchase.create') }}">
                                    <i class="mdi mdi-plus-circle-outline mr-1"></i>Single Stock
                                </a>
                                <a class="dropdown-item" href="{{ route('purchase.create.multiple') }}">
                                    <i class="mdi mdi-plus-box-multiple-outline mr-1"></i>Multiple Stock
                                </a>
                            </div>
                        </div>

                        <a href="{{ route('newinvoice') }}" class="btn btn-primary dashboard-btn">
                            <i class="mdi mdi-receipt-text-plus-outline mr-1"></i>Create Invoice
                        </a>
                    </div>
                </div>

                <div class="dashboard-filter">
                    <form action="{{ route('dashboard') }}" method="GET" id="dashboardfilter">
                        <div class="form-row dashboard-filter__row">
                            <div class="col-12 col-md-4 col-lg-3 mb-3 mb-md-0">
                                <label class="dashboard-filter__label" for="findbystatus">Filter Sales By</label>
                                <select name="filtertime" id="findbystatus" class="form-control">
                                    <option value="">Select time period</option>
                                    <option value="today" @selected($filtertime == 'today')>Today</option>
                                    <option value="yesterday" @selected($filtertime == 'yesterday')>Yesterday</option>
                                    <option value="lastweek" @selected($filtertime == 'lastweek')>Last Week</option>
                                    <option value="month" @selected($filtertime == 'month')>This Month</option>
                                    <option value="custom" @selected($filtertime == 'custom')>Custom Range</option>
                                </select>
                            </div>

                            <div class="col-12 col-md-3 col-lg-2 mb-3 mb-md-0 dashboard-filter__date-group @if($filtertime != 'custom') is-hidden @endif"
                                id="fromdate-group">
                                <label class="dashboard-filter__label" for="fromdate">From Date</label>
                                <input type="date" id="fromdate" name="fromdate"
                                    class="form-control @if($filtertime == 'custom') showdefault @endif"
                                    value="{{ $fromdate }}" style="display:none;">
                            </div>

                            <div class="col-12 col-md-3 col-lg-2 mb-3 mb-md-0 dashboard-filter__date-group @if($filtertime != 'custom') is-hidden @endif"
                                id="todate-group">
                                <label class="dashboard-filter__label" for="todate">To Date</label>
                                <input type="date" id="todate" name="todate"
                                    class="form-control @if($filtertime == 'custom') showdefault @endif"
                                    value="{{ $todate }}" style="display:none;">
                            </div>

                            <div class="col-12 col-md-2 col-lg-2">
                                <label class="dashboard-filter__label d-none d-md-block">&nbsp;</label>
                                <button type="submit" class="btn btn-primary btn-block dashboard-btn">Apply Filter</button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    @if (count($todaysSales))
                        <table class="table sales-table">
                            <thead>
                                <tr>
                                    <th>Sr. No</th>
                                    <th>Item Detail</th>
                                    <th>Customer</th>
                                    <th>Payment</th>
                                    <th>Date</th>
                                    <th class="text-right">Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($todaysSales as $key => $sale)
                                    <tr>
                                        <td>
                                            <a href="{{ route('saledetail', $sale->id) }}" class="sales-index">
                                                #{{ ($todaysSales->currentPage() - 1) * $todaysSales->perPage() + $key + 1 }}
                                            </a>
                                        </td>
                                        <td>
                                            @if($sale->items->isEmpty())
                                                <div class="sales-product">
                                                    <div class="sales-product__title">No items</div>
                                                    <div class="sales-product__meta">
                                                        <span class="sales-chip">Sale record without attached item rows</span>
                                                    </div>
                                                </div>
                                            @else
                                                @foreach ($sale->items as $item)
                                                    @php
                                                        $p = $item->purchase;
                                                    @endphp
                                                    <div class="sales-product">
                                                        <div class="sales-product__title">{{ $p->model ?? 'Unknown Model' }}</div>
                                                        <!-- <div class="sales-product__meta">
                                                            <span class="sales-chip">Color: {{ $p->color ?? '-' }}</span>
                                                            <span class="sales-chip">Storage: {{ $p->storage ?? '-' }}</span>
                                                            <span class="sales-chip">IMEI: {{ $p->imei ?? '-' }}</span>
                                                            <span class="sales-chip">Qty: {{ $item->qty ?? 1 }}</span>
                                                        </div> -->
                                                    </div>
                                                @endforeach
                                            @endif
                                        </td>
                                        <td>
                                            <div class="sales-customer__name">{{ $sale->customer_name ?: 'Walk-in Customer' }}</div>
                                            @if($sale->customer_no)
                                                <div class="sales-customer__contact">
                                                    <a href="tel:{{ $sale->customer_no }}">{{ $sale->customer_no }}</a>
                                                </div>
                                            @else
                                                <div class="text-muted">No contact number</div>
                                            @endif
                                        </td>
                                        <td>
                                            @if($sale->payment_type == 'Cash')
                                                <span class="badge badge-soft-primary text-primary px-3 py-2">{{ $sale->payment_type }}</span>
                                            @elseif($sale->payment_type == 'Online')
                                                <span class="badge badge-soft-info text-info px-3 py-2">{{ $sale->payment_type }}</span>
                                            @elseif($sale->payment_type == 'Credit Card')
                                                <span class="badge badge-soft-warning text-warning px-3 py-2">{{ $sale->payment_type }}</span>
                                            @else
                                                <span class="badge badge-light px-3 py-2">{{ $sale->payment_type }}</span>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="sales-date">{{ Carbon\Carbon::parse($sale->invoice_date)->format('d M Y') }}</div>
                                        </td>
                                        <td class="sales-amount">
                                            <span class="sales-amount__value">₹{{ $sale->net_amount }}</span>
                                            <span class="sales-amount__label">Net amount</span>
                                        </td>
                                        <td class="sales-actions">
                                            @can('sales.view')
                                                <a href="{{ route('saledetail', $sale->id) }}" class="btn btn-light btn-sm mr-2" title="View">
                                                    <i class="mdi mdi-eye-outline"></i>
                                                </a>
                                            @endcan
                                            <form method="post" action="{{ route('delete-sale', $sale->id) }}"
                                                class="dashboard-delete-sale-form"
                                                style="display:inline;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                                    <i class="mdi mdi-trash-can-outline"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                        <div class="pagination-links">
                            {{ $todaysSales->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
                        </div>
                    @else
                        <div class="sales-empty">
                            <div class="sales-empty__icon">
                                <i class="mdi mdi-chart-timeline-variant"></i>
                            </div>
                            <h4>No sales found for this selection</h4>
                            <p>Try another date range, add stock, or create a new invoice to start recording activity.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        function updateTime() {
            const now = new Date();
            const rawHours = now.getHours();
            const period = rawHours >= 12 ? 'PM' : 'AM';
            const hours = String(((rawHours + 11) % 12) + 1).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');

            const currentTime = hours + ":" + minutes + ":" + seconds + " " + period;
            document.getElementById('currentTime').innerText = currentTime;

            let greeting = "Hello";
            const hour = rawHours;

            if (hour >= 5 && hour < 12) {
                greeting = "Good Morning";
            } else if (hour >= 12 && hour < 17) {
                greeting = "Good Afternoon";
            } else if (hour >= 17 && hour < 21) {
                greeting = "Good Evening";
            } else {
                greeting = "Good Night";
            }

            document.getElementById('greeting').innerText = greeting;
        }

        updateTime();
        setInterval(updateTime, 1000);

        const filterTimeSelect = document.getElementById('findbystatus');
        const fromDateInput = document.getElementById('fromdate');
        const toDateInput = document.getElementById('todate');
        const fromDateGroup = document.getElementById('fromdate-group');
        const toDateGroup = document.getElementById('todate-group');

        function toggleCustomDateFields() {
            const isCustomRange = filterTimeSelect && filterTimeSelect.value === 'custom';

            [fromDateInput, toDateInput].forEach((field) => {
                if (!field) {
                    return;
                }

                field.style.display = isCustomRange ? 'block' : 'none';
                field.classList.toggle('showdefault', isCustomRange);
            });

            [fromDateGroup, toDateGroup].forEach((group) => {
                if (!group) {
                    return;
                }

                group.classList.toggle('is-hidden', !isCustomRange);
            });
        }

        if (filterTimeSelect) {
            toggleCustomDateFields();
            filterTimeSelect.addEventListener('change', toggleCustomDateFields);
        }

        document.querySelectorAll('.dashboard-delete-sale-form').forEach((form) => {
            form.addEventListener('submit', function (event) {
                event.preventDefault();

                Swal.fire({
                    title: 'Delete this sale?',
                    text: "This action can't be undone.",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#ef4444',
                    cancelButtonColor: '#64748b',
                    confirmButtonText: 'Yes, delete it',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    </script>
@endsection
