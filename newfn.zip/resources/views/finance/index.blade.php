@extends('layout.app')

@section('css')
    <style>
        .error {
            color: #dc3545;
            font-weight: 400;
        }

        .transactions-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.12), transparent 25%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .transactions-hero {
            background: linear-gradient(135deg, #17324d 0%, #1f5b6b 52%, #19b78f 100%);
            border-radius: 24px;
            padding: 28px 30px;
            color: #fff;
            box-shadow: 0 24px 48px rgba(17, 34, 68, 0.16);
            margin-bottom: 24px;
        }

        .transactions-hero__eyebrow {
            font-size: 12px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: rgba(255, 255, 255, 0.74);
            margin-bottom: 10px;
        }

        .transactions-hero__title {
            color: #fff;
            font-size: 30px;
            margin-bottom: 8px;
        }

        .transactions-hero__subtitle {
            color: rgba(255, 255, 255, 0.82);
            margin-bottom: 0;
            max-width: 620px;
        }

        .transactions-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            justify-content: flex-end;
        }

        .transactions-btn {
            border-radius: 12px;
            min-height: 46px;
            font-weight: 600;
            padding: 10px 16px;
            box-shadow: none !important;
        }

        .transactions-btn.btn-success {
            background: linear-gradient(135deg, #1abc9c 0%, #11856f 100%);
            border-color: transparent;
        }

        .transactions-btn.btn-info {
            background: rgba(255, 255, 255, 0.16);
            border-color: rgba(255, 255, 255, 0.24);
            color: #fff;
        }

        .transactions-card {
            border: 0;
            border-radius: 22px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
            height: 100%;
        }

        .transactions-stat {
            color: #fff;
            padding: 20px 18px;
            position: relative;
        }

        .transactions-stat::after {
            content: "";
            position: absolute;
            width: 74px;
            height: 74px;
            border-radius: 18px;
            top: -18px;
            right: -18px;
            background: rgba(255, 255, 255, 0.12);
        }

        .transactions-stat__label {
            font-size: 12px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            opacity: 0.82;
            margin-bottom: 10px;
        }

        .transactions-stat__value {
            font-size: 26px;
            line-height: 1;
            font-weight: 700;
            margin-bottom: 0;
            color: #fff;
        }

        .transactions-stat--balance {
            background: linear-gradient(135deg, #5b3cc4 0%, #7c4dff 100%);
        }

        .transactions-stat--cash {
            background: linear-gradient(135deg, #1d6ee8 0%, #39a0ff 100%);
        }

        .transactions-stat--bank {
            background: linear-gradient(135deg, #128a9e 0%, #19b7cd 100%);
        }

        .transactions-stat--in {
            background: linear-gradient(135deg, #159957 0%, #36c57b 100%);
        }

        .transactions-stat--out {
            background: linear-gradient(135deg, #d4385a 0%, #f25f5c 100%);
        }

        .transactions-panel {
            background: #fff;
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .transactions-panel__body {
            padding: 24px;
        }

        .transactions-panel__header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 22px;
        }

        .transactions-panel__eyebrow {
            font-size: 12px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: #1abc9c;
            margin-bottom: 8px;
        }

        .transactions-panel__title {
            font-size: 24px;
            color: #18324b;
            margin-bottom: 6px;
        }

        .transactions-panel__subtitle {
            color: #7b8798;
            margin-bottom: 0;
        }

        .transactions-filter {
            background: #f7fafc;
            border: 1px solid #e4ebf3;
            border-radius: 20px;
            padding: 18px;
            margin-bottom: 22px;
        }

        .transactions-filter__row {
            display: flex;
            flex-wrap: nowrap;
            align-items: end;
            gap: 14px;
        }

        .transactions-filter__item {
            min-width: 0;
            margin-bottom: 0;
        }

        .transactions-filter__item--date {
            flex: 1.2 1 0;
        }

        .transactions-filter__item--type,
        .transactions-filter__item--source,
        .transactions-filter__item--payment {
            flex: 0.9 1 0;
        }

        .transactions-filter .form-group {
            margin-bottom: 0;
        }

        .transactions-filter label {
            display: block;
            color: #637289;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .transactions-filter .form-control {
            min-height: 46px;
            border-radius: 12px;
            border-color: #d6e1ec;
            box-shadow: none;
        }

        .transactions-filter__actions {
            display: flex;
            gap: 10px;
            align-items: flex-end;
            height: 100%;
            white-space: nowrap;
        }

        .transactions-filter__item--actions {
            flex: 0 0 auto;
        }

        .transactions-table-wrap {
            background: linear-gradient(180deg, #ffffff 0%, #f9fbfd 100%);
            border: 1px solid #e6edf5;
            border-radius: 20px;
            padding: 16px;
            overflow: hidden;
        }

        .transactions-table-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding-bottom: 14px;
            margin-bottom: 14px;
            border-bottom: 1px solid #ebf0f6;
        }

        .transactions-table-toolbar__title {
            font-size: 16px;
            font-weight: 700;
            color: #17324d;
            margin-bottom: 4px;
        }

        .transactions-table-toolbar__hint {
            font-size: 13px;
            color: #7b8798;
            margin-bottom: 0;
        }

        .transactions-table-toolbar__chip {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            border-radius: 999px;
            background: #eef6ff;
            color: #22577a;
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }

        #transactionTable {
            width: 100% !important;
            margin-bottom: 0 !important;
            border-collapse: separate;
            border-spacing: 0;
        }

        #transactionTable thead th {
            background: #f5f8fc;
            color: #5f7086;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-top: 0;
            border-bottom: 1px solid #e4ebf3;
            padding: 13px 12px;
            white-space: nowrap;
        }

        #transactionTable tbody td {
            vertical-align: middle;
            padding: 14px 12px;
            border-color: #edf2f7;
            color: #17324d;
            background: #fff;
        }

        #transactionTable tbody tr:hover td {
            background: #f8fbff;
        }

        #transactionTable .transactions-col-index,
        #transactionTable .transactions-col-date,
        #transactionTable .transactions-col-type,
        #transactionTable .transactions-col-source,
        #transactionTable .transactions-col-amount,
        #transactionTable .transactions-col-actions {
            white-space: nowrap;
        }

        #transactionTable .transactions-col-index {
            min-width: 56px;
        }

        #transactionTable .transactions-col-date {
            min-width: 118px;
        }

        #transactionTable .transactions-col-type {
            min-width: 116px;
        }

        #transactionTable .transactions-col-source {
            min-width: 108px;
        }

        #transactionTable .transactions-col-payment {
            min-width: 148px;
        }

        #transactionTable .transactions-col-amount {
            min-width: 144px;
        }

        #transactionTable .transactions-col-note {
            min-width: 220px;
            max-width: 260px;
        }

        #transactionTable .transactions-col-actions {
            min-width: 104px;
        }

        .transactions-type-badge,
        .transactions-source-badge {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 74px;
            border-radius: 999px;
            padding: 6px 12px;
            font-size: 12px;
            font-weight: 700;
        }

        .transactions-type-badge--credit {
            background: rgba(40, 167, 69, 0.12);
            color: #16934a;
        }

        .transactions-type-badge--debit {
            background: rgba(220, 53, 69, 0.12);
            color: #c12f49;
        }

        .transactions-source-badge {
            background: rgba(24, 50, 75, 0.08);
            color: #18324b;
        }

        .transactions-payment-method {
            display: inline-block;
            max-width: 150px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-weight: 600;
            color: #27445d;
        }

        .transactions-amount {
            font-weight: 700;
            white-space: nowrap;
        }

        .transactions-amount--credit {
            color: #16934a;
        }

        .transactions-amount--debit {
            color: #c12f49;
        }

        .transactions-note {
            display: inline-block;
            max-width: 240px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            color: #64748b;
        }

        .transactions-empty-note {
            color: #94a3b8;
        }

        .transactions-actions-cell {
            text-align: center;
        }

        .transactions-actions-cell .btn {
            border-radius: 10px;
            min-width: 36px;
            padding: 6px 9px;
        }

        .transactions-actions-group {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .transactions-actions-empty {
            color: #94a3b8;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 34px;
            height: 34px;
            border-radius: 10px;
            background: #f4f7fb;
            border: 1px solid #e1eaf2;
            font-size: 13px;
        }

        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_filter {
            margin-bottom: 14px;
        }

        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_filter,
        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_paginate {
            color: #637289;
            font-size: 13px;
        }

        .dataTables_wrapper .dataTables_filter label,
        .dataTables_wrapper .dataTables_length label {
            font-weight: 600;
        }

        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #d6e1ec;
            border-radius: 10px;
            min-height: 38px;
            padding: 6px 12px;
            background: #fff;
        }

        .dataTables_wrapper .dataTables_filter input {
            min-width: 240px;
        }

        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_paginate {
            margin-top: 16px;
        }

        div.dataTables_wrapper div.dataTables_scroll {
            border: 1px solid #ebf0f6;
            border-radius: 16px;
            overflow: hidden;
            background: #fff;
        }

        div.dataTables_wrapper div.dataTables_scrollHead {
            background: #f5f8fc;
            border-bottom: 1px solid #e4ebf3;
        }

        div.dataTables_wrapper div.dataTables_scrollHead table.dataTable,
        div.dataTables_wrapper div.dataTables_scrollBody table.dataTable {
            margin-bottom: 0 !important;
        }

        div.dataTables_wrapper div.dataTables_scrollBody {
            scrollbar-width: thin;
            scrollbar-color: #b8c7d9 #edf3f8;
        }

        div.dataTables_wrapper div.dataTables_scrollBody::-webkit-scrollbar {
            height: 10px;
            width: 10px;
        }

        div.dataTables_wrapper div.dataTables_scrollBody::-webkit-scrollbar-track {
            background: #edf3f8;
        }

        div.dataTables_wrapper div.dataTables_scrollBody::-webkit-scrollbar-thumb {
            background: #b8c7d9;
            border-radius: 999px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border-radius: 10px !important;
            border: 1px solid transparent !important;
            color: #4c627c !important;
            background: transparent !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current,
        .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
            background: #17324d !important;
            color: #fff !important;
            border-color: #17324d !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: #eef4fb !important;
            border-color: #d6e1ec !important;
            color: #17324d !important;
        }

        .modal-content {
            border: 0;
            border-radius: 18px;
            box-shadow: 0 24px 48px rgba(15, 23, 42, 0.14);
        }

        .modal-header,
        .modal-footer {
            border-color: #edf2f7;
        }

        @media (max-width: 991.98px) {
            .transactions-hero {
                padding: 24px 22px;
            }

            .transactions-panel__header {
                flex-direction: column;
            }

            .transactions-actions {
                justify-content: flex-start;
            }
        }

        @media (max-width: 767.98px) {
            .transactions-shell {
                padding-top: 18px;
            }

            .transactions-hero__title {
                font-size: 24px;
            }

            .transactions-actions {
                width: 100%;
            }

            .transactions-actions > * {
                flex: 1 1 calc(50% - 6px);
            }

            .transactions-panel__body {
                padding: 18px;
            }

            .transactions-filter {
                padding: 16px;
            }

            .transactions-filter__row {
                flex-wrap: wrap;
                gap: 0;
            }

            .transactions-filter__item,
            .transactions-filter__item--date,
            .transactions-filter__item--type,
            .transactions-filter__item--source,
            .transactions-filter__item--payment,
            .transactions-filter__item--actions {
                flex: 0 0 100%;
                width: 100%;
                margin-bottom: 1rem;
            }

            .transactions-filter__actions {
                flex-direction: column;
            }

            .transactions-filter__actions .btn {
                width: 100%;
            }

            .transactions-table-toolbar {
                flex-direction: column;
                align-items: flex-start;
            }

            .transactions-table-wrap {
                padding: 12px;
            }

            #transactionTable th,
            #transactionTable td {
                font-size: 0.85rem;
            }

            .dataTables_wrapper .dataTables_filter input {
                min-width: 0;
                width: 100%;
            }
        }
    </style>
@endsection

@section('title')
    Transaction List
@endsection
@section('content')
    <div class="container-fluid transactions-shell">
        <div class="transactions-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="transactions-hero__eyebrow">Finance Overview</div> -->
                    <h1 class="transactions-hero__title">Transaction Management</h1>
                    <p class="transactions-hero__subtitle">
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="transactions-actions mt-3 mt-lg-0">
                        <a href="{{ route('transactions.resync') }}" class="btn transactions-btn btn-info">
                            <i class="fas fa-sync-alt mr-1"></i>Resync Balances
                        </a>
                        <button type="button" class="btn transactions-btn btn-success" data-toggle="modal" data-target="#transactionModal">
                            <i class="fas fa-plus-circle mr-1"></i>Add Transaction
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--balance">
                        <div class="transactions-stat__label">Total Balance</div>
                        <h5 class="transactions-stat__value">{{ config('constant.currency') }} <span id="openingBalance">0</span></h5>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--cash">
                        <div class="transactions-stat__label">Cash Balance</div>
                        <h5 class="transactions-stat__value">{{ config('constant.currency') }} <span id="cashBalance">0</span></h5>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--bank">
                        <div class="transactions-stat__label">Bank Balance</div>
                        <h5 class="transactions-stat__value">{{ config('constant.currency') }} <span id="bankBalance">0</span></h5>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--in">
                        <div class="transactions-stat__label">Total In</div>
                        <h5 class="transactions-stat__value">{{ config('constant.currency') }} <span id="totalIn">0</span></h5>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl mb-3">
                <div class="transactions-card">
                    <div class="transactions-stat transactions-stat--out">
                        <div class="transactions-stat__label">Total Out</div>
                        <h5 class="transactions-stat__value">{{ config('constant.currency') }} <span id="totalOut">0</span></h5>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @if (session('status'))
                <div class="alert alert-success" id="statusMessage">
                    {{ session('status') }}
                </div>
                @endif
                @if (session('error'))
                <div class="alert alert-danger" id="errorMessage">
                    {{ session('error') }}
                </div>
                @endif
                <div class="transactions-panel">
                    <div class="transactions-panel__body">
                        <div class="transactions-panel__header">
                            <div>
                                <div class="transactions-panel__eyebrow">Recent Activity</div>
                                <h2 class="transactions-panel__title">All Transactions</h2>
                            </div>
                        </div>

                        <form id="filterForm" class="transactions-filter">
                            <div class="transactions-filter__row">
                                <div class="transactions-filter__item transactions-filter__item--date">
                                    <div class="form-group">
                                        <label for="date_from">Date From</label>
                                        <input type="date" class="form-control" id="date_from" name="date_from">
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--date">
                                    <div class="form-group">
                                        <label for="date_to">Date To</label>
                                        <input type="date" class="form-control" id="date_to" name="date_to">
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--type">
                                    <div class="form-group">
                                        <label for="filter_transaction_type">Transaction Type</label>
                                        <select class="form-control" id="filter_transaction_type" name="transaction_type">
                                            <option value="">All</option>
                                            <option value="credit">IN</option>
                                            <option value="debit">OUT</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--source">
                                    <div class="form-group">
                                        <label for="filter_source">Source</label>
                                        <select class="form-control" id="filter_source" name="source">
                                            <option value="all">All</option>
                                            <option value="manual">Manual</option>
                                            <option value="sale">Sale</option>
                                            <option value="purchase">Purchase</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--payment">
                                    <div class="form-group">
                                        <label for="filter_payment_method">Payment Method</label>
                                        <select class="form-control" id="filter_payment_method" name="payment_method">
                                            <option value="">All</option>
                                            @foreach($paymentMethods as $method)
                                                <option value="{{ $method->id }}">{{ $method->method_name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="transactions-filter__item transactions-filter__item--actions">
                                    <div class="transactions-filter__actions">
                                        <button type="button" id="applyFilter" class="btn btn-primary transactions-btn">Apply Filter</button>
                                        <button type="button" id="resetFilter" class="btn btn-light transactions-btn">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <div class="transactions-table-wrap">
                            <div class="transactions-table-toolbar">
                                <div>
                                    <div class="transactions-table-toolbar__title">Transaction Register</div>
                                    <p class="transactions-table-toolbar__hint">A cleaner, compact ledger view with quick actions and easier scanning.</p>
                                </div>
                                <div class="transactions-table-toolbar__chip">
                                    <i class="fas fa-arrows-alt-h"></i>
                                    <span>Scroll for more columns on smaller screens</span>
                                </div>
                            </div>
                            <table id="transactionTable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Payment Date</th>
                                        <th>Type</th>
                                        <th>Source</th>
                                        <th>Payment Method</th>
                                        <th>Amount</th>
                                        <th>Note</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Transaction Modal -->
    <div class="modal fade" id="transactionModal" tabindex="-1" role="dialog" aria-labelledby="transactionModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="transactionModalLabel">Add Transaction</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="transactionForm" action="{{ route('transactions.store') }}" method="POST">
                    <input type="hidden" name="id" id="transactionId">
                    @csrf
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="party_id">Party <span class="text-danger">*</span></label>
                                    <select class="form-control @error('party_id') is-invalid @enderror" id="party_id" name="party_id">
                                        <option value="">Select Party</option>
                                        @foreach($parties as $party)
                                            <option value="{{ $party->id }}" {{ old('party_id') == $party->id ? 'selected' : '' }}>{{ $party->party_name }}</option>
                                        @endforeach
                                    </select>
                                    @error('party_id')  
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="payment_date">Payment Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="payment_date" name="payment_date" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="transaction_type">Transaction Type <span class="text-danger">*</span></label>
                                    <select class="form-control" id="transaction_type" name="transaction_type" required>
                                        <option value="">Select Type</option>
                                        <option value="credit">IN</option>
                                        <option value="debit">OUT</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="payment_method">Payment Method <span class="text-danger">*</span></label>
                                    <select class="form-control" id="payment_method" name="payment_method" required>
                                        <option value="">Select Method</option>
                                        @foreach($paymentMethods as $method)
                                            <option value="{{ $method->id }}">{{ $method->method_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="amount">Amount <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">{{ config('constant.currency') }}</span>
                                        </div>
                                        <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="0" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="note">Note</label>
                                    <textarea class="form-control" id="note" name="note" rows="3"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save Transaction</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script type="text/javascript">
        $(function () {
            const currency = '{{ config('constant.currency') }}';
            let table; // Declare table variable in higher scope

            // Initialize Bootstrap modal
            $('#transactionModal').modal({
                show: false,
                backdrop: 'static',
                keyboard: false
            });

            // Function to get filter parameters
            function getFilterParams() {
                return {
                    date_from: $('#date_from').val(),
                    date_to: $('#date_to').val(),
                    transaction_type: $('#filter_transaction_type').val(),
                    payment_method: $('#filter_payment_method').val(),
                    source: $('#filter_source').val() || 'all'
                };
            }

            table = $('#transactionTable').DataTable({
                processing: true,
                serverSide: true,
                scrollX: true,
                autoWidth: false,
                scrollCollapse: true,
                pageLength: 10,
                order: [[1, 'desc']],
                language: {
                    search: '',
                    searchPlaceholder: 'Search date, method, amount, note...',
                    lengthMenu: 'Show _MENU_ rows',
                    info: 'Showing _START_ to _END_ of _TOTAL_ transactions',
                    infoEmpty: 'No transactions available',
                    zeroRecords: 'No matching transactions found',
                    paginate: {
                        previous: 'Prev',
                        next: 'Next'
                    }
                },
                ajax: {
                    url: "{{ route('transactions.index') }}",
                    data: function(d) {
                        return $.extend({}, d, getFilterParams());
                    }
                },
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex', className: 'text-center transactions-col-index'},
                    {data: 'payment_date', name: 'payment_date', className: 'text-center transactions-col-date', render: function(data) {
                        return moment(data).format('DD/MM/YYYY');
                    }},
                    {data: 'transaction_type', name: 'transaction_type', className: 'text-center transactions-col-type', render: function(data, type, row) {
                        const label = row.transaction_type === 'debit' ? 'OUT' : 'IN';
                        const badgeClass = row.transaction_type === 'debit'
                            ? 'transactions-type-badge transactions-type-badge--debit'
                            : 'transactions-type-badge transactions-type-badge--credit';
                        return '<span class="' + badgeClass + '">' + label + '</span>';
                    }},
                    {data: 'source', name: 'source', className: 'text-center transactions-col-source', render: function(data) {
                        return '<span class="transactions-source-badge">' + (data ? data : 'Manual') + '</span>';
                    }},
                    {data: 'payment_method', name: 'payment_method', className: 'text-center transactions-col-payment', render: function(data, type, row) {
                        if (row.paymentMethod && row.paymentMethod.method_name) {
                            return '<span class="transactions-payment-method">' + row.paymentMethod.method_name + '</span>';
                        }
                        if (row.source === 'Sale') {
                            return '<span class="transactions-payment-method">Invoice</span>';
                        }
                        if (row.source === 'Purchase') {
                            return '<span class="transactions-payment-method">Purchase</span>';
                        }
                        return '<span class="transactions-payment-method">-</span>';
                    }},
                    {data: 'amount', name: 'amount', className: 'text-center transactions-col-amount', render: function(data, type, row) {
                        const amountClass = row.transaction_type === 'debit'
                            ? 'transactions-amount transactions-amount--debit'
                            : 'transactions-amount transactions-amount--credit';
                        return '<span class="' + amountClass + '">' + (row.transaction_type === 'debit' ? '- ' : '+ ') + currency + ' ' + data + '</span>';
                    }},
                    {data: 'note', name: 'note', className: 'text-left transactions-col-note', render: function(data) {
                        if (data && data.length > 50) {
                            return '<span class="transactions-note note-tooltip" data-toggle="tooltip" data-placement="top" title="' + data + '">' + data + '</span>';
                        }
                        if (data) {
                            return '<span class="transactions-note">' + data + '</span>';
                        }
                        return '<span class="transactions-empty-note">No note</span>';
                    }},
                    // {
                    //     data: 'created_at',
                    //     name: 'created_at',
                    //     className: 'text-center',
                    //     render: function(data) {
                    //         return moment(data).format('DD/MM/YYYY HH:mm:ss');
                    //     }
                    // },
                    {data: 'action', name: 'action', className: 'text-center transactions-actions-cell transactions-col-actions', orderable: false, searchable: false, render: function(data, type, row) {
                        if (row.source === 'Manual') {
                            return '<div class="transactions-actions-group">' +
                                '<button class="btn btn-primary btn-sm edit-transaction" data-id="' + row.id + '" title="Edit transaction"><i class="fas fa-edit"></i></button>' +
                                '<button class="btn btn-danger btn-sm delete-transaction" data-id="' + row.id + '" title="Delete transaction"><i class="fas fa-trash"></i></button>' +
                            '</div>';
                        }
                        return '<span class="transactions-actions-empty" title="Locked"><i class="fas fa-lock"></i></span>';
                    }},
                ],
                initComplete: function(settings, json) {
                    if (json) {
                        if (json.openingBalance !== undefined) {
                            $('#openingBalance').text(json.openingBalance);
                        }
                        if (json.cashBalance !== undefined) {
                            $('#cashBalance').text(json.cashBalance);
                        }
                        if (json.bankBalance !== undefined) {
                            $('#bankBalance').text(json.bankBalance);
                        }
                        if (json.totalIn !== undefined) {
                            $('#totalIn').text(json.totalIn);
                        }
                        if (json.totalOut !== undefined) {
                            $('#totalOut').text(json.totalOut);
                        }
                    }

                    $('#transactionTable').closest('.dataTables_wrapper').find('.dataTables_filter input').attr('autocomplete', 'off');
                },
                drawCallback: function() {
                    this.api().columns.adjust();
                }
            });

            setTimeout(function() {
                table.columns.adjust().draw(false);
            }, 0);

            $(window).on('resize', function() {
                table.columns.adjust();
            });

            // Apply filter button click handler
            $('#applyFilter').on('click', function() {
                table.ajax.reload(function(json) {
                    if (json) {
                        if (json.openingBalance !== undefined) {
                            $('#openingBalance').text(json.openingBalance);
                        }
                        if (json.cashBalance !== undefined) {
                            $('#cashBalance').text(json.cashBalance);
                        }
                        if (json.bankBalance !== undefined) {
                            $('#bankBalance').text(json.bankBalance);
                        }
                        if (json.totalIn !== undefined) {
                            $('#totalIn').text(json.totalIn);
                        }
                        if (json.totalOut !== undefined) {
                            $('#totalOut').text(json.totalOut);
                        }
                    }
                });
            });

            $('#resetFilter').on('click', function() {
                $('#filterForm')[0].reset();
                table.order([1, 'desc']).ajax.reload();
            });

            // Delete transaction handler
            $(document).on('click', '.delete-transaction', function() {
                const transactionId = $(this).data('id');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "/admin/transactions/delete/" + transactionId,
                            type: 'DELETE',
                            data: {
                                _token: '{{ csrf_token() }}'
                            },
                            success: function(response) {
                                table.ajax.reload(function(json) {
                                    if (json) {
                                        if (json.openingBalance !== undefined) {
                                            $('#openingBalance').text(json.openingBalance);
                                        }
                                        if (json.cashBalance !== undefined) {
                                            $('#cashBalance').text(json.cashBalance);
                                        }
                                        if (json.bankBalance !== undefined) {
                                            $('#bankBalance').text(json.bankBalance);
                                        }
                                        if (json.totalIn !== undefined) {
                                            $('#totalIn').text(json.totalIn);
                                        }
                                        if (json.totalOut !== undefined) {
                                            $('#totalOut').text(json.totalOut);
                                        }
                                    }
                                });
                                $('#openingBalance').text(response.data.openingBalance);
                                $('#totalIn').text(response.data.totalIn);
                                $('#totalOut').text(response.data.totalOut);
                                Swal.fire(
                                    'Deleted!',
                                    'Transaction has been deleted.',
                                    'success'
                                );
                            },
                            error: function(xhr) {
                                Swal.fire(
                                    'Error!',
                                    'Something went wrong while deleting the transaction.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            });

            // Edit transaction handler
            $(document).on('click', '.edit-transaction', function() {
                const transactionId = $(this).data('id');

                // Reset form and clear validation errors
                $('#transactionForm')[0].reset();
                $('#transactionForm').validate().resetForm();

                // Set transaction ID in hidden field
                $('#transactionId').val(transactionId);

                // Fetch transaction data
                $.ajax({
                    url: "/admin/transactions/edit/" + transactionId,
                    type: 'GET',
                    success: function(response) {
                        response = response.data;

                        // Pre-fill form fields
                        $('#transactionForm #party_id').val(response.party_id).trigger('change');
                        $('#transactionForm #payment_date').val(response.payment_date);
                        $('#transactionForm #transaction_type').val(response.transaction_type).trigger('change');
                        $('#transactionForm #payment_method').val(response.payment_method).trigger('change');
                        $('#transactionForm #amount').val(response.amount);
                        $('#transactionForm #note').val(response.note);
                        $('#transactionForm #transactionId').val(response.id);

                        // Show modal
                        $('#transactionModal').modal('show');
                    },
                    error: function(xhr) {
                        toastr.error('Error fetching transaction details');
                    }
                });
            });

            // Form validation
            $("#transactionForm").validate({
                rules: {
                    party_id: "required",
                    payment_date: "required",
                    transaction_type: "required",
                    payment_method: "required",
                    amount: {
                        required: true,
                        min: 0.01
                    }
                },
                messages: {
                    party_id: "Please select Party",
                    payment_date: "Please select payment date",
                    transaction_type: "Please select transaction type",
                    payment_method: "Please select payment method",
                    amount: {
                        required: "Please enter amount",
                        min: "Amount must be greater than 0"
                    }
                },
                submitHandler: function(form) {
                    var formData = $(form).serialize();
                    $.ajax({
                        url: $(form).attr('action'),
                        type: 'POST',
                        data: formData,
                        success: function(response) {
                            toastr.success(response.message);

                            // Try normal hide
                            $('#transactionModal').modal('hide');

                            // Force hide backup
                            setTimeout(() => {
                                $('#transactionModal').removeClass('show').hide();
                                $('body').removeClass('modal-open');
                                $('.modal-backdrop').remove();
                            }, 300);

                            // Reset form and select2 fields
                            $('#transactionForm')[0].reset();

                            // Update UI
                            table.ajax.reload(function(json) {
                                if (json) {
                                    if (json.openingBalance !== undefined) {
                                        $('#openingBalance').text(json.openingBalance);
                                    }
                                    if (json.totalIn !== undefined) {
                                        $('#totalIn').text(json.totalIn);
                                    }
                                    if (json.cashBalance !== undefined) {
                                        $('#cashBalance').text(json.cashBalance);
                                    }
                                    if (json.bankBalance !== undefined) {
                                        $('#bankBalance').text(json.bankBalance);
                                    }
                                    if (json.totalOut !== undefined) {
                                        $('#totalOut').text(json.totalOut);
                                    }
                                }
                            });
                        },
                        error: function(xhr) {
                            toastr.error('Error storing transaction');
                        }
                    });
                    return false;
                }
            });

            // Set default date to today
            $('#payment_date').val(new Date().toISOString().split('T')[0]);
        });
    </script>
@endsection
