<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Log In | FONICO Mobile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="We deal with BUY Sale Exchanges of Old Phones" name="description" />
    <meta content="FONICO Mobile" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" href="{{ asset('assets/images/new_logo/favicon.ico') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" id="bs-default-stylesheet" />
    <link href="{{ asset('assets/css/app.min.css') }}" rel="stylesheet" type="text/css" id="app-default-stylesheet" />
    <link href="{{ asset('assets/css/bootstrap-dark.min.css') }}" rel="stylesheet" type="text/css" id="bs-dark-stylesheet" disabled />
    <link href="{{ asset('assets/css/app-dark.min.css') }}" rel="stylesheet" type="text/css" id="app-dark-stylesheet" disabled />
    <link href="{{ asset('assets/css/icons.min.css') }}" rel="stylesheet" type="text/css" />

    <style>
        :root {
            --fonico-ink: #112939;
            --fonico-ink-soft: #1f4458;
            --fonico-mint: #3ec7a6;
            --fonico-mint-deep: #23a184;
            --fonico-sand: #eef5f3;
            --fonico-line: rgba(17, 41, 57, 0.12);
            --fonico-copy: #527082;
            --fonico-white: #ffffff;
            --fonico-shadow: 0 30px 80px rgba(17, 41, 57, 0.18);
        }

        * {
            box-sizing: border-box;
        }

        body {
            min-height: 100vh;
            margin: 0;
            font-family: "Plus Jakarta Sans", sans-serif;
            background:
                radial-gradient(circle at top left, rgba(62, 199, 166, 0.22), transparent 30%),
                radial-gradient(circle at bottom right, rgba(17, 41, 57, 0.16), transparent 30%),
                linear-gradient(135deg, #f6fbfa 0%, #edf4f2 42%, #e5efec 100%);
            color: var(--fonico-ink);
        }

        .login-shell {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .login-frame {
            width: 100%;
            /* max-width: 1080px; */
            display: grid;
            grid-template-columns: 1.08fr 0.92fr;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(255, 255, 255, 0.65);
            border-radius: 30px;
            overflow: hidden;
            box-shadow: var(--fonico-shadow);
            backdrop-filter: blur(14px);
        }

        .login-brand {
            position: relative;
            padding: 48px;
            background:
                linear-gradient(160deg, rgba(17, 41, 57, 0.96) 0%, rgba(22, 52, 71, 0.97) 55%, rgba(35, 161, 132, 0.92) 100%);
            color: var(--fonico-white);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            min-height: 700px;
            text-align: center;
        }

        .login-brand::before,
        .login-brand::after {
            content: "";
            position: absolute;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.08);
        }

        .login-brand::before {
            width: 240px;
            height: 240px;
            top: -72px;
            right: -80px;
        }

        .login-brand::after {
            width: 180px;
            height: 180px;
            bottom: 58px;
            left: -50px;
        }

        .brand-top,
        .brand-content,
        .brand-metrics {
            position: relative;
            z-index: 1;
            width: 100%;
        }

        .brand-badge {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 14px;
            min-width: 220px;
            padding: 20px 24px 18px;
            border-radius: 28px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.14);
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06);
        }

        .brand-badge img {
            /* width: 96px; */
            height: 96px;
            object-fit: cover;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.96);
            /* padding: 10px; */
            box-shadow: 0 14px 32px rgba(0, 0, 0, 0.18);
        }

        .brand-badge__title {
            display: block;
            font-size: 19px;
            font-weight: 800;
            letter-spacing: 0.08em;
        }

        .brand-badge__text {
            display: block;
            color: rgba(255, 255, 255, 0.72);
            font-size: 12px;
            margin-top: 4px;
            letter-spacing: 0.16em;
            text-transform: uppercase;
        }

        .brand-content {
            max-width: 520px;
            margin: 42px auto;
        }

        .brand-content h1 {
            color: var(--fonico-white);
            font-size: clamp(2.2rem, 4vw, 3.8rem);
            line-height: 1.05;
            margin-bottom: 18px;
            font-weight: 800;
            letter-spacing: -0.04em;
        }

        .brand-content p {
            font-size: 1rem;
            line-height: 1.8;
            color: rgba(255, 255, 255, 0.76);
            margin-bottom: 0;
        }

        .brand-metrics {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 14px;
            max-width: 640px;
            margin: 0 auto;
        }

        .brand-metric {
            padding: 18px;
            border-radius: 22px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(10px);
        }

        .brand-metric__label {
            font-size: 12px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: rgba(255, 255, 255, 0.62);
            margin-bottom: 8px;
        }

        .brand-metric__value {
            font-size: 1rem;
            font-weight: 700;
            color: var(--fonico-white);
            line-height: 1.4;
        }

        .login-panel {
            padding: 52px 48px 34px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.98) 0%, #f8fbfa 100%);
        }

        .login-panel__inner {
            width: 100%;
            max-width: 420px;
            margin: 0 auto;
            text-align: center;
        }

        .panel-kicker {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            border-radius: 999px;
            background: #e7f6f1;
            color: var(--fonico-mint-deep);
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            margin-bottom: 20px;
            justify-content: center;
        }

        .login-panel h2 {
            font-size: 2rem;
            line-height: 1.1;
            font-weight: 800;
            color: var(--fonico-ink);
            margin-bottom: 12px;
            letter-spacing: -0.03em;
        }

        .login-panel__lead {
            color: var(--fonico-copy);
            font-size: 0.98rem;
            line-height: 1.7;
            margin-bottom: 28px;
        }

        .alert {
            border-radius: 18px;
            padding: 14px 16px;
            border: 0;
            margin-bottom: 18px;
        }

        .alert ul {
            padding-left: 18px;
            margin-bottom: 0;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 9px;
            font-size: 13px;
            font-weight: 700;
            color: var(--fonico-ink);
            letter-spacing: 0.01em;
            text-align: left;
        }

        .field-shell {
            position: relative;
        }

        .form-control {
            height: 56px;
            border-radius: 18px;
            border: 1px solid var(--fonico-line);
            background: var(--fonico-white);
            color: var(--fonico-ink);
            padding: 16px 18px;
            font-size: 15px;
            transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
        }

        .form-control:focus {
            border-color: rgba(35, 161, 132, 0.75);
            box-shadow: 0 0 0 4px rgba(62, 199, 166, 0.15);
        }

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 14px;
            transform: translateY(-50%);
            border: 0;
            background: transparent;
            color: #6e8796;
            padding: 6px;
            line-height: 1;
            cursor: pointer;
        }

        .password-toggle:focus {
            outline: none;
            color: var(--fonico-mint-deep);
        }

        .remember-row {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin: 8px 0 24px;
        }

        .custom-checkbox {
            padding-left: 0;
            display: flex;
            align-items: center;
            min-height: 24px;
        }

        .custom-checkbox .custom-control-input {
            width: 18px;
            height: 18px;
            margin: 0 10px 0 0;
            position: static;
            opacity: 1;
        }

        .custom-checkbox .custom-control-label {
            position: static;
            padding-left: 0;
            color: var(--fonico-copy);
            font-weight: 600;
            cursor: pointer;
            text-align: left;
        }

        .custom-checkbox .custom-control-label::before,
        .custom-checkbox .custom-control-label::after {
            display: none;
        }

        .signin-btn {
            height: 58px;
            border: 0;
            border-radius: 18px;
            background: linear-gradient(135deg, var(--fonico-mint) 0%, var(--fonico-mint-deep) 100%);
            color: var(--fonico-white);
            font-size: 15px;
            font-weight: 800;
            letter-spacing: 0.01em;
            box-shadow: 0 18px 36px rgba(35, 161, 132, 0.22);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .signin-btn:hover,
        .signin-btn:focus {
            color: var(--fonico-white);
            transform: translateY(-1px);
            box-shadow: 0 22px 40px rgba(35, 161, 132, 0.26);
        }

        .panel-footer {
            margin-top: 22px;
            text-align: center;
            color: var(--fonico-copy);
            font-size: 14px;
        }

        .panel-footer a {
            color: var(--fonico-mint-deep);
            font-weight: 700;
        }

        .page-footer {
            padding-top: 18px;
            text-align: center;
            color: #6f8791;
            font-size: 13px;
        }

        .page-footer a {
            color: inherit;
            font-weight: 700;
        }

        .parsley-errors-list {
            list-style: none;
            padding-left: 0;
            margin: 8px 0 0;
        }

        .parsley-required {
            color: #d64b5c;
            font-size: 13px;
            font-weight: 600;
        }

        @media (max-width: 1199.98px) {
            .login-brand,
            .login-panel {
                padding: 40px 34px;
            }

            .brand-metrics {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 991.98px) {
            .login-frame {
                grid-template-columns: 1fr;
            }

            .login-brand {
                min-height: auto;
                gap: 28px;
            }

            .brand-content {
                margin: 12px 0;
            }
        }

        @media (max-width: 575.98px) {
            .login-shell {
                padding: 14px;
            }

            .login-frame {
                border-radius: 24px;
            }

            .login-brand,
            .login-panel {
                padding: 28px 22px;
            }

            .brand-badge {
                width: 100%;
            }

            .login-panel h2 {
                font-size: 1.65rem;
            }

            .remember-row {
                align-items: flex-start;
                flex-direction: column;
            }

            .page-footer {
                font-size: 12px;
                line-height: 1.6;
            }
        }

        @media (max-width: 767.98px) {
            .login-brand {
                display: none;
            }

            .login-frame {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <main class="login-shell">
        <div class="w-100">
            <section class="login-frame">
                <aside class="login-brand">
                    <div class="brand-top">
                        <div class="brand-badge">
                            <img src="{{ asset('assets/images/new_logo/fonico_mobiles.jpg') }}" alt="Fonico Mobile">
                            <div>
                                <!-- <span class="brand-badge__title">FONICO MOBILE</span> -->
                                <span class="brand-badge__text">Buy. Sell. Exchange.</span>
                            </div>
                        </div>
                    </div>

                    <div class="brand-content">
                        <h1>Run your old-phone business from one focused workspace.</h1>
                        <p>
                            Sign in to access stock management, sales activity, invoicing, reports, and daily closing tools built around the way Fonico operates.
                        </p>
                    </div>

                    <div class="brand-metrics">
                        <div class="brand-metric">
                            <div class="brand-metric__label">Operations</div>
                            <div class="brand-metric__value">Stocks, sales, and expenses in one connected flow</div>
                        </div>
                        <div class="brand-metric">
                            <div class="brand-metric__label">Control</div>
                            <div class="brand-metric__value">Role-based access for teams handling daily store work</div>
                        </div>
                        <div class="brand-metric">
                            <div class="brand-metric__label">Reports</div>
                            <div class="brand-metric__value">Daily closing and performance visibility without extra steps</div>
                        </div>
                    </div>
                </aside>

                <section class="login-panel">
                    <div class="login-panel__inner">
                        <div class="panel-kicker">Secure Access</div>
                        <h2>Welcome back</h2>
                        <p class="login-panel__lead">
                            Use your account credentials to continue to the Fonico dashboard.
                        </p>

                        @include('include.alert')

                        <form method="POST" action="{{ route('login') }}">
                            @csrf

                            <div class="form-group">
                                <label class="form-label" for="email">Email address</label>
                                <div class="field-shell">
                                    <input
                                        class="form-control"
                                        type="email"
                                        id="email"
                                        name="email"
                                        value="{{ old('email') }}"
                                        placeholder="you@fonico.com"
                                        required
                                        autofocus
                                        autocomplete="username">
                                </div>
                                @error('email')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message }}</li>
                                    </ul>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="form-label" for="password">Password</label>
                                <div class="field-shell">
                                    <input
                                        type="password"
                                        id="password"
                                        name="password"
                                        required
                                        autocomplete="current-password"
                                        class="form-control"
                                        placeholder="Enter your password">
                                    <button type="button" class="password-toggle" id="passwordToggle" aria-label="Show password">
                                        <i class="fe-eye"></i>
                                    </button>
                                </div>
                                @error('password')
                                    <ul class="parsley-errors-list filled" aria-hidden="false">
                                        <li class="parsley-required">{{ $message }}</li>
                                    </ul>
                                @enderror
                            </div>

                            <div class="remember-row">
                                <div class="custom-control custom-checkbox">
                                    <input
                                        type="checkbox"
                                        name="remember"
                                        class="custom-control-input"
                                        id="remember_me"
                                        {{ old('remember', true) ? 'checked' : '' }}>
                                    <label class="custom-control-label" for="remember_me">{{ __('Keep me signed in') }}</label>
                                </div>
                            </div>

                            <div class="form-group mb-0">
                                <button class="btn btn-block signin-btn" type="submit">{{ __('Log in') }}</button>
                            </div>
                        </form>

                        <div class="panel-footer">
                            Don't have an account?
                            <a href="{{ route('register') }}">{{ __('Create one') }}</a>
                        </div>
                    </div>
                </section>
            </section>

            <div class="page-footer">
                <script>document.write(new Date().getFullYear())</script> &copy;
                <a href="https://www.ascentwebservices.com" target="_blank" rel="noopener noreferrer">Ascent Web Services</a>.
                Built for FONICO Mobile.
            </div>
        </div>
    </main>

    <script src="{{ asset('assets/js/vendor.min.js') }}"></script>
    <script src="{{ asset('assets/js/app.min.js') }}"></script>
    <script>
        const passwordInput = document.getElementById('password');
        const passwordToggle = document.getElementById('passwordToggle');

        if (passwordInput && passwordToggle) {
            passwordToggle.addEventListener('click', function () {
                const nextType = passwordInput.type === 'password' ? 'text' : 'password';
                passwordInput.type = nextType;
                this.setAttribute('aria-label', nextType === 'password' ? 'Show password' : 'Hide password');
                this.innerHTML = nextType === 'password' ? '<i class="fe-eye"></i>' : '<i class="fe-eye-off"></i>';
            });
        }
    </script>
</body>
</html>
