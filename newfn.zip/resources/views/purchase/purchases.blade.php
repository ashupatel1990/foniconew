@extends('layout.app')

@section('title', 'List Purchases')

@section('css')
    <style>
        .purchase-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.10), transparent 26%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .purchase-hero {
            position: relative;
            overflow: hidden;
            border-radius: 26px;
            padding: 28px 30px;
            margin-bottom: 24px;
            background: linear-gradient(135deg, #163447 0%, #204e65 58%, #1abc9c 100%);
            box-shadow: 0 24px 50px rgba(22, 52, 71, 0.18);
            color: #fff;
        }

        .purchase-hero::after {
            content: "";
            position: absolute;
            right: -72px;
            bottom: -96px;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .purchase-hero__eyebrow {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 14px;
        }

        .purchase-hero__title {
            color: #fff;
            font-size: 31px;
            line-height: 1.15;
            margin-bottom: 8px;
        }

        .purchase-hero__subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            max-width: 560px;
            margin-bottom: 0;
        }

        .purchase-hero__summary {
            border-radius: 20px;
            padding: 18px 20px;
            min-width: 270px;
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(6px);
        }

        .purchase-hero__summary-label {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: rgba(255, 255, 255, 0.72);
            margin-bottom: 8px;
        }

        .purchase-hero__summary-value {
            font-size: 34px;
            line-height: 1.05;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .purchase-hero__summary-meta {
            margin-bottom: 0;
            color: rgba(255, 255, 255, 0.8);
        }

        .purchase-section {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .purchase-section .card-body {
            padding: 26px;
        }

        .purchase-section__top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 22px;
        }

        .purchase-section__eyebrow {
            color: #1abc9c;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 8px;
        }

        .purchase-section__title {
            color: #18324b;
            font-size: 24px;
            margin-bottom: 6px;
        }

        .purchase-section__subtitle {
            color: #7b8798;
            margin-bottom: 0;
        }

        .purchase-actions {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-end;
            gap: 10px;
        }

        .purchase-btn {
            border-radius: 12px;
            padding: 10px 16px;
            font-weight: 600;
            box-shadow: none !important;
        }

        .purchase-btn.btn-primary {
            background: linear-gradient(135deg, #1abc9c 0%, #128a73 100%);
            border-color: transparent;
        }

        .purchase-btn.btn-outline-primary {
            color: #18324b;
            border-color: #c8d5e3;
            background: #fff;
        }

        .purchase-filter {
            background: #f7fafc;
            border: 1px solid #e4ebf3;
            border-radius: 18px;
            padding: 18px;
            margin-bottom: 22px;
        }

        .purchase-filter .form-control,
        .purchase-filter .btn {
            min-height: 46px;
            border-radius: 12px;
            box-shadow: none;
        }

        .purchase-filter .form-control {
            border-color: #d7e1ec;
        }

        .purchase-filter__label {
            display: block;
            color: #637289;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .purchase-filter__row {
            align-items: end;
        }

        .purchase-search .input-group-text {
            border-radius: 12px 0 0 12px;
            border-color: #d7e1ec;
            background: #fff;
            color: #8a98aa;
        }

        .purchase-search .form-control {
            border-left: 0;
        }

        .purchase-search .btn {
            border-radius: 0 12px 12px 0;
        }

        .purchase-table {
            margin-bottom: 0;
        }

        .purchase-table thead th {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #6f7f92;
            background: #f7fafc;
            border-top: 0;
            border-bottom: 1px solid #e6edf5;
            padding: 10px 12px;
            white-space: nowrap;
            line-height: 1.2;
        }

        .purchase-table tbody td {
            padding: 11px 12px;
            border-top: 1px solid #eef3f8;
            vertical-align: middle !important;
            line-height: 1.25;
        }

        .purchase-index {
            font-weight: 700;
            color: #4f46e5;
        }

        .purchase-model a {
            font-weight: 700;
            color: #18324b;
        }

        .purchase-meta {
            color: #7e8b9c;
            font-size: 12px;
            margin-top: 5px;
        }

        .purchase-imei {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: #17324d;
            font-weight: 600;
            cursor: pointer;
            font-size: 13px;
        }

        .purchase-imei i {
            color: #1abc9c;
        }

        .purchase-chip {
            display: inline-flex;
            align-items: center;
            padding: 4px 10px;
            border-radius: 999px;
            background: #f7fafc;
            border: 1px solid #dde7f0;
            color: #607086;
            font-weight: 600;
            font-size: 12px;
            line-height: 1.2;
        }

        .purchase-amount {
            font-size: 15px;
            font-weight: 700;
            color: #17324d;
            white-space: nowrap;
            display: block;
            text-align: right;
        }

        .purchase-date {
            color: #5f7188;
            font-weight: 600;
            white-space: nowrap;
        }

        .purchase-status {
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.02em;
            line-height: 1.2;
        }

        .purchase-status--available {
            background: rgba(26, 188, 156, 0.12);
            color: #169c82;
        }

        .purchase-status--sold {
            background: rgba(239, 68, 68, 0.12);
            color: #d63c49;
        }

        .purchase-actions-col {
            white-space: nowrap;
            text-align: right;
        }

        .purchase-action-icons {
            display: inline-flex;
            align-items: center;
            justify-content: flex-end;
            gap: 6px;
        }

        .purchase-action-icon {
            width: 32px;
            height: 32px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            border: 1px solid #dce5ef;
            background: #fff;
            color: #5f7188;
            transition: all 0.18s ease;
        }

        .purchase-action-icon:hover {
            transform: translateY(-1px);
            box-shadow: 0 10px 20px rgba(15, 23, 42, 0.08);
            text-decoration: none;
        }

        .purchase-action-icon i {
            font-size: 16px;
        }

        .purchase-action-icon--edit {
            color: #3b82f6;
            border-color: rgba(59, 130, 246, 0.2);
            background: rgba(59, 130, 246, 0.08);
        }

        .purchase-action-icon--view {
            color: #1abc9c;
            border-color: rgba(26, 188, 156, 0.2);
            background: rgba(26, 188, 156, 0.08);
        }

        .purchase-action-icon--delete {
            color: #d63c49;
            border-color: rgba(214, 60, 73, 0.18);
            background: rgba(214, 60, 73, 0.08);
        }

        .purchase-empty {
            text-align: center;
            padding: 56px 20px;
        }

        .purchase-empty__icon {
            width: 78px;
            height: 78px;
            margin: 0 auto 18px;
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(26, 188, 156, 0.12);
            color: #169c82;
            font-size: 30px;
        }

        .purchase-empty h4 {
            color: #17324d;
            margin-bottom: 8px;
        }

        .purchase-empty p {
            color: #8190a5;
            margin-bottom: 18px;
        }

        .purchase-detail-modal .modal-dialog {
            max-width: 1080px;
        }

        .purchase-detail-modal .modal-content {
            border: 0;
            border-radius: 22px;
            overflow: hidden;
            box-shadow: 0 24px 60px rgba(15, 23, 42, 0.2);
        }

        .purchase-detail-modal .modal-header {
            border-bottom: 1px solid #e8eef5;
            padding: 18px 22px;
        }

        .purchase-detail-modal .modal-title {
            color: #18324b;
            font-weight: 700;
        }

        .purchase-detail-modal .modal-body {
            padding: 18px;
            background: #f7fafc;
        }

        .purchase-detail-modal__content {
            min-height: 240px;
        }

        .purchase-detail-view {
            padding: 4px;
        }

        .purchase-detail-view .container-fluid {
            padding-left: 0;
            padding-right: 0;
        }

        .purchase-detail-hero {
            position: relative;
            overflow: hidden;
            border-radius: 22px;
            padding: 22px 24px;
            margin-bottom: 18px;
            background: linear-gradient(135deg, #17324d 0%, #1f4b63 58%, #1abc9c 100%);
            color: #fff;
            box-shadow: 0 18px 40px rgba(22, 52, 71, 0.18);
        }

        .purchase-detail-hero::after {
            content: "";
            position: absolute;
            right: -70px;
            bottom: -80px;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .purchase-detail-hero__eyebrow {
            display: inline-block;
            padding: 6px 11px;
            border-radius: 999px;
            margin-bottom: 12px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.85);
            font-size: 11px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
        }

        .purchase-detail-hero__title {
            color: #fff;
            font-size: 28px;
            margin-bottom: 10px;
            line-height: 1.15;
        }

        .purchase-detail-hero__meta {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .purchase-detail-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: #fff;
            font-size: 12px;
            font-weight: 600;
        }

        .purchase-detail-status {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 999px;
            padding: 7px 12px;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 0.02em;
        }

        .purchase-detail-status--available {
            background: rgba(26, 188, 156, 0.16);
            color: #dffbf5;
        }

        .purchase-detail-status--sold {
            background: rgba(239, 68, 68, 0.18);
            color: #ffe3e6;
        }

        .purchase-detail-card {
            border: 0;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 14px 34px rgba(15, 23, 42, 0.08);
            height: 100%;
        }

        .purchase-detail-card .card-body {
            padding: 20px;
        }

        .purchase-detail-card__title {
            color: #18324b;
            font-size: 15px;
            font-weight: 700;
            margin-bottom: 16px;
        }

        .purchase-detail-table {
            margin-bottom: 0;
        }

        .purchase-detail-table th,
        .purchase-detail-table td {
            border-top: 1px solid #edf2f7;
            padding: 13px 14px;
            vertical-align: middle !important;
        }

        .purchase-detail-table tr:first-child th,
        .purchase-detail-table tr:first-child td {
            border-top: 0;
        }

        .purchase-detail-table th {
            width: 42%;
            background: #f7fafc;
            color: #607086;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }

        .purchase-detail-table td {
            color: #17324d;
            font-weight: 600;
            background: #fff;
        }

        .purchase-detail-value {
            font-size: 18px;
            font-weight: 700;
            color: #17324d;
        }

        .purchase-detail-docs {
            margin-top: 18px;
        }

        .purchase-detail-doc {
            display: block;
            border-radius: 16px;
            overflow: hidden;
            border: 1px solid #e6edf5;
            background: #fff;
            box-shadow: 0 10px 24px rgba(15, 23, 42, 0.06);
        }

        .purchase-detail-doc__media {
            height: 150px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f7fafc;
        }

        .purchase-detail-doc__media img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }

        .purchase-detail-doc__label {
            padding: 10px 12px;
            color: #607086;
            font-size: 12px;
            font-weight: 600;
            text-align: center;
            background: #fff;
        }

        .purchase-detail-modal__state {
            min-height: 240px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6b7a90;
            font-weight: 600;
        }

        .purchase-detail-modal__state i {
            font-size: 22px;
            margin-right: 10px;
        }

        .pagination-links {
            margin-top: 24px;
        }

        @media (max-width: 991.98px) {
            .purchase-section__top {
                flex-direction: column;
            }

            .purchase-actions {
                justify-content: flex-start;
                width: 100%;
            }

            .purchase-hero {
                padding: 24px 22px;
            }

            .purchase-hero__summary {
                margin-top: 18px;
            }
        }

        @media (max-width: 767.98px) {
            .purchase-shell {
                padding-top: 18px;
            }

            .purchase-hero__eyebrow,
            .purchase-hero__title,
            .purchase-hero__subtitle {
                display: none;
            }

            .purchase-table {
                min-width: 1100px;
            }

            .purchase-section .card-body {
                padding: 20px;
            }

            .purchase-detail-hero__title {
                font-size: 24px;
            }
        }
    </style>
@endsection

@section('content')
    <div class="container-fluid purchase-shell">
        <div class="purchase-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <div class="purchase-hero__eyebrow">Inventory Management</div>
                    <h1 class="purchase-hero__title">List Purchases</h1>
                    <p class="purchase-hero__subtitle">
                        Track every stocked device, filter inventory quickly, and manage product lifecycle from one clean view.
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="purchase-hero__summary float-lg-right">
                        <div class="purchase-hero__summary-label">Available Stock Value</div>
                        <div class="purchase-hero__summary-value">
                            {{ config('constant.currency') }} {{ number_format($totalAvailableStockAmount, 2) }}
                        </div>
                        <p class="purchase-hero__summary-meta">Current unsold inventory value in stock</p>
                    </div>
                </div>
            </div>
        </div>

        @include('include.alert')

        <div class="card purchase-section">
            <div class="card-body">
                <div class="purchase-section__top">
                    <div>
                        <div class="purchase-section__eyebrow">Stock Registry</div>
                        <h2 class="purchase-section__title">Manage Purchase [{{ $totalItems }}]</h2>
                        <p class="purchase-section__subtitle">
                            Search by IMEI or model, refine the list by year, storage, color, and stock status.
                        </p>
                    </div>

                    <div class="purchase-actions">
                        <div class="btn-group">
                            <button type="button" class="btn btn-outline-primary purchase-btn dropdown-toggle"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="mdi mdi-plus-circle-outline mr-1"></i>Add Stock
                            </button>
                            <div class="dropdown-menu dropdown-menu-right mt-2">
                                <a class="dropdown-item" href="{{ route('purchase.create') }}">
                                    <i class="mdi mdi-plus-circle-outline mr-1"></i>Single Stock
                                </a>
                                <a class="dropdown-item" href="{{ route('purchase.create.multiple') }}">
                                    <i class="mdi mdi-plus-box-multiple-outline mr-1"></i>Multiple Stock
                                </a>
                            </div>
                        </div>

                        <div class="btn-group">
                            <button type="button" class="btn btn-primary purchase-btn dropdown-toggle"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="mdi mdi-file-download-outline mr-1"></i>Export Stock
                            </button>
                            <div class="dropdown-menu dropdown-menu-right mt-2">
                                <a class="dropdown-item" href="{{ request()->fullUrlWithQuery(['download' => 'csv']) }}">
                                    <i class="mdi mdi-file-delimited-outline mr-1"></i>Download CSV
                                </a>
                                <a class="dropdown-item" href="{{ request()->fullUrlWithQuery(['download' => 'pdf']) }}">
                                    <i class="mdi mdi-file-pdf-box mr-1"></i>Download PDF
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                @if (count($allPurchases))
                    <div class="purchase-filter">
                        <form action="{{ route('allpurchases') }}" method="GET" id="filterpurchase">
                            <div class="form-row purchase-filter__row">
                                <div class="col-12 col-lg-4 mb-3 mb-lg-0">
                                    <label class="purchase-filter__label" for="searchstock">Search Inventory</label>
                                    <div class="input-group purchase-search">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="mdi mdi-magnify"></i></span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Search by model or IMEI"
                                            name="search" value="{{ request()->input('search') }}" id="searchstock">
                                        <div class="input-group-append">
                                            <button class="btn btn-dark" type="submit">Search</button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-6 col-md-3 col-lg-1 mb-3 mb-lg-0">
                                    <label class="purchase-filter__label" for="selectyear">Year</label>
                                    <select name="year" class="form-control" id="selectyear">
                                        <option value="">Year</option>
                                        @for ($filterYear = now()->year; $filterYear >= 2024; $filterYear--)
                                            <option value="{{ $filterYear }}" @selected((int) $year === $filterYear)>
                                                {{ $filterYear }}
                                            </option>
                                        @endfor
                                    </select>
                                </div>

                                <div class="col-6 col-md-3 col-lg-2 mb-3 mb-lg-0">
                                    <label class="purchase-filter__label" for="selectstorage">Storage</label>
                                    <select name="storage" class="form-control" id="selectstorage">
                                        <option value="">Select Storage</option>
                                        <option value="64" @selected($storage == 64)>64 GB</option>
                                        <option value="128" @selected($storage == 128)>128 GB</option>
                                        <option value="256" @selected($storage == 256)>256 GB</option>
                                        <option value="512" @selected($storage == 512)>512 GB</option>
                                        <option value="1024" @selected($storage == 1024)>1 TB</option>
                                        <option value="2048" @selected($storage == 2048)>2 TB</option>
                                    </select>
                                </div>

                                <div class="col-6 col-md-3 col-lg-2 mb-3 mb-lg-0">
                                    <label class="purchase-filter__label" for="selectcolor">Color</label>
                                    <select name="color" class="form-control" id="selectcolor">
                                        <option value="">Select Color</option>
                                        @foreach ($colors as $color)
                                            <option value="{{ $color->color }}"
                                                @selected(strtolower($color->color) == strtolower($selectedcolor))>
                                                {{ $color->color }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="col-6 col-md-3 col-lg-2 mb-3 mb-lg-0">
                                    <label class="purchase-filter__label" for="findbysold">Status</label>
                                    <select name="is_sold" class="form-control" id="findbysold">
                                        <option value="">Select Status</option>
                                        <option value="2" @selected($issold == 2)>Available</option>
                                        <option value="1" @selected($issold == 1)>Sold</option>
                                    </select>
                                </div>

                                <div class="col-12 col-md-3 col-lg-1">
                                    <label class="purchase-filter__label d-none d-md-block">&nbsp;</label>
                                    <button class="btn btn-outline-danger btn-block purchase-btn" type="button"
                                        onclick="clearFilters()">Clear</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive">
                        <table class="table purchase-table">
                            <thead>
                                <tr>
                                    <th>
                                        <a href="{{ route('allpurchases', ['direction' => $sortDirection == 'asc' ? 'desc' : 'asc']) }}"
                                            class="text-decoration-none">
                                            Sr. No
                                            @if ($sortDirection == 'asc')
                                                <i class="fa fa-arrow-up ml-1"></i>
                                            @else
                                                <i class="fa fa-arrow-down ml-1"></i>
                                            @endif
                                        </a>
                                    </th>
                                    <th>Model</th>
                                    <th>IMEI</th>
                                    <th>Storage</th>
                                    <th>Color</th>
                                    <th class="text-right">Buying Cost</th>
                                    <th>Buy Date</th>
                                    <th>Sale Date</th>
                                    <th>Status</th>
                                    <th class="text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($allPurchases as $purchase)
                                    <tr>
                                        <td>
                                            <a href="{{ route('purchase-detail', $purchase->id) }}" class="purchase-index">
                                                #{{ $purchase->id }}
                                            </a>
                                        </td>
                                        <td class="purchase-model">
                                            <a href="{{ route('purchase-detail', $purchase->id) }}">
                                                {{ ucfirst($purchase->model) }}
                                            </a>
                                            <!-- <div class="purchase-meta">Stock entry details</div> -->
                                        </td>
                                        <td>
                                            <span class="purchase-imei" onclick="copyToClipboard('{{ $purchase->imei }}')"
                                                title="Click to copy IMEI">
                                                <i class="mdi mdi-content-copy"></i>{{ $purchase->imei }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="purchase-chip">{{ $purchase->storage }} GB</span>
                                        </td>
                                        <td>
                                            <span class="purchase-chip">{{ ucfirst($purchase->color) }}</span>
                                        </td>
                                        <td class="text-right">
                                            <span class="purchase-amount">
                                                {{ config('constant.currency') . number_format($purchase->purchase_price, 2) }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="purchase-date">
                                                {{ \Carbon\Carbon::parse($purchase->purchase_date)->format('d/m/Y') }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="purchase-date">
                                                @if($purchase->sell_date && $purchase->is_sold)
                                                    {{ \Carbon\Carbon::parse($purchase->sell_date)->format('d/m/Y') }}
                                                @else
                                                    --
                                                @endif
                                            </span>
                                        </td>
                                        <td>
                                            @if($purchase->is_sold == 1)
                                                <span class="purchase-status purchase-status--sold">Sold</span>
                                            @else
                                                <span class="purchase-status purchase-status--available">Available</span>
                                            @endif
                                        </td>
                                        <td class="purchase-actions-col">
                                            <div class="purchase-action-icons">
                                                @if($purchase->is_sold == 0)
                                                    <a href="{{ route('purchase.edit', $purchase->id) }}"
                                                        class="purchase-action-icon purchase-action-icon--edit"
                                                        title="Edit">
                                                        <i class="mdi mdi-square-edit-outline"></i>
                                                    </a>
                                                @endif

                                                <a href="{{ route('purchase-detail', $purchase->id) }}"
                                                    class="purchase-action-icon purchase-action-icon--view js-purchase-detail"
                                                    data-title="Stock Detail #{{ $purchase->id }}"
                                                    title="View">
                                                    <i class="mdi mdi-eye-outline"></i>
                                                </a>

                                                <form method="post" action="{{ route('delete-stock', $purchase->id) }}" class="d-inline-block mb-0">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit"
                                                        class="purchase-action-icon purchase-action-icon--delete"
                                                        onclick="sureToDelete(event)"
                                                        title="Delete">
                                                        <i class="mdi mdi-trash-can-outline"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="pagination-links">
                        {{ $allPurchases->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
                    </div>
                @else
                    <div class="purchase-empty">
                        <div class="purchase-empty__icon">
                            <i class="mdi mdi-cellphone-plus"></i>
                        </div>
                        <h4>No stock found</h4>
                        <p>Start by adding your first stock item or return to the full inventory view.</p>
                        <a href="{{ route('allpurchases') }}" class="btn btn-primary purchase-btn">
                            <i class="mdi mdi-refresh mr-1"></i>Reload Inventory
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <div class="modal fade purchase-detail-modal" id="purchaseDetailModal" tabindex="-1" role="dialog"
        aria-labelledby="purchaseDetailModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="purchaseDetailModalLabel">Purchase Detail</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="purchaseDetailModalContent" class="purchase-detail-modal__content">
                        <div class="purchase-detail-modal__state">
                            <i class="mdi mdi-package-variant-closed"></i>Choose a purchase to view its details.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        function sureToDelete(e) {
            if (confirm('Are You sure you want to delete this?')) {
                return true;
            } else {
                e.preventDefault();
            }
        }

        function copyToClipboard(text) {
            navigator.clipboard.writeText(text);
            toastr.success('Copied to clipboard');
        }

        function clearFilters() {
            window.location.href = "{{ route('allpurchases') }}";
        }

        $(document).on('click', '.js-purchase-detail', function(e) {
            e.preventDefault();

            const url = $(this).attr('href');
            const title = $(this).data('title') || 'Purchase Detail';

            $('#purchaseDetailModalLabel').text(title);
            $('#purchaseDetailModal').modal('show');
            $('#purchaseDetailModalContent').html(
                '<div class="purchase-detail-modal__state"><i class="mdi mdi-loading mdi-spin"></i>Loading purchase details...</div>'
            );

            $.ajax({
                url: url,
                method: 'GET',
                data: {
                    modal: 1
                },
                success: function(response) {
                    $('#purchaseDetailModalContent').html(response);
                },
                error: function() {
                    $('#purchaseDetailModalContent').html(
                        '<div class="purchase-detail-modal__state"><i class="mdi mdi-alert-circle-outline"></i>Unable to load purchase details right now.</div>'
                    );
                }
            });
        });

        $('#purchaseDetailModal').on('hidden.bs.modal', function() {
            $('#purchaseDetailModalContent').html(
                '<div class="purchase-detail-modal__state"><i class="mdi mdi-package-variant-closed"></i>Choose a purchase to view its details.</div>'
            );
        });
    </script>
@endsection
