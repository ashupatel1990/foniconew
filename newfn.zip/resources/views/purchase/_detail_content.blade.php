@php
    $isModal = request()->ajax() || request()->boolean('modal');
    $documentRows = $purchase->document ? array_filter(explode(',', $purchase->document)) : [];
@endphp

<div class="purchase-detail-view">
    <div class="container-fluid">
        <div class="purchase-detail-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="purchase-detail-hero__eyebrow">Stock Overview</div> -->
                    <h3 class="purchase-detail-hero__title mb-0">{{ $purchase->model }}</h3>
                </div>
                <div class="col-lg-4 text-lg-right mt-3 mt-lg-0">
                    @unless($isModal)
                        <a href="javascript:history.back()" class="btn btn-light btn-sm mb-3">
                            <i class="mdi mdi-keyboard-backspace mr-1"></i>Back
                        </a>
                    @endunless
                    <div class="purchase-detail-hero__meta {{ $isModal ? '' : 'justify-content-lg-end' }}">
                        <span class="purchase-detail-pill">
                            <i class="mdi mdi-pound-box-outline"></i>ID #{{ $purchase->id }}
                        </span>
                        <span class="purchase-detail-status {{ $purchase->is_sold == 1 ? 'purchase-detail-status--sold' : 'purchase-detail-status--available' }}">
                            {{ $purchase->is_sold == 1 ? 'Sold' : 'Available' }}
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-6 col-lg-6 mb-3">
                <div class="card purchase-detail-card">
                    <div class="card-body">
                        <h4 class="purchase-detail-card__title">Device Information</h4>
                        <div class="table-responsive">
                            <table class="table purchase-detail-table">
                                <tbody>
                                    @if($purchase->device_type)
                                        <tr>
                                            <th>Device Type</th>
                                            <td>
                                                @if($purchase->device_type == 'Phone')
                                                    <i class="ti-mobile mr-1"></i>
                                                @endif
                                                @if($purchase->device_type == 'Tablet')
                                                    <i class="ti-tablet mr-1"></i>
                                                @endif
                                                @if($purchase->device_type == 'Laptop')
                                                    <i class="mdi mdi-laptop-mac mr-1"></i>
                                                @endif
                                                @if($purchase->device_type == 'Accessories')
                                                    <i class="mdi mdi-ipod mr-1"></i>
                                                @endif
                                                {{ $purchase->device_type }}
                                            </td>
                                        </tr>
                                    @endif
                                    @if($purchase->imei)
                                        <tr>
                                            <th>IMEI</th>
                                            <td>{{ $purchase->imei }}</td>
                                        </tr>
                                    @endif
                                    @if($purchase->storage)
                                        <tr>
                                            <th>Storage</th>
                                            <td>{{ $purchase->storage }} GB</td>
                                        </tr>
                                    @endif
                                    @if($purchase->color)
                                        <tr>
                                            <th>Color</th>
                                            <td>{{ ucfirst($purchase->color) }}</td>
                                        </tr>
                                    @endif
                                    @if($purchase->purchase_from)
                                        <tr>
                                            <th>Purchase From</th>
                                            <td>{{ ucfirst($purchase->purchase_from) }}</td>
                                        </tr>
                                    @endif
                                    @if($purchase->contactno)
                                        <tr>
                                            <th>Mobile No</th>
                                            <td>{{ $purchase->contactno }}</td>
                                        </tr>
                                    @endif
                                    @if($purchase->condition)
                                        <tr>
                                            <th>Condition</th>
                                            <td>{{ $purchase->condition }}</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-6 col-lg-6 mb-3">
                <div class="card purchase-detail-card">
                    <div class="card-body">
                        <h4 class="purchase-detail-card__title">Pricing & Purchase Info</h4>
                        <div class="table-responsive">
                            <table class="table purchase-detail-table">
                                <tbody>
                                    <tr>
                                        <th>Purchase Cost</th>
                                        <td><span class="purchase-detail-value">{{ '₹' . number_format($purchase->purchase_cost) }}</span></td>
                                    </tr>
                                    <tr>
                                        <th>Repairing Charge</th>
                                        <td><span class="purchase-detail-value">{{ '₹' . number_format($purchase->repairing_charge) }}</span></td>
                                    </tr>
                                    <tr>
                                        <th>Total Cost</th>
                                        <td><span class="purchase-detail-value">{{ '₹' . number_format($purchase->purchase_price) }}</span></td>
                                    </tr>
                                    @if($purchase->remark)
                                        <tr>
                                            <th>Remark</th>
                                            <td>{{ $purchase->remark }}</td>
                                        </tr>
                                    @endif
                                    <tr>
                                        <th>Purchase Date</th>
                                        <td>{{ \Carbon\Carbon::parse($purchase->purchase_date)->format('d-m-Y') }}</td>
                                    </tr>
                                    <tr>
                                        <th>Purchased By</th>
                                        <td>{{ $purchase->user && $purchase->user->name ? ucfirst($purchase->user->name) : 'Guest' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Brand Warrenty</th>
                                        <td>
                                            @if($purchase->warrentydate)
                                                {{ \Carbon\Carbon::parse($purchase->warrentydate)->format('d-m-Y') }}
                                            @else
                                                Non Warrenty
                                            @endif
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @if (!empty($documentRows))
            <div class="card purchase-detail-card purchase-detail-docs">
                <div class="card-body">
                    <h4 class="purchase-detail-card__title">Documents</h4>
                    <div class="row">
                        @foreach($documentRows as $row)
                            <div class="col-sm-6 col-lg-3 mb-3">
                                <a href="{{ asset('documents/purchases/' . $row) }}" class="purchase-detail-doc" title="{{ $purchase->model }}" target="_blank">
                                    <div class="purchase-detail-doc__media">
                                        @if (pathinfo($row, PATHINFO_EXTENSION) == 'pdf')
                                            <img src="{{ asset('assets/images/pdf-file.svg') }}" alt="{{ $row }}">
                                        @else
                                            <img src="{{ asset('documents/purchases/' . $row) }}" alt="{{ $row }}">
                                        @endif
                                    </div>
                                    <div class="purchase-detail-doc__label">{{ \Illuminate\Support\Str::limit($row, 24) }}</div>
                                </a>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        @endif
    </div>
</div>
