@extends('layout.app')

@section('title')
    Stock Detail: #{{ $purchase->id }}
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <h4 class="page-title">Stock Detail ID : #{{ $purchase->id }}</h4>
                </div>
            </div>
        </div>

        @include('purchase._detail_content', ['purchase' => $purchase])
    </div>
@endsection
