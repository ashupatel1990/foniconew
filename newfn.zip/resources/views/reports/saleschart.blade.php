@extends('layout.app')

@section('title')
    Sales Charts Report
@endsection

@section('content')
    <style>
        .sales-chart-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.10), transparent 26%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .sales-chart-hero {
            position: relative;
            overflow: hidden;
            border-radius: 26px;
            padding: 28px 30px;
            margin-bottom: 24px;
            background: linear-gradient(135deg, #163447 0%, #204e65 58%, #1abc9c 100%);
            box-shadow: 0 24px 50px rgba(22, 52, 71, 0.18);
            color: #fff;
        }

        .sales-chart-hero::after {
            content: "";
            position: absolute;
            right: -72px;
            bottom: -96px;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
            pointer-events: none;
            z-index: 0;
        }

        .sales-chart-hero .row {
            position: relative;
            z-index: 1;
        }

        .sales-chart-hero__eyebrow {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 14px;
        }

        .sales-chart-hero__title {
            color: #fff;
            font-size: 31px;
            line-height: 1.15;
            margin-bottom: 8px;
        }

        .sales-chart-hero__subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            max-width: 560px;
            margin-bottom: 0;
        }

        .sales-chart-summary {
            border: 0;
            border-radius: 20px;
            box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
            height: 100%;
        }

        .sales-chart-summary .card-body {
            padding: 22px;
        }

        .sales-chart-summary__label {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #7b8798;
            margin-bottom: 10px;
        }

        .sales-chart-summary__value {
            font-size: 28px;
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 0;
            color: #17324d;
        }

        .sales-chart-card {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
            height: 100%;
        }

        .sales-chart-card .card-body {
            padding: 24px;
        }

        .sales-chart-card__eyebrow {
            color: #1abc9c;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 8px;
        }

        .sales-chart-card__title {
            color: #18324b;
            font-size: 22px;
            margin-bottom: 6px;
        }

        .sales-chart-card__subtitle {
            color: #7b8798;
            margin-bottom: 18px;
        }

        .sales-chart-canvas {
            height: 340px !important;
        }

        .sales-chart-empty {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 260px;
            color: #7b8798;
            font-weight: 600;
        }

        @media (max-width: 767.98px) {
            .sales-chart-shell {
                padding-top: 18px;
            }

            .sales-chart-hero {
                padding: 24px 22px;
            }

            .sales-chart-hero__title {
                font-size: 26px;
            }

            .sales-chart-card .card-body {
                padding: 20px;
            }
        }
    </style>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <div class="container-fluid sales-chart-shell">
        <div class="sales-chart-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <div class="sales-chart-hero__eyebrow">Analytics</div>
                    <h1 class="sales-chart-hero__title">Sales Analytics for {{ $timePeriod }}</h1>
                    <p class="sales-chart-hero__subtitle">
                        Track daily revenue, profit movement, and payment mode patterns for the current month in one place.
                    </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card sales-chart-summary">
                    <div class="card-body">
                        <div class="sales-chart-summary__label">Invoices This Month</div>
                        <div class="sales-chart-summary__value">{{ $invoiceCount }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card sales-chart-summary">
                    <div class="card-body">
                        <div class="sales-chart-summary__label">Total Sales</div>
                        <div class="sales-chart-summary__value">₹{{ number_format($totalSalesAmount, 2) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card sales-chart-summary">
                    <div class="card-body">
                        <div class="sales-chart-summary__label">Total Profit</div>
                        <div class="sales-chart-summary__value">₹{{ number_format($totalProfitAmount, 2) }}</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-7 mb-4">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <div class="sales-chart-card__eyebrow">Revenue</div>
                        <h2 class="sales-chart-card__title">Daily Sales Overview</h2>
                        <p class="sales-chart-card__subtitle">Revenue trend across invoice dates for {{ $timePeriod }}.</p>
                        <canvas id="dailySalesChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 mb-4">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <div class="sales-chart-card__eyebrow">Payments</div>
                        <h2 class="sales-chart-card__title">Payment Mode Breakdown</h2>
                        <p class="sales-chart-card__subtitle">Invoice count split by payment method.</p>
                        <canvas id="paymentModeChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <div class="sales-chart-card__eyebrow">Invoices</div>
                        <h2 class="sales-chart-card__title">Daily Invoice Count</h2>
                        <p class="sales-chart-card__subtitle">How many invoices were created on each date.</p>
                        <canvas id="invoiceCountChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mb-4">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <div class="sales-chart-card__eyebrow">Customers</div>
                        <h2 class="sales-chart-card__title">Top Customers by Revenue</h2>
                        <p class="sales-chart-card__subtitle">Highest-value customers for {{ $timePeriod }}.</p>
                        <canvas id="topCustomersChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card sales-chart-card">
                    <div class="card-body">
                        <div class="sales-chart-card__eyebrow">Profit</div>
                        <h2 class="sales-chart-card__title">Daily Profit Analysis</h2>
                        <p class="sales-chart-card__subtitle">Profit generated from invoice items, grouped by invoice date.</p>
                        <canvas id="profitAnalysisChart" class="sales-chart-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const dailySalesLabels = @json($dailySalesLabels);
        const dailySalesValues = @json($dailySalesValues);
        const dailyProfitLabels = @json($dailyProfitLabels);
        const dailyProfitValues = @json($dailyProfitValues);
        const paymentModeLabels = @json($paymentModeLabels);
        const paymentModeValues = @json($paymentModeValues);
        const dailyInvoiceCountLabels = @json($dailyInvoiceCountLabels);
        const dailyInvoiceCountValues = @json($dailyInvoiceCountValues);
        const topCustomerLabels = @json($topCustomerLabels);
        const topCustomerValues = @json($topCustomerValues);

        const axisLabelColor = '#607086';
        const gridColor = 'rgba(148, 163, 184, 0.18)';
        const currencyTooltip = (value) => '₹' + Number(value).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        new Chart(document.getElementById('dailySalesChart'), {
            type: 'bar',
            data: {
                labels: dailySalesLabels,
                datasets: [{
                    label: 'Revenue',
                    data: dailySalesValues,
                    backgroundColor: '#1abc9c',
                    borderRadius: 8,
                    maxBarThickness: 36
                }]
            },
            options: {
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return ' Revenue: ' + currencyTooltip(context.parsed.y);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: axisLabelColor },
                        grid: { display: false }
                    },
                    y: {
                        ticks: { color: axisLabelColor },
                        grid: { color: gridColor }
                    }
                }
            }
        });

        new Chart(document.getElementById('paymentModeChart'), {
            type: 'doughnut',
            data: {
                labels: paymentModeLabels,
                datasets: [{
                    data: paymentModeValues,
                    backgroundColor: ['#17324d', '#1abc9c', '#4f46e5', '#f59e0b', '#ef4444']
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: axisLabelColor,
                            boxWidth: 14,
                            padding: 16
                        }
                    }
                }
            }
        });

        new Chart(document.getElementById('invoiceCountChart'), {
            type: 'bar',
            data: {
                labels: dailyInvoiceCountLabels,
                datasets: [{
                    label: 'Invoices',
                    data: dailyInvoiceCountValues,
                    backgroundColor: '#4f46e5',
                    borderRadius: 8,
                    maxBarThickness: 34
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        ticks: { color: axisLabelColor },
                        grid: { display: false }
                    },
                    y: {
                        ticks: { color: axisLabelColor, precision: 0 },
                        grid: { color: gridColor }
                    }
                }
            }
        });

        new Chart(document.getElementById('topCustomersChart'), {
            type: 'bar',
            data: {
                labels: topCustomerLabels,
                datasets: [{
                    label: 'Revenue',
                    data: topCustomerValues,
                    backgroundColor: '#f59e0b',
                    borderRadius: 8,
                    maxBarThickness: 32
                }]
            },
            options: {
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return ' Revenue: ' + currencyTooltip(context.parsed.x);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: axisLabelColor,
                            callback: function(value) {
                                return '₹' + Number(value).toLocaleString('en-IN');
                            }
                        },
                        grid: { color: gridColor }
                    },
                    y: {
                        ticks: { color: axisLabelColor },
                        grid: { display: false }
                    }
                }
            }
        });

        new Chart(document.getElementById('profitAnalysisChart'), {
            type: 'line',
            data: {
                labels: dailyProfitLabels,
                datasets: [{
                    label: 'Profit',
                    data: dailyProfitValues,
                    borderColor: '#17324d',
                    backgroundColor: 'rgba(23, 50, 77, 0.08)',
                    fill: true,
                    tension: 0.35,
                    pointBackgroundColor: '#1abc9c',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 7,
                    pointHitRadius: 18,
                    pointHoverBorderWidth: 3
                }]
            },
            options: {
                maintainAspectRatio: false,
                interaction: {
                    mode: 'nearest',
                    intersect: false
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        enabled: true,
                        callbacks: {
                            label: function(context) {
                                return ' Profit: ' + currencyTooltip(context.parsed.y);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: axisLabelColor },
                        grid: { color: 'transparent' }
                    },
                    y: {
                        ticks: { color: axisLabelColor },
                        grid: { color: gridColor }
                    }
                }
            }
        });
    </script>
@endsection
