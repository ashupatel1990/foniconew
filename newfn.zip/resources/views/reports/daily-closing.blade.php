@extends('layout.app')

@section('title')
    Daily Closing Summary
@endsection

@section('content')
    <style>
        .daily-closing-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.10), transparent 26%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .daily-closing-hero {
            position: relative;
            overflow: hidden;
            border-radius: 26px;
            padding: 28px 30px;
            margin-bottom: 24px;
            background: linear-gradient(135deg, #163447 0%, #204e65 58%, #1abc9c 100%);
            box-shadow: 0 24px 50px rgba(22, 52, 71, 0.18);
            color: #fff;
        }

        .daily-closing-hero::after {
            content: "";
            position: absolute;
            right: -72px;
            bottom: -96px;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
            pointer-events: none;
            z-index: 0;
        }

        .daily-closing-hero .row {
            position: relative;
            z-index: 1;
        }

        .daily-closing-hero__eyebrow {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 14px;
        }

        .daily-closing-hero__title {
            color: #fff;
            font-size: 31px;
            line-height: 1.15;
            margin-bottom: 8px;
        }

        .daily-closing-hero__subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            max-width: 620px;
            margin-bottom: 0;
        }

        .daily-closing-toolbar {
            display: flex;
            justify-content: flex-end;
            align-items: flex-end;
            gap: 12px;
            flex-wrap: wrap;
        }

        .daily-closing-filter {
            min-width: 220px;
        }

        .daily-closing-filter label {
            display: block;
            color: rgba(255, 255, 255, 0.72);
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .daily-closing-filter .form-control,
        .daily-closing-toolbar .btn {
            min-height: 46px;
            border-radius: 12px;
            box-shadow: none !important;
        }

        .daily-closing-toolbar .btn-light {
            color: #17324d;
            font-weight: 700;
        }

        .daily-closing-toolbar .btn-outline-light {
            border-color: rgba(255, 255, 255, 0.38);
            color: #fff;
            font-weight: 700;
        }

        .daily-closing-summary {
            border: 0;
            border-radius: 20px;
            box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
            height: 100%;
        }

        .daily-closing-summary .card-body {
            padding: 22px;
        }

        .daily-closing-summary__label {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #7b8798;
            margin-bottom: 10px;
        }

        .daily-closing-summary__value {
            font-size: 24px;
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 0;
            color: #17324d;
        }

        .daily-closing-summary__meta {
            color: #7b8798;
            font-size: 13px;
            margin-top: 12px;
            margin-bottom: 0;
        }

        .daily-closing-summary--good .daily-closing-summary__value {
            color: #169c82;
        }

        .daily-closing-summary--warn .daily-closing-summary__value {
            color: #b97700;
        }

        .daily-closing-summary--danger .daily-closing-summary__value {
            color: #dc2626;
        }

        .daily-closing-card {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
            height: 100%;
        }

        .daily-closing-card .card-body {
            padding: 24px;
        }

        .daily-closing-card__eyebrow {
            color: #1abc9c;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 8px;
        }

        .daily-closing-card__title {
            color: #18324b;
            font-size: 22px;
            margin-bottom: 6px;
        }

        .daily-closing-card__subtitle {
            color: #7b8798;
            margin-bottom: 18px;
        }

        .daily-closing-stat {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 0;
            border-bottom: 1px solid #edf2f7;
            gap: 16px;
        }

        .daily-closing-stat:last-child {
            border-bottom: 0;
            padding-bottom: 0;
        }

        .daily-closing-stat:first-child {
            padding-top: 0;
        }

        .daily-closing-stat__label {
            color: #637289;
            font-weight: 600;
        }

        .daily-closing-stat__value {
            color: #18324b;
            font-size: 18px;
            font-weight: 700;
            text-align: right;
        }

        .daily-closing-stat__value.is-positive {
            color: #169c82;
        }

        .daily-closing-stat__value.is-negative {
            color: #dc2626;
        }

        .daily-closing-table {
            margin-bottom: 0;
        }

        .daily-closing-table thead th {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #ebf6ff;
            background: #17324d;
            border-top: 0;
            border-bottom: 0;
            padding: 14px 16px;
            white-space: nowrap;
        }

        .daily-closing-table tbody td {
            padding: 16px;
            vertical-align: top;
            border-color: #edf2f7;
            color: #425466;
        }

        .daily-closing-table tbody tr:hover {
            background: #f9fbfd;
        }

        .daily-closing-amount {
            text-align: right;
            font-size: 16px;
            font-weight: 700;
            color: #18324b;
            white-space: nowrap;
        }

        .daily-closing-payment {
            display: inline-flex;
            padding: 7px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
            background: #eef6ff;
            color: #1d4ed8;
        }

        .daily-closing-empty {
            border: 1px dashed #d7e1ec;
            border-radius: 18px;
            padding: 24px;
            text-align: center;
            color: #7b8798;
            background: #f8fbfd;
        }

        @media print {
            .daily-closing-no-print {
                display: none !important;
            }

            .daily-closing-shell {
                background: #fff;
                padding: 0;
            }

            .daily-closing-hero,
            .daily-closing-summary,
            .daily-closing-card {
                box-shadow: none !important;
            }
        }

        @media (max-width: 767.98px) {
            .daily-closing-shell {
                padding-top: 18px;
            }

            .daily-closing-hero {
                padding: 24px 22px;
            }

            .daily-closing-hero__title {
                font-size: 26px;
            }

            .daily-closing-toolbar {
                justify-content: stretch;
            }

            .daily-closing-filter {
                width: 100%;
            }
        }
    </style>

    <div class="container-fluid daily-closing-shell">
        <div class="daily-closing-hero">
            <div class="row align-items-center">
                <div class="col-lg-7 mb-3 mb-lg-0">
                    <div class="daily-closing-hero__eyebrow">Reports</div>
                    <h1 class="daily-closing-hero__title">Daily Closing Summary</h1>
                    <p class="daily-closing-hero__subtitle">
                        Review opening balance, payment-wise sales, expenses, and net profit for a single day in one clear closing view.
                    </p>
                </div>
                <div class="col-lg-5">
                    <form method="GET" action="{{ route('daily-closing') }}" class="daily-closing-toolbar daily-closing-no-print">
                        <div class="daily-closing-filter">
                            <label for="closingDate">Closing Date</label>
                            <input type="date" name="date" id="closingDate" class="form-control" value="{{ $selectedDate }}">
                        </div>
                        <button type="submit" class="btn btn-light">Apply</button>
                        <a href="{{ route('daily-closing', ['date' => now()->toDateString()]) }}" class="btn btn-outline-light">Today</a>
                        <button type="button" class="btn btn-outline-light" onclick="window.print()">Print</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card daily-closing-summary">
                    <div class="card-body">
                        <div class="daily-closing-summary__label">Opening Balance</div>
                        <div class="daily-closing-summary__value">₹{{ number_format($openingBalance, 2) }}</div>
                        <p class="daily-closing-summary__meta">Cash ₹{{ number_format($openingCash, 2) }} | Bank ₹{{ number_format($openingBank, 2) }}</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card daily-closing-summary">
                    <div class="card-body">
                        <div class="daily-closing-summary__label">Total Sales</div>
                        <div class="daily-closing-summary__value">₹{{ number_format($totalSales, 2) }}</div>
                        <p class="daily-closing-summary__meta">{{ $invoiceCount }} invoice(s) | {{ $itemsSold }} item(s) sold</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card daily-closing-summary daily-closing-summary--good">
                    <div class="card-body">
                        <div class="daily-closing-summary__label">Net Profit</div>
                        <div class="daily-closing-summary__value">₹{{ number_format($netProfit, 2) }}</div>
                        <p class="daily-closing-summary__meta">Gross ₹{{ number_format($grossProfit, 2) }} | Expense ₹{{ number_format($totalExpense, 2) }}</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card daily-closing-summary daily-closing-summary--warn">
                    <div class="card-body">
                        <div class="daily-closing-summary__label">Closing Balance</div>
                        <div class="daily-closing-summary__value">₹{{ number_format($closingBalance, 2) }}</div>
                        <p class="daily-closing-summary__meta">Cash ₹{{ number_format($closingCash, 2) }} | Bank ₹{{ number_format($closingBank, 2) }}</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-5 mb-4">
                <div class="card daily-closing-card">
                    <div class="card-body">
                        <div class="daily-closing-card__eyebrow">Cash Flow</div>
                        <h2 class="daily-closing-card__title">Closing Breakdown</h2>
                        <p class="daily-closing-card__subtitle">A quick view of how today moved cash, bank balance, and profit.</p>

                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Cash Sales</div>
                            <div class="daily-closing-stat__value">₹{{ number_format($cashSales, 2) }}</div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Online / UPI Sales</div>
                            <div class="daily-closing-stat__value">₹{{ number_format($onlineSales, 2) }}</div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Card Sales</div>
                            <div class="daily-closing-stat__value">₹{{ number_format($cardSales, 2) }}</div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Expenses</div>
                            <div class="daily-closing-stat__value is-negative">₹{{ number_format($totalExpense, 2) }}</div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Gross Profit</div>
                            <div class="daily-closing-stat__value is-positive">₹{{ number_format($grossProfit, 2) }}</div>
                        </div>
                        <div class="daily-closing-stat">
                            <div class="daily-closing-stat__label">Net Profit</div>
                            <div class="daily-closing-stat__value {{ $netProfit >= 0 ? 'is-positive' : 'is-negative' }}">₹{{ number_format($netProfit, 2) }}</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7 mb-4">
                <div class="card daily-closing-card">
                    <div class="card-body">
                        <div class="daily-closing-card__eyebrow">Register</div>
                        <h2 class="daily-closing-card__title">Daily Position</h2>
                        <p class="daily-closing-card__subtitle">Use this as a simple end-of-day reconciliation snapshot.</p>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Opening Cash</div>
                                    <div class="daily-closing-stat__value">₹{{ number_format($openingCash, 2) }}</div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Cash Inflow</div>
                                    <div class="daily-closing-stat__value">₹{{ number_format($cashSales, 2) }}</div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Cash Outflow</div>
                                    <div class="daily-closing-stat__value is-negative">₹{{ number_format($totalExpense, 2) }}</div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Closing Cash</div>
                                    <div class="daily-closing-stat__value">₹{{ number_format($closingCash, 2) }}</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Opening Bank</div>
                                    <div class="daily-closing-stat__value">₹{{ number_format($openingBank, 2) }}</div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Bank / UPI Inflow</div>
                                    <div class="daily-closing-stat__value">₹{{ number_format($onlineSales + $cardSales, 2) }}</div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Closing Bank</div>
                                    <div class="daily-closing-stat__value">₹{{ number_format($closingBank, 2) }}</div>
                                </div>
                                <div class="daily-closing-stat">
                                    <div class="daily-closing-stat__label">Total Closing</div>
                                    <div class="daily-closing-stat__value">₹{{ number_format($closingBalance, 2) }}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8 mb-4">
                <div class="card daily-closing-card">
                    <div class="card-body">
                        <div class="daily-closing-card__eyebrow">Sales</div>
                        <h2 class="daily-closing-card__title">Invoices on {{ \Carbon\Carbon::parse($selectedDate)->format('d M Y') }}</h2>
                        <p class="daily-closing-card__subtitle">Review today’s invoice activity and payment mix.</p>

                        @if($invoices->isEmpty())
                            <div class="daily-closing-empty">No invoices found for this date.</div>
                        @else
                            <div class="table-responsive">
                                <table class="table daily-closing-table">
                                    <thead>
                                        <tr>
                                            <th>Invoice</th>
                                            <th>Customer</th>
                                            <th>Payment</th>
                                            <th class="text-right">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($invoices as $invoice)
                                            <tr>
                                                <td>
                                                    <strong>#{{ $invoice->invoice_no }}</strong><br>
                                                    <small class="text-muted">{{ \Carbon\Carbon::parse($invoice->invoice_date)->format('d-m-Y') }}</small>
                                                </td>
                                                <td>
                                                    <strong>{{ $invoice->customer_name ?: 'Walk-in Customer' }}</strong><br>
                                                    <small class="text-muted">{{ $invoice->customer_no ?: '-' }}</small>
                                                </td>
                                                <td>
                                                    <span class="daily-closing-payment">{{ $invoice->payment_type ?: 'Unknown' }}</span>
                                                </td>
                                                <td class="daily-closing-amount">₹{{ number_format((float) $invoice->net_amount, 2) }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mb-4">
                <div class="card daily-closing-card">
                    <div class="card-body">
                        <div class="daily-closing-card__eyebrow">Expenses</div>
                        <h2 class="daily-closing-card__title">Expense Register</h2>
                        <p class="daily-closing-card__subtitle">Expenses are deducted from cash while calculating today’s closing.</p>

                        @if($expenses->isEmpty())
                            <div class="daily-closing-empty">No expenses recorded for this date.</div>
                        @else
                            @foreach($expenses as $expense)
                                <div class="daily-closing-stat">
                                    <div>
                                        <div class="daily-closing-stat__label text-dark">{{ $expense->expense_name ?: ($expense->title ?? 'Expense') }}</div>
                                        <small class="text-muted">{{ $expense->remark ?: ($expense->note ?? 'No note added') }}</small>
                                    </div>
                                    <div class="daily-closing-stat__value is-negative">₹{{ number_format((float) $expense->amount, 2) }}</div>
                                </div>
                            @endforeach
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
