<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Sales Report</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            color: #243447;
            font-size: 12px;
        }

        .header {
            border-bottom: 2px solid #17324d;
            padding-bottom: 12px;
            margin-bottom: 18px;
        }

        .title {
            font-size: 24px;
            font-weight: 700;
            color: #17324d;
            margin: 0 0 4px;
        }

        .subtitle {
            color: #607086;
            margin: 0;
        }

        .summary {
            width: 100%;
            margin-bottom: 18px;
        }

        .summary td {
            width: 25%;
            border: 1px solid #dbe6ef;
            padding: 10px;
            vertical-align: top;
        }

        .summary-label {
            font-size: 10px;
            text-transform: uppercase;
            color: #607086;
            margin-bottom: 6px;
        }

        .summary-value {
            font-size: 16px;
            font-weight: 700;
            color: #17324d;
        }

        table.report {
            width: 100%;
            border-collapse: collapse;
        }

        table.report th {
            background: #17324d;
            color: #fff;
            padding: 10px 8px;
            font-size: 11px;
            text-transform: uppercase;
        }

        table.report td {
            border: 1px solid #e3ebf3;
            padding: 10px 8px;
            vertical-align: top;
        }

        .text-right {
            text-align: right;
        }

        .muted {
            color: #607086;
            font-size: 11px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1 class="title">Sales Report</h1>
        <p class="subtitle">Period: {{ $timePeriod }} | Generated: {{ now()->format('d M Y H:i') }}</p>
    </div>

    <table class="summary">
        <tr>
            <td>
                <div class="summary-label">Total Sales</div>
                <div class="summary-value">₹{{ number_format($totalSalesAmount, 2) }}</div>
            </td>
            <td>
                <div class="summary-label">Total Profit</div>
                <div class="summary-value">₹{{ number_format($totalProfitAmount, 2) }}</div>
            </td>
            <td>
                <div class="summary-label">Total Expense</div>
                <div class="summary-value">₹{{ number_format($totalExpenseAmount, 2) }}</div>
            </td>
            <td>
                <div class="summary-label">Net Profit</div>
                <div class="summary-value">₹{{ number_format($totalProfitAmount - $totalExpenseAmount, 2) }}</div>
            </td>
        </tr>
    </table>

    <table class="report">
        <thead>
            <tr>
                <th>Date</th>
                <th>Invoice No.</th>
                <th>Customer</th>
                <th class="text-right">Billing Info</th>
                <th>Payment</th>
            </tr>
        </thead>
        <tbody>
            @foreach($allSales as $invoice)
                <tr>
                    <td>{{ \Carbon\Carbon::parse($invoice->invoice_date)->format('d/m/Y') }}</td>
                    <td>#{{ $invoice->invoice_no }}</td>
                    <td>
                        <strong>{{ $invoice->customer_name ?? '-' }}</strong><br>
                        <span class="muted">{{ $invoice->customer_no ?? 'N/A' }}</span>
                    </td>
                    <td class="text-right">
                        @if($invoice->total_amount) Total: ₹{{ number_format($invoice->total_amount, 2) }}<br>@endif
                        @if($invoice->tax_amount) Tax: ₹{{ number_format($invoice->tax_amount, 2) }}<br>@endif
                        @if($invoice->discount) Discount: ₹{{ number_format($invoice->discount, 2) }}<br>@endif
                        Net: ₹{{ number_format($invoice->net_amount, 2) }}
                    </td>
                    <td>{{ ucfirst($invoice->payment_type) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
