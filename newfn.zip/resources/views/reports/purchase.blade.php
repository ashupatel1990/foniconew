@extends('layout.app')

@section('title')
    Purchase Report
@endsection

@section('content')
    <style>
        .showdefault {
            display: block !important;
        }

        .purchase-report-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(23, 162, 184, 0.10), transparent 26%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .purchase-report-hero {
            position: relative;
            overflow: hidden;
            border-radius: 26px;
            padding: 28px 30px;
            margin-bottom: 24px;
            background: linear-gradient(135deg, #193549 0%, #285f75 55%, #1ca38a 100%);
            box-shadow: 0 24px 50px rgba(20, 46, 62, 0.18);
            color: #fff;
        }

        .purchase-report-hero::after {
            content: "";
            position: absolute;
            right: -72px;
            bottom: -92px;
            width: 230px;
            height: 230px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
        }

        .purchase-report-hero .row {
            position: relative;
            z-index: 1;
        }

        .purchase-report-hero__title {
            color: #fff;
            font-size: 31px;
            line-height: 1.15;
            margin-bottom: 8px;
        }

        .purchase-report-hero__subtitle {
            color: rgba(255, 255, 255, 0.82);
            font-size: 15px;
            max-width: 620px;
            margin-bottom: 0;
        }

        .purchase-report-actions {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            height: 100%;
        }

        .purchase-report-btn {
            border-radius: 12px;
            padding: 11px 18px;
            font-weight: 700;
            box-shadow: none !important;
        }

        .purchase-report-btn.btn-light {
            color: #17324d;
        }

        .purchase-report-btn.btn-outline-light {
            border-color: rgba(255, 255, 255, 0.4);
            color: #fff;
        }

        .purchase-report-btn.btn-outline-light:hover {
            color: #17324d;
            background: #fff;
        }

        .purchase-report-summary {
            border: 0;
            border-radius: 20px;
            box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
            height: 100%;
        }

        .purchase-report-summary .card-body {
            padding: 22px;
        }

        .purchase-report-summary__label {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #7b8798;
            margin-bottom: 10px;
        }

        .purchase-report-summary__value {
            font-size: 22px;
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 0;
        }

        .purchase-report-summary--cost .purchase-report-summary__value {
            color: #1d4ed8;
        }

        .purchase-report-summary--repair .purchase-report-summary__value {
            color: #b97700;
        }

        .purchase-report-summary--value .purchase-report-summary__value {
            color: #169c82;
        }

        .purchase-report-summary--sold .purchase-report-summary__value {
            color: #dc2626;
        }

        .purchase-report-card {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .purchase-report-card .card-body {
            padding: 26px;
        }

        .purchase-report-card__title {
            color: #18324b;
            font-size: 24px;
            margin-bottom: 6px;
        }

        .purchase-report-card__subtitle {
            color: #7b8798;
            margin-bottom: 18px;
        }

        .purchase-report-filter {
            background: #f7fafc;
            border: 1px solid #e4ebf3;
            border-radius: 18px;
            padding: 18px;
            margin-bottom: 22px;
        }

        .purchase-report-filter .form-control,
        .purchase-report-filter .btn {
            min-height: 46px;
            border-radius: 12px;
            box-shadow: none;
        }

        .purchase-report-filter .form-control {
            border-color: #d7e1ec;
        }

        .purchase-report-label {
            display: block;
            color: #637289;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .purchase-report-date-group {
            display: none;
        }

        .purchase-report-date-group.showdefault {
            display: block !important;
        }

        .purchase-report-filter-actions {
            display: flex;
            align-items: flex-end;
            gap: 10px;
            height: 100%;
        }

        .purchase-report-filter-actions .btn {
            min-width: 140px;
        }

        .purchase-report-table {
            margin-bottom: 0;
            min-width: 1180px;
        }

        .purchase-report-table thead th {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #ebf6ff;
            background: #17324d;
            border-top: 0;
            border-bottom: 0;
            padding: 14px 16px;
            white-space: nowrap;
        }

        .purchase-report-table tbody td {
            padding: 5px 16px;
            border-top: 1px solid #eef3f8;
            vertical-align: middle !important;
        }

        .purchase-report-date {
            color: #5f7188;
            font-weight: 700;
            white-space: nowrap;
        }

        .purchase-report-device__name {
            color: #18324b;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .purchase-report-device__meta,
        .purchase-report-source__meta,
        .purchase-report-note {
            color: #7e8b9c;
            font-size: 12px;
        }

        .purchase-report-source__name {
            color: #18324b;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .purchase-report-money__label {
            color: #7b8798;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 4px;
        }

        .purchase-report-money__value {
            color: #18324b;
            font-size: 15px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .purchase-report-money__value--main {
            color: #169c82;
            font-size: 18px;
        }

        .purchase-report-status {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 7px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .purchase-report-status--sold {
            background: rgba(220, 38, 38, 0.12);
            color: #c53030;
        }

        .purchase-report-status--available {
            background: rgba(22, 156, 130, 0.12);
            color: #11806a;
        }

        .purchase-report-empty {
            text-align: center;
            padding: 56px 20px;
        }

        .purchase-report-empty__icon {
            width: 78px;
            height: 78px;
            margin: 0 auto 18px;
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(28, 163, 138, 0.12);
            color: #169c82;
            font-size: 30px;
        }

        .purchase-report-empty h4 {
            color: #17324d;
            margin-bottom: 8px;
        }

        .purchase-report-empty p {
            color: #8190a5;
            margin-bottom: 0;
        }

        @media (max-width: 991.98px) {
            .purchase-report-actions {
                justify-content: flex-start;
                margin-top: 18px;
            }
        }

        @media (max-width: 767.98px) {
            .purchase-report-shell {
                padding-top: 18px;
            }

            .purchase-report-hero {
                padding: 24px 22px;
            }

            .purchase-report-hero__title {
                font-size: 26px;
            }

            .purchase-report-card .card-body {
                padding: 20px;
            }

            .purchase-report-filter-actions {
                flex-direction: column;
                align-items: stretch;
            }

            .purchase-report-filter-actions .btn {
                width: 100%;
            }
        }
    </style>

    <div class="container-fluid purchase-report-shell">
        <div class="purchase-report-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="purchase-report-hero__title">Purchase Items Report</h1>
                    <p class="purchase-report-hero__subtitle">
                        Review purchased inventory with date, supplier, device and cost details, then export the same filtered view as CSV or PDF.
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="purchase-report-actions">
                        <a href="{{ route('buy-export', request()->query()) }}" class="btn btn-light purchase-report-btn">
                            <i class="mdi mdi-file-delimited mr-1"></i>CSV
                        </a>
                        <a href="{{ route('purchase-report-pdf', request()->query()) }}" class="btn btn-outline-light purchase-report-btn">
                            <i class="mdi mdi-file-pdf-box mr-1"></i>PDF
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--cost">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Purchase Cost - {{ $timePeriod }}</div>
                        <div class="purchase-report-summary__value">{{ config('constant.currency') }}{{ number_format($totalPurchaseAmount, 2) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--repair">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Repairing - {{ $timePeriod }}</div>
                        <div class="purchase-report-summary__value">{{ config('constant.currency') }}{{ number_format($totalRepairingAmount, 2) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--value">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Stock Value - {{ $timePeriod }}</div>
                        <div class="purchase-report-summary__value">{{ config('constant.currency') }}{{ number_format($totalStockValue, 2) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card purchase-report-summary purchase-report-summary--sold">
                    <div class="card-body">
                        <div class="purchase-report-summary__label">Sold vs Available</div>
                        <div class="purchase-report-summary__value">{{ $soldItems }} / {{ $availableItems }}</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card purchase-report-card">
            <div class="card-body">
                <h2 class="purchase-report-card__title">Purchased Items [{{ $totalItems }}]</h2>
                <p class="purchase-report-card__subtitle">Apply filters to narrow the report, then export exactly what you see.</p>

                <div class="purchase-report-filter">
                    <form method="GET" id="purchase-report-form">
                        <div class="form-row align-items-end">
                            <div class="col-12 col-md-3 mb-3 mb-md-0">
                                <label class="purchase-report-label" for="purchase-period">Report Period</label>
                                <select name="period" class="form-control" id="purchase-period">
                                    <option value="alls" @selected($period == 'alls')>All Purchases</option>
                                    <option value="thismonth" @selected($period == 'thismonth')>This Month</option>
                                    <option value="lastmonth" @selected($period == 'lastmonth')>Last Month</option>
                                    <option value="thisyear" @selected($period == 'thisyear')>This Year</option>
                                    <option value="lastyear" @selected($period == 'lastyear')>Last Year</option>
                                    <option value="custom" @selected($period == 'custom')>Custom Range</option>
                                </select>
                            </div>
                            <div class="col-md-2 mb-3 mb-md-0 purchase-report-date-group @if($period == 'custom') showdefault @endif">
                                <label class="purchase-report-label" for="purchase-fromdate">From Date</label>
                                <input type="date" id="purchase-fromdate" name="fromdate" class="form-control" value="{{ $fromdate }}">
                            </div>
                            <div class="col-md-2 mb-3 mb-md-0 purchase-report-date-group @if($period == 'custom') showdefault @endif">
                                <label class="purchase-report-label" for="purchase-todate">To Date</label>
                                <input type="date" id="purchase-todate" name="todate" class="form-control" value="{{ $todate }}">
                            </div>
                            <div class="col-12 col-md-2 mb-3 mb-md-0">
                                <label class="purchase-report-label" for="purchase-status">Item Status</label>
                                <select name="status" class="form-control" id="purchase-status">
                                    <option value="" @selected($status === '')>All</option>
                                    <option value="available" @selected($status === 'available')>Available</option>
                                    <option value="sold" @selected($status === 'sold')>Sold</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-3 mb-3 mb-md-0">
                                <label class="purchase-report-label" for="purchase-search">Search</label>
                                <input type="text" id="purchase-search" name="search" class="form-control" value="{{ $search }}" placeholder="IMEI, model, supplier, phone">
                            </div>
                            <div class="col-12 col-md-2 mb-3 mb-md-0">
                                <label class="purchase-report-label d-none d-md-block">&nbsp;</label>
                                <div class="purchase-report-filter-actions">
                                    <button type="submit" class="btn btn-primary purchase-report-btn">
                                    Filter Report
                                    </button>
                                    <a href="{{ route('purchase-report') }}" class="btn btn-outline-danger purchase-report-btn">
                                    Clear
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    @if ($allPurchased->count())
                        <table class="table purchase-report-table">
                            <thead>
                                <tr>
                                    <th>Purchase Date</th>
                                    <th>Device</th>
                                    <th>Supplier</th>
                                    <th>Costing</th>
                                    <th>Status</th>
                                    <!-- <th>Notes</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($allPurchased as $purchase)
                                    <tr>
                                        <td>
                                            <span class="purchase-report-date">{{ \Carbon\Carbon::parse($purchase->purchase_date)->format('d/m/Y') }}</span>
                                            @if($purchase->sell_date)
                                                <div class="purchase-report-device__meta mt-2">Sold: {{ \Carbon\Carbon::parse($purchase->sell_date)->format('d/m/Y') }}</div>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="purchase-report-device__name">{{ $purchase->model ?: 'Unnamed Device' }}</div>
                                            <div class="purchase-report-device__meta">IMEI: {{ $purchase->imei ?: 'N/A' }}</div>
                                            <div class="purchase-report-device__meta">Storage: {{ $purchase->storage ?: 'N/A' }} | Color: {{ $purchase->color ?: 'N/A' }}</div>
                                        </td>
                                        <td>
                                            <div class="purchase-report-source__name">{{ $purchase->purchase_from ?: 'Unknown Supplier' }}</div>
                                            <div class="purchase-report-source__meta">Phone: {{ $purchase->contactno ?: 'N/A' }}</div>
                                        </td>
                                        <td>
                                            <div class="purchase-report-money__label">Buy Cost</div>
                                            <div class="purchase-report-money__value">{{ config('constant.currency') }}{{ number_format((float) $purchase->purchase_cost, 2) }}</div>
                                            <!-- <div class="purchase-report-money__label">Repairing</div> -->
                                            <!-- <div class="purchase-report-money__value">{{ config('constant.currency') }}{{ number_format((float) ($purchase->repairing_charge ?: 0), 2) }}</div> -->
                                            <!-- <div class="purchase-report-money__label">Stock Value</div>
                                            <div class="purchase-report-money__value purchase-report-money__value--main">{{ config('constant.currency') }}{{ number_format((float) $purchase->purchase_price, 2) }}</div> -->
                                        </td>
                                        <td>
                                            <span class="purchase-report-status purchase-report-status--{{ $purchase->is_sold ? 'sold' : 'available' }}">
                                                {{ $purchase->is_sold ? 'Sold' : 'Available' }}
                                            </span>
                                        </td>
                                        <!-- <td>
                                            <div class="purchase-report-note">{{ $purchase->remark ?: 'No notes recorded' }}</div>
                                        </td> -->
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="mt-3">
                            {{ $allPurchased->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
                        </div>
                    @else
                        <div class="purchase-report-empty">
                            <div class="purchase-report-empty__icon">
                                <i class="mdi mdi-package-variant-closed"></i>
                            </div>
                            <h4>No purchases found</h4>
                            <p>Try another date range, status, or search term to view purchase activity.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('purchase-period');
            const dateGroups = document.querySelectorAll('.purchase-report-date-group');

            function toggleCustomDateFields() {
                const showDates = periodSelect && periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleCustomDateFields);
                toggleCustomDateFields();
            }
        })();
    </script>
@endsection
