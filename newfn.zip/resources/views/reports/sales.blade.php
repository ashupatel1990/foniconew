@extends('layout.app')

@section('title')
    Sales Report
@endsection

@section('content')
    <style>
        .showdefault {
            display: block !important;
        }

        .sales-report-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.10), transparent 26%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .sales-report-hero {
            position: relative;
            overflow: hidden;
            border-radius: 26px;
            padding: 28px 30px;
            margin-bottom: 24px;
            background: linear-gradient(135deg, #163447 0%, #204e65 58%, #1abc9c 100%);
            box-shadow: 0 24px 50px rgba(22, 52, 71, 0.18);
            color: #fff;
        }

        .sales-report-hero::after {
            content: "";
            position: absolute;
            right: -72px;
            bottom: -96px;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
            pointer-events: none;
            z-index: 0;
        }

        .sales-report-hero .row {
            position: relative;
            z-index: 1;
        }

        .sales-report-hero__eyebrow {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 14px;
        }

        .sales-report-hero__title {
            color: #fff;
            font-size: 31px;
            line-height: 1.15;
            margin-bottom: 8px;
        }

        .sales-report-hero__subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            max-width: 560px;
            margin-bottom: 0;
        }

        .sales-report-actions {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            height: 100%;
        }

        .sales-report-btn {
            border-radius: 12px;
            padding: 11px 18px;
            font-weight: 700;
            box-shadow: none !important;
        }

        .sales-report-btn.btn-light {
            color: #17324d;
        }

        .sales-report-btn.btn-outline-light {
            border-color: rgba(255, 255, 255, 0.45);
            color: #fff;
        }

        .sales-report-btn.btn-outline-light:hover {
            color: #000;
        }

        .sales-report-summary {
            border: 0;
            border-radius: 20px;
            box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
            height: 85%;
        }

        .sales-report-summary .card-body {
            padding: 22px;
        }

        .sales-report-summary__label {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #7b8798;
            margin-bottom: 10px;
        }

        .sales-report-summary__value {
            font-size: 22px;
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 0;
        }

        .sales-report-summary--sales .sales-report-summary__value {
            color: #1d4ed8;
        }

        .sales-report-summary--profit .sales-report-summary__value {
            color: #169c82;
        }

        .sales-report-summary--expense .sales-report-summary__value {
            color: #dc2626;
        }

        .sales-report-summary--net .sales-report-summary__value {
            color: #b97700;
        }

        .sales-report-card {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .sales-report-card .card-body {
            padding: 26px;
        }

        .sales-report-card__title {
            color: #18324b;
            font-size: 24px;
            margin-bottom: 6px;
        }

        .sales-report-card__subtitle {
            color: #7b8798;
            margin-bottom: 18px;
        }

        .sales-report-filter {
            background: #f7fafc;
            border: 1px solid #e4ebf3;
            border-radius: 18px;
            padding: 18px;
            margin-bottom: 22px;
        }

        .sales-report-filter .form-control,
        .sales-report-filter .btn {
            min-height: 46px;
            border-radius: 12px;
            box-shadow: none;
        }

        .sales-report-filter .form-control {
            border-color: #d7e1ec;
        }

        .sales-report-label {
            display: block;
            color: #637289;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .sales-report-date-group {
            display: none;
        }

        .sales-report-date-group.showdefault {
            display: block !important;
        }

        .sales-report-table {
            margin-bottom: 0;
        }

        .sales-report-table thead th {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #ebf6ff;
            background: #17324d;
            border-top: 0;
            border-bottom: 0;
            padding: 14px 16px;
            white-space: nowrap;
        }

        .sales-report-table tbody td {
            padding: 18px 16px;
            border-top: 1px solid #eef3f8;
            vertical-align: top !important;
        }

        .sales-report-date {
            color: #5f7188;
            font-weight: 700;
            white-space: nowrap;
        }

        .sales-report-invoice {
            color: #18324b;
            font-weight: 700;
        }

        .sales-report-party__name {
            color: #18324b;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .sales-report-party__meta {
            color: #7e8b9c;
            font-size: 12px;
        }

        .sales-report-billing {
            text-align: right;
        }

        .sales-report-billing__item + .sales-report-billing__item {
            margin-top: 8px;
        }

        .sales-report-billing__item {
            display: flex;
            align-items: baseline;
            justify-content: space-between;
            gap: 12px;
        }

        .sales-report-billing__label {
            color: #7b8798;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            margin-bottom: 0;
            text-align: left;
        }

        .sales-report-billing__value {
            color: #18324b;
            font-size: 15px;
            font-weight: 700;
            white-space: nowrap;
            text-align: right;
        }

        .sales-report-billing__value--net {
            font-size: 18px;
        }

        .sales-report-payment {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(23, 50, 77, 0.08);
            color: #17324d;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .sales-report-empty {
            text-align: center;
            padding: 56px 20px;
        }

        .sales-report-empty__icon {
            width: 78px;
            height: 78px;
            margin: 0 auto 18px;
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(26, 188, 156, 0.12);
            color: #169c82;
            font-size: 30px;
        }

        .sales-report-empty h4 {
            color: #17324d;
            margin-bottom: 8px;
        }

        .sales-report-empty p {
            color: #8190a5;
            margin-bottom: 0;
        }

        @media (max-width: 991.98px) {
            .sales-report-actions {
                justify-content: flex-start;
                margin-top: 18px;
            }
        }

        @media (max-width: 767.98px) {
            .sales-report-shell {
                padding-top: 18px;
            }

            .sales-report-hero {
                padding: 24px 22px;
            }

            .sales-report-hero__title {
                font-size: 26px;
            }

            .sales-report-card .card-body {
                padding: 20px;
            }

            .sales-report-table {
                min-width: 980px;
            }
        }
    </style>

    <div class="container-fluid sales-report-shell">
        <div class="sales-report-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <!-- <div class="sales-report-hero__eyebrow">Reports</div> -->
                    <h1 class="sales-report-hero__title">Sales Report</h1>
                    <p class="sales-report-hero__subtitle">
                    </p>
                </div>
                <div class="col-lg-4">
                    <div class="sales-report-actions">
                        <a href="{{ route('sale-export', request()->query()) }}" class="btn btn-light sales-report-btn">
                            <i class="mdi mdi-microsoft-excel mr-1"></i>Spreadsheet
                        </a>
                        <a href="{{ route('sale-export-pdf', request()->query()) }}" class="btn btn-outline-light sales-report-btn">
                            <i class="mdi mdi-file-pdf-box mr-1"></i>PDF
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card sales-report-summary sales-report-summary--sales">
                    <div class="card-body">
                        <div class="sales-report-summary__label">Total Sales - {{ $timePeriod }}</div>
                        <div class="sales-report-summary__value">₹{{ number_format($totalSalesAmount, 2) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card sales-report-summary sales-report-summary--profit">
                    <div class="card-body">
                        <div class="sales-report-summary__label">Total Profit - {{ $timePeriod }}</div>
                        <div class="sales-report-summary__value">₹{{ number_format($totalProfitAmount, 2) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card sales-report-summary sales-report-summary--expense">
                    <div class="card-body">
                        <div class="sales-report-summary__label">Total Expense - {{ $timePeriod }}</div>
                        <div class="sales-report-summary__value">₹{{ number_format($totalExpenseAmount, 2) }}</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-3 mb-3">
                <div class="card sales-report-summary sales-report-summary--net">
                    <div class="card-body">
                        <div class="sales-report-summary__label">Net Profit - {{ $timePeriod }}</div>
                        <div class="sales-report-summary__value">₹{{ number_format($totalProfitAmount - $totalExpenseAmount, 2) }}</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card sales-report-card">
            <div class="card-body">
                <h2 class="sales-report-card__title">Transactions Report [{{ $totalItems }}]</h2>
                <p class="sales-report-card__subtitle"></p>

                <div class="sales-report-filter">
                    <form method="GET" id="salesreport">
                        <div class="form-row align-items-end">
                            <div class="col-12 col-md-4 mb-3 mb-md-0">
                                <label class="sales-report-label" for="selectsalesperiod">Report Period</label>
                                <select name="period" class="form-control" id="selectsalesperiod">
                                    <option value="alls" @selected($period == 'alls')>All Sales</option>
                                    <option value="thismonth" @selected($period == 'thismonth')>This Month</option>
                                    <option value="lastmonth" @selected($period == 'lastmonth')>Last Month</option>
                                    <option value="thisyear" @selected($period == 'thisyear')>This Year</option>
                                    <option value="lastyear" @selected($period == 'lastyear')>Last Year</option>
                                    <option value="custom" @selected($period == 'custom')>Custom Range</option>
                                </select>
                            </div>

                            <div class="col-md-2 mb-3 mb-md-0 sales-report-date-group @if($period == 'custom') showdefault @endif">
                                <label class="sales-report-label" for="salefromdate">From Date</label>
                                <input type="date" id="salefromdate" name="fromdate" class="form-control"
                                    value="{{ $fromdate }}">
                            </div>
                            <div class="col-md-2 mb-3 mb-md-0 sales-report-date-group @if($period == 'custom') showdefault @endif">
                                <label class="sales-report-label" for="saletodate">To Date</label>
                                <input type="date" id="saletodate" name="todate" class="form-control"
                                    value="{{ $todate }}">
                            </div>

                            <div class="col-12 col-md-4 d-flex">
                                <button type="submit" formaction="{{ route('sale-report') }}" class="btn btn-primary sales-report-btn flex-fill mr-2">
                                    Filter
                                </button>
                                <a href="{{ route('sale-report') }}" class="btn btn-outline-danger sales-report-btn flex-fill">
                                    Clear
                                </a>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive">
                    @if (count($allSales))
                        <table class="table sales-report-table" id="invoice-tables">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Invoice No.</th>
                                    <th>Party Name</th>
                                    <th class="text-right">Billing Info</th>
                                    <th>Payment Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($allSales as $invoice)
                                    <tr>
                                        <td>
                                            <span class="sales-report-date">{{ date('d/m/Y', strtotime($invoice->invoice_date)) }}</span>
                                        </td>
                                        <td>
                                            <a href="{{ route('invoice-detail', $invoice->id) }}" class="sales-report-invoice">
                                                #{{ $invoice->invoice_no }}
                                            </a>
                                        </td>
                                        <td>
                                            <div class="sales-report-party__name">{{ ucwords($invoice->customer_name) }}</div>
                                            <div class="sales-report-party__meta">
                                                @if($invoice->customer_no)
                                                    Contact: {{ ucfirst($invoice->customer_no) }}
                                                @else
                                                    Contact: N/A
                                                @endif
                                            </div>
                                        </td>
                                        <td class="sales-report-billing">
                                            @if($invoice->total_amount)
                                                <div class="sales-report-billing__item">
                                                    <span class="sales-report-billing__label">Total Amount</span>
                                                    <span class="sales-report-billing__value">₹{{ number_format($invoice->total_amount, 2) }}</span>
                                                </div>
                                            @endif
                                            @if($invoice->tax_amount)
                                                <div class="sales-report-billing__item">
                                                    <span class="sales-report-billing__label">Tax</span>
                                                    <span class="sales-report-billing__value">₹{{ number_format($invoice->tax_amount, 2) }}</span>
                                                </div>
                                            @endif
                                            @if($invoice->discount)
                                                <div class="sales-report-billing__item">
                                                    <span class="sales-report-billing__label">Discount</span>
                                                    <span class="sales-report-billing__value">₹{{ number_format($invoice->discount, 2) }}</span>
                                                </div>
                                            @endif
                                            @if($invoice->net_amount)
                                                <div class="sales-report-billing__item">
                                                    <span class="sales-report-billing__label">Net Amount</span>
                                                    <span class="sales-report-billing__value sales-report-billing__value--net">₹{{ number_format($invoice->net_amount, 2) }}</span>
                                                </div>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="sales-report-payment">{{ ucfirst($invoice->payment_type) }}</span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div class="mt-3">
                            {{ $allSales->appends(request()->query())->links('vendor.pagination.bootstrap-5') }}
                        </div>
                    @else
                        <div class="sales-report-empty">
                            <div class="sales-report-empty__icon">
                                <i class="mdi mdi-chart-bar-stacked"></i>
                            </div>
                            <h4>No transactions to show</h4>
                            <p>Try another period or date range to view sales activity.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('selectsalesperiod');
            const dateGroups = document.querySelectorAll('.sales-report-date-group');

            function toggleCustomDateFields() {
                const showDates = periodSelect && periodSelect.value === 'custom';

                dateGroups.forEach(function (group) {
                    group.style.display = showDates ? 'block' : 'none';
                });
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleCustomDateFields);
                toggleCustomDateFields();
            }
        })();
    </script>
@endsection
