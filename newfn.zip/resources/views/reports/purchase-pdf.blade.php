<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Purchase Report</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            color: #243447;
            font-size: 11px;
        }

        .header {
            border-bottom: 2px solid #17324d;
            padding-bottom: 12px;
            margin-bottom: 18px;
        }

        .title {
            font-size: 24px;
            font-weight: 700;
            color: #17324d;
            margin: 0 0 4px;
        }

        .subtitle {
            color: #607086;
            margin: 0;
        }

        .summary {
            width: 100%;
            margin-bottom: 18px;
            border-collapse: separate;
            border-spacing: 8px 0;
        }

        .summary td {
            width: 20%;
            border: 1px solid #dbe6ef;
            padding: 10px;
            vertical-align: top;
        }

        .summary-label {
            font-size: 9px;
            text-transform: uppercase;
            color: #607086;
            margin-bottom: 6px;
        }

        .summary-value {
            font-size: 15px;
            font-weight: 700;
            color: #17324d;
        }

        table.report {
            width: 100%;
            border-collapse: collapse;
        }

        table.report th {
            background: #17324d;
            color: #fff;
            padding: 9px 7px;
            font-size: 10px;
            text-transform: uppercase;
        }

        table.report td {
            border: 1px solid #e3ebf3;
            padding: 9px 7px;
            vertical-align: top;
        }

        .text-right {
            text-align: right;
        }

        .muted {
            color: #607086;
            font-size: 10px;
        }

        .status {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 700;
        }

        .status-sold {
            background: #fee2e2;
            color: #b91c1c;
        }

        .status-available {
            background: #dcfce7;
            color: #15803d;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1 class="title">Purchase Items Report</h1>
        <p class="subtitle">
            Period: {{ $timePeriod }} | Generated: {{ now()->format('d M Y H:i') }}
            @if($search)
                | Search: {{ $search }}
            @endif
            @if($status)
                | Status: {{ ucfirst($status) }}
            @endif
        </p>
    </div>

    <table class="summary">
        <tr>
            <td>
                <div class="summary-label">Items</div>
                <div class="summary-value">{{ $totalItems }}</div>
            </td>
            <td>
                <div class="summary-label">Purchase Cost</div>
                <div class="summary-value">{{ config('constant.currency') }}{{ number_format($totalPurchaseAmount, 2) }}</div>
            </td>
            <td>
                <div class="summary-label">Repairing</div>
                <div class="summary-value">{{ config('constant.currency') }}{{ number_format($totalRepairingAmount, 2) }}</div>
            </td>
            <td>
                <div class="summary-label">Stock Value</div>
                <div class="summary-value">{{ config('constant.currency') }}{{ number_format($totalStockValue, 2) }}</div>
            </td>
            <td>
                <div class="summary-label">Sold / Available</div>
                <div class="summary-value">{{ $soldItems }} / {{ $availableItems }}</div>
            </td>
        </tr>
    </table>

    <table class="report">
        <thead>
            <tr>
                <th>Date</th>
                <th>Device</th>
                <th>Supplier</th>
                <th class="text-right">Costing</th>
                <th>Status</th>
                <th>Remark</th>
            </tr>
        </thead>
        <tbody>
            @foreach($allPurchased as $purchase)
                <tr>
                    <td>
                        {{ \Carbon\Carbon::parse($purchase->purchase_date)->format('d/m/Y') }}
                        @if($purchase->sell_date)
                            <br><span class="muted">Sold: {{ \Carbon\Carbon::parse($purchase->sell_date)->format('d/m/Y') }}</span>
                        @endif
                    </td>
                    <td>
                        <strong>{{ $purchase->model ?: 'Unnamed Device' }}</strong><br>
                        <span class="muted">IMEI: {{ $purchase->imei ?: 'N/A' }}</span><br>
                        <span class="muted">{{ $purchase->storage ?: 'N/A' }} | {{ $purchase->color ?: 'N/A' }}</span>
                    </td>
                    <td>
                        <strong>{{ $purchase->purchase_from ?: 'Unknown Supplier' }}</strong><br>
                        <span class="muted">{{ $purchase->contactno ?: 'N/A' }}</span>
                    </td>
                    <td class="text-right">
                        Buy: {{ config('constant.currency') }}{{ number_format((float) $purchase->purchase_cost, 2) }}<br>
                        Repair: {{ config('constant.currency') }}{{ number_format((float) ($purchase->repairing_charge ?: 0), 2) }}<br>
                        <strong>Value: {{ config('constant.currency') }}{{ number_format((float) $purchase->purchase_price, 2) }}</strong>
                    </td>
                    <td>
                        <span class="status status-{{ $purchase->is_sold ? 'sold' : 'available' }}">
                            {{ $purchase->is_sold ? 'Sold' : 'Available' }}
                        </span>
                    </td>
                    <td>{{ $purchase->remark ?: '-' }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
