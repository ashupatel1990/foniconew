@extends('layout.app')

@section('title')
    Profit & Loss Statement
@endsection

@section('content')
    <style>
        .profit-loss-shell {
            padding: 24px 0 32px;
            background:
                radial-gradient(circle at top left, rgba(26, 188, 156, 0.10), transparent 26%),
                linear-gradient(180deg, #f7fafc 0%, #eef3f8 100%);
            min-height: 100%;
        }

        .profit-loss-hero {
            position: relative;
            overflow: hidden;
            border-radius: 26px;
            padding: 28px 30px;
            margin-bottom: 24px;
            background: linear-gradient(135deg, #163447 0%, #204e65 58%, #1abc9c 100%);
            box-shadow: 0 24px 50px rgba(22, 52, 71, 0.18);
            color: #fff;
        }

        .profit-loss-hero::after {
            content: "";
            position: absolute;
            right: -72px;
            bottom: -96px;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
            pointer-events: none;
            z-index: 0;
        }

        .profit-loss-hero .row {
            position: relative;
            z-index: 1;
        }

        .profit-loss-hero__eyebrow {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.88);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 14px;
        }

        .profit-loss-hero__title {
            color: #fff;
            font-size: 31px;
            line-height: 1.15;
            margin-bottom: 8px;
        }

        .profit-loss-hero__subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 15px;
            max-width: 620px;
            margin-bottom: 0;
        }

        .profit-loss-toolbar {
            display: flex;
            justify-content: flex-end;
            align-items: flex-end;
            gap: 12px;
            flex-wrap: wrap;
        }

        .profit-loss-filter {
            min-width: 220px;
        }

        .profit-loss-filter--date {
            min-width: 170px;
            display: none;
        }

        .profit-loss-filter--date.is-visible {
            display: block;
        }

        .profit-loss-filter label {
            display: block;
            color: rgba(255, 255, 255, 0.72);
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .profit-loss-filter .form-control,
        .profit-loss-toolbar .btn {
            min-height: 46px;
            border-radius: 12px;
            box-shadow: none !important;
        }

        .profit-loss-toolbar .btn-light {
            color: #17324d;
            font-weight: 700;
        }

        .profit-loss-toolbar .btn-outline-light {
            border-color: rgba(255, 255, 255, 0.38);
            color: #fff;
            font-weight: 700;
        }

        .profit-loss-summary {
            border: 0;
            border-radius: 20px;
            box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
            height: 100%;
        }

        .profit-loss-summary .card-body {
            padding: 22px;
        }

        .profit-loss-summary__label {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #7b8798;
            margin-bottom: 10px;
        }

        .profit-loss-summary__value {
            font-size: 24px;
            font-weight: 700;
            line-height: 1.1;
            margin-bottom: 0;
            color: #17324d;
        }

        .profit-loss-summary__meta {
            color: #7b8798;
            font-size: 13px;
            margin-top: 12px;
            margin-bottom: 0;
        }

        .profit-loss-summary--good .profit-loss-summary__value {
            color: #169c82;
        }

        .profit-loss-summary--warn .profit-loss-summary__value {
            color: #b97700;
        }

        .profit-loss-summary--danger .profit-loss-summary__value {
            color: #dc2626;
        }

        .profit-loss-card {
            border: 0;
            border-radius: 24px;
            box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
            overflow: hidden;
            height: 100%;
        }

        .profit-loss-card .card-body {
            padding: 24px;
        }

        .profit-loss-card__eyebrow {
            color: #1abc9c;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 8px;
        }

        .profit-loss-card__title {
            color: #18324b;
            font-size: 22px;
            margin-bottom: 6px;
        }

        .profit-loss-card__subtitle {
            color: #7b8798;
            margin-bottom: 18px;
        }

        .profit-loss-stat {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 0;
            border-bottom: 1px solid #edf2f7;
            gap: 16px;
        }

        .profit-loss-stat:last-child {
            border-bottom: 0;
            padding-bottom: 0;
        }

        .profit-loss-stat:first-child {
            padding-top: 0;
        }

        .profit-loss-stat__label {
            color: #637289;
            font-weight: 600;
        }

        .profit-loss-stat__value {
            color: #18324b;
            font-size: 18px;
            font-weight: 700;
            text-align: right;
        }

        .profit-loss-stat__value.is-positive {
            color: #169c82;
        }

        .profit-loss-stat__value.is-negative {
            color: #dc2626;
        }

        .profit-loss-table {
            margin-bottom: 0;
        }

        .profit-loss-table thead th {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #ebf6ff;
            background: #17324d;
            border-top: 0;
            border-bottom: 0;
            padding: 14px 16px;
            white-space: nowrap;
        }

        .profit-loss-table tbody td {
            padding: 16px;
            vertical-align: top;
            border-color: #edf2f7;
            color: #425466;
        }

        .profit-loss-table tbody tr:hover {
            background: #f9fbfd;
        }

        .profit-loss-amount {
            text-align: right;
            font-size: 16px;
            font-weight: 700;
            color: #18324b;
            white-space: nowrap;
        }

        .profit-loss-empty {
            border: 1px dashed #d7e1ec;
            border-radius: 18px;
            padding: 24px;
            text-align: center;
            color: #7b8798;
            background: #f8fbfd;
        }

        .profit-loss-statement-row {
            display: grid;
            grid-template-columns: 120px 1fr 1fr 1fr 1fr 1fr;
            gap: 12px;
            padding: 12px 0;
            border-bottom: 1px solid #edf2f7;
            font-size: 14px;
        }

        .profit-loss-statement-row:first-child {
            padding-top: 0;
            font-weight: 700;
            background: #f8fbfd;
            padding: 16px 12px;
            border-radius: 8px;
            margin-bottom: 8px;
        }

        .profit-loss-statement-row:last-child {
            border-bottom: 0;
        }

        .profit-loss-statement-cell {
            text-align: right;
        }

        .profit-loss-statement-row:first-child .profit-loss-statement-cell {
            text-align: center;
            color: #637289;
        }

        @media print {
            .profit-loss-no-print {
                display: none !important;
            }

            .profit-loss-shell {
                background: #fff;
                padding: 0;
            }

            .profit-loss-hero,
            .profit-loss-summary,
            .profit-loss-card {
                box-shadow: none !important;
            }
        }

        @media (max-width: 767.98px) {
            .profit-loss-shell {
                padding-top: 18px;
            }

            .profit-loss-hero {
                padding: 24px 22px;
            }

            .profit-loss-hero__title {
                font-size: 26px;
            }

            .profit-loss-toolbar {
                justify-content: stretch;
            }

            .profit-loss-filter {
                width: 100%;
            }

            .profit-loss-statement-row {
                grid-template-columns: 100px 1fr 1fr;
                gap: 8px;
            }
        }
    </style>

    <div class="container-fluid profit-loss-shell">
        <div class="profit-loss-hero">
            <div class="row align-items-center">
                <div class="col-lg-7 mb-3 mb-lg-0">
                    <div class="profit-loss-hero__eyebrow">Reports</div>
                    <h1 class="profit-loss-hero__title">Profit & Loss Statement</h1>
                    <p class="profit-loss-hero__subtitle">
                        Track revenue, expenses, and profitability across your chosen time period.
                    </p>
                </div>
                <div class="col-lg-5">
                    <form method="GET" action="{{ route('profit-loss') }}" class="profit-loss-toolbar profit-loss-no-print">
                        <div class="profit-loss-filter">
                            <label for="timePeriod">Time Period</label>
                            <select name="period" id="timePeriod" class="form-control">
                                <option value="today" {{ request()->get('period') === 'today' ? 'selected' : '' }}>Today</option>
                                <option value="week" {{ request()->get('period') === 'week' ? 'selected' : '' }}>This Week</option>
                                <option value="month" {{ request()->get('period') === 'month' ? 'selected' : '' }}>This Month</option>
                                <option value="quarter" {{ request()->get('period') === 'quarter' ? 'selected' : '' }}>This Quarter</option>
                                <option value="year" {{ request()->get('period') === 'year' ? 'selected' : '' }}>This Year</option>
                                <option value="custom" {{ request()->get('period') === 'custom' ? 'selected' : '' }}>Custom Range</option>
                                <option value="alls" {{ request()->get('period') === 'alls' ? 'selected' : '' }}>All Time</option>
                            </select>
                        </div>
                        <div class="profit-loss-filter profit-loss-filter--date {{ request()->get('period') === 'custom' ? 'is-visible' : '' }}" id="fromDateFilter">
                            <label for="profitLossFromDate">From Date</label>
                            <input type="date" name="fromdate" id="profitLossFromDate" class="form-control" value="{{ $fromdate }}">
                        </div>
                        <div class="profit-loss-filter profit-loss-filter--date {{ request()->get('period') === 'custom' ? 'is-visible' : '' }}" id="toDateFilter">
                            <label for="profitLossToDate">To Date</label>
                            <input type="date" name="todate" id="profitLossToDate" class="form-control" value="{{ $todate }}">
                        </div>
                        <button type="submit" class="btn btn-light">Apply</button>
                        <a href="{{ route('profit-loss') }}" class="btn btn-outline-light">Clear</a>
                        <button type="button" class="btn btn-outline-light" onclick="window.print()">Print</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-xl-4 mb-3">
                <div class="card profit-loss-summary">
                    <div class="card-body">
                        <div class="profit-loss-summary__label">Total Revenue</div>
                        <div class="profit-loss-summary__value">₹{{ number_format($totalRevenue, 2) }}</div>
                        <p class="profit-loss-summary__meta">{{ $invoiceCount }} invoice(s)</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4 mb-3">
                <div class="card profit-loss-summary">
                    <div class="card-body">
                        <div class="profit-loss-summary__label">Gross Profit</div>
                        <div class="profit-loss-summary__value">₹{{ number_format($grossProfit, 2) }}</div>
                        <p class="profit-loss-summary__meta">{{ number_format($grossMargin, 1) }}% of revenue</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xl-4 mb-3">
                <div class="card profit-loss-summary {{ $netProfit >= 0 ? 'profit-loss-summary--good' : 'profit-loss-summary--danger' }}">
                    <div class="card-body">
                        <div class="profit-loss-summary__label">Net Profit</div>
                        <div class="profit-loss-summary__value">₹{{ number_format($netProfit, 2) }}</div>
                        <p class="profit-loss-summary__meta">{{ number_format($netMargin, 1) }}% net margin</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="card profit-loss-card">
                    <div class="card-body">
                        <div class="profit-loss-card__eyebrow">Financial Overview</div>
                        <h2 class="profit-loss-card__title">Profit & Loss Breakdown</h2>
                        <p class="profit-loss-card__subtitle">A complete breakdown of your revenue and expenses for the period.</p>

                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Total Revenue</div>
                            <div class="profit-loss-stat__value">₹{{ number_format($totalRevenue, 2) }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Less: Purchase Cost</div>
                            <div class="profit-loss-stat__value is-negative">₹{{ number_format($purchaseSpend, 2) }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Gross Profit</div>
                            <div class="profit-loss-stat__value is-positive">₹{{ number_format($grossProfit, 2) }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Less: Total Expenses</div>
                            <div class="profit-loss-stat__value is-negative">₹{{ number_format($totalExpenses, 2) }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Net Profit</div>
                            <div class="profit-loss-stat__value {{ $netProfit >= 0 ? 'is-positive' : 'is-negative' }}">₹{{ number_format($netProfit, 2) }}</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 mb-4">
                <div class="card profit-loss-card">
                    <div class="card-body">
                        <div class="profit-loss-card__eyebrow">Metrics</div>
                        <h2 class="profit-loss-card__title">Key Performance Indicators</h2>
                        <p class="profit-loss-card__subtitle">View profitability ratios and efficiency metrics.</p>

                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Gross Margin</div>
                            <div class="profit-loss-stat__value">{{ number_format($grossMargin, 2) }}%</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Net Margin</div>
                            <div class="profit-loss-stat__value {{ $netMargin >= 0 ? 'is-positive' : 'is-negative' }}">{{ number_format($netMargin, 2) }}%</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Total Invoices</div>
                            <div class="profit-loss-stat__value">{{ $invoiceCount }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Total Expenses</div>
                            <div class="profit-loss-stat__value">{{ $expenseCount }}</div>
                        </div>
                        <div class="profit-loss-stat">
                            <div class="profit-loss-stat__label">Total Purchases</div>
                            <div class="profit-loss-stat__value">{{ $purchaseCount }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @if($expenseBreakdown->isNotEmpty())
            <div class="row">
                <div class="col-lg-6 mb-4">
                    <div class="card profit-loss-card">
                        <div class="card-body">
                            <div class="profit-loss-card__eyebrow">Expenses</div>
                            <h2 class="profit-loss-card__title">Top Expense Categories</h2>
                            <p class="profit-loss-card__subtitle">Your largest expense categories during this period.</p>

                            @foreach($expenseBreakdown as $expense)
                                <div class="profit-loss-stat">
                                    <div>
                                        <div class="profit-loss-stat__label text-dark">{{ $expense['label'] }}</div>
                                        <small class="text-muted">{{ $expense['count'] }} transaction(s)</small>
                                    </div>
                                    <div class="profit-loss-stat__value is-negative">₹{{ number_format($expense['amount'], 2) }}</div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 mb-4">
                    <div class="card profit-loss-card">
                        <div class="card-body">
                            <div class="profit-loss-card__eyebrow">Summary</div>
                            <h2 class="profit-loss-card__title">Period Summary</h2>
                            <p class="profit-loss-card__subtitle">Report period: {{ $timePeriod }}</p>

                            <div class="profit-loss-stat">
                                <div class="profit-loss-stat__label">Revenue per Invoice</div>
                                <div class="profit-loss-stat__value">₹{{ number_format($invoiceCount > 0 ? $totalRevenue / $invoiceCount : 0, 2) }}</div>
                            </div>
                            <div class="profit-loss-stat">
                                <div class="profit-loss-stat__label">Profit per Invoice</div>
                                <div class="profit-loss-stat__value is-positive">₹{{ number_format($invoiceCount > 0 ? $grossProfit / $invoiceCount : 0, 2) }}</div>
                            </div>
                            <div class="profit-loss-stat">
                                <div class="profit-loss-stat__label">Average Expense</div>
                                <div class="profit-loss-stat__value is-negative">₹{{ number_format($expenseCount > 0 ? $totalExpenses / $expenseCount : 0, 2) }}</div>
                            </div>
                            <div class="profit-loss-stat">
                                <div class="profit-loss-stat__label">Period Net Profit</div>
                                <div class="profit-loss-stat__value {{ $netProfit >= 0 ? 'is-positive' : 'is-negative' }}">₹{{ number_format($netProfit, 2) }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        @if($statementRows->isNotEmpty())
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="card profit-loss-card">
                        <div class="card-body">
                            <div class="profit-loss-card__eyebrow">Details</div>
                            <h2 class="profit-loss-card__title">Period-wise Statement</h2>
                            <p class="profit-loss-card__subtitle">Revenue, expenses, and profit breakdown by {{ $timePeriod }}.</p>

                            <div class="table-responsive">
                                <div class="profit-loss-statement-row">
                                    <div class="profit-loss-statement-cell"><strong>Period</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Revenue</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Gross Profit</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Expenses</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Purchase Cost</strong></div>
                                    <div class="profit-loss-statement-cell"><strong>Net Profit</strong></div>
                                </div>

                                @foreach($statementRows as $row)
                                    <div class="profit-loss-statement-row">
                                        <div class="profit-loss-statement-cell">{{ $row['label'] }}</div>
                                        <div class="profit-loss-statement-cell">₹{{ number_format($row['revenue'], 2) }}</div>
                                        <div class="profit-loss-statement-cell">₹{{ number_format($row['gross_profit'], 2) }}</div>
                                        <div class="profit-loss-statement-cell">₹{{ number_format($row['expenses'], 2) }}</div>
                                        <div class="profit-loss-statement-cell">₹{{ number_format($row['purchase_spend'], 2) }}</div>
                                        <div class="profit-loss-statement-cell {{ $row['net_profit'] >= 0 ? 'text-success' : 'text-danger' }}">₹{{ number_format($row['net_profit'], 2) }}</div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    </div>

    <script>
        (function () {
            const periodSelect = document.getElementById('timePeriod');
            const fromDateFilter = document.getElementById('fromDateFilter');
            const toDateFilter = document.getElementById('toDateFilter');

            function toggleCustomDateFilters() {
                const isCustom = periodSelect && periodSelect.value === 'custom';

                if (fromDateFilter) {
                    fromDateFilter.classList.toggle('is-visible', isCustom);
                }

                if (toDateFilter) {
                    toDateFilter.classList.toggle('is-visible', isCustom);
                }
            }

            if (periodSelect) {
                periodSelect.addEventListener('change', toggleCustomDateFilters);
                toggleCustomDateFilters();
            }
        })();
    </script>
@endsection
