@extends('layout.app')

@section('title', 'Ledger Entries')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2>Ledger Entries</h2>
                <a href="{{ route('ledger.create') }}" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New Entry
                </a>
            </div>
        </div>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="mb-4">
        <h4 class="mb-3">Transaction Management</h4>
        <div class="ledger-summary-grid">
            <div class="ledger-summary-card ledger-summary-purple">
                <h6>Total Balance</h6>
                <p id="summary-total-balance">₹ {{ number_format($summary['total_balance'] ?? 0, 2) }}</p>
            </div>
            <div class="ledger-summary-card ledger-summary-blue">
                <h6>Cash Balance</h6>
                <p id="summary-cash-balance">₹ {{ number_format($summary['cash_balance'] ?? 0, 2) }}</p>
            </div>
            <div class="ledger-summary-card ledger-summary-cyan">
                <h6>Bank Balance</h6>
                <p id="summary-bank-balance">₹ {{ number_format($summary['bank_balance'] ?? 0, 2) }}</p>
            </div>
            <div class="ledger-summary-card ledger-summary-green">
                <h6>Total In</h6>
                <p id="summary-total-in">₹ {{ number_format($summary['total_in'] ?? 0, 2) }}</p>
            </div>
            <div class="ledger-summary-card ledger-summary-red">
                <h6>Total Out</h6>
                <p id="summary-total-out">₹ {{ number_format($summary['total_out'] ?? 0, 2) }}</p>
            </div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="card mb-4">
        <div class="card-header">
            <h5>Filters</h5>
        </div>
        <div class="card-body">
            <form class="row g-3" id="filter-form">
                <div class="col-md-3">
                    <label for="date_from" class="form-label">From Date</label>
                    <input type="date" class="form-control" id="date_from" name="date_from" 
                           value="{{ request('date_from') }}">
                </div>
                <div class="col-md-3">
                    <label for="date_to" class="form-label">To Date</label>
                    <input type="date" class="form-control" id="date_to" name="date_to"
                           value="{{ request('date_to') }}">
                </div>
                <div class="col-md-3">
                    <label for="party_id" class="form-label">Party</label>
                    <select class="form-control" id="party_id" name="party_id">
                        <option value="">-- All Parties --</option>
                        @foreach ($parties as $party)
                            <option value="{{ $party->id }}" {{ request('party_id') == $party->id ? 'selected' : '' }}>
                                {{ $party->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="entry_type" class="form-label">Entry Type</label>
                    <select class="form-control" id="entry_type" name="entry_type">
                        <option value="">-- All Types --</option>
                        <option value="SALE" {{ request('entry_type') == 'SALE' ? 'selected' : '' }}>Sale</option>
                        <option value="PURCHASE" {{ request('entry_type') == 'PURCHASE' ? 'selected' : '' }}>Purchase</option>
                        <option value="EXPENSE" {{ request('entry_type') == 'EXPENSE' ? 'selected' : '' }}>Expense</option>
                        <option value="PAYMENT" {{ request('entry_type') == 'PAYMENT' ? 'selected' : '' }}>Payment</option>
                        <option value="RECEIPT" {{ request('entry_type') == 'RECEIPT' ? 'selected' : '' }}>Receipt</option>
                    </select>
                </div>
                <div class="col-md-12 mt-3">
                    <button type="button" class="btn btn-info" id="filter-btn">
                        <i class="fas fa-filter"></i> Apply Filters
                    </button>
                    <button type="button" class="btn btn-secondary" id="reset-btn">
                        <i class="fas fa-redo"></i> Reset
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Data Table -->
    <div class="card">
        <div class="card-header">
            <h5>Ledger Entries List</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table id="ledger-table" class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Party</th>
                            <th>Type</th>
                            <th>Debit (₹)</th>
                            <th>Credit (₹)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete Entry</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this ledger entry?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirm-delete">Delete</button>
            </div>
        </div>
    </div>
</div>

@endsection

@section('css')
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<style>
    .ledger-summary-grid {
        display: grid;
        grid-template-columns: repeat(5, minmax(0, 1fr));
        gap: 1.25rem;
        margin-bottom: 1.75rem;
    }

    .ledger-summary-card {
        border-radius: 8px;
        color: #fff;
        padding: 1rem 1.25rem;
        text-align: center;
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.12);
    }

    .ledger-summary-card h6 {
        margin-bottom: 0.85rem;
        color: #fff;
        font-size: 1.05rem;
        font-weight: 700;
        text-transform: uppercase;
    }

    .ledger-summary-card p {
        margin: 0;
        font-size: 1.45rem;
        font-weight: 700;
        color: #fff;
    }

    .ledger-summary-purple { background: linear-gradient(135deg, #6f42c1, #7b4acb); }
    .ledger-summary-blue { background: linear-gradient(135deg, #0d6efd, #1d7ff0); }
    .ledger-summary-cyan { background: linear-gradient(135deg, #17a2b8, #2ca7bd); }
    .ledger-summary-green { background: linear-gradient(135deg, #28a745, #32b44a); }
    .ledger-summary-red { background: linear-gradient(135deg, #dc3545, #e23a4a); }

    @media (max-width: 991.98px) {
        .ledger-summary-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }

    @media (max-width: 575.98px) {
        .ledger-summary-grid {
            grid-template-columns: 1fr;
        }
    }
</style>
@endsection

@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
$(document).ready(function() {
    function formatCurrency(amount) {
        return '₹ ' + Number(amount || 0).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function updateSummary(summary) {
        if (!summary) {
            return;
        }

        $('#summary-total-balance').text(formatCurrency(summary.total_balance));
        $('#summary-cash-balance').text(formatCurrency(summary.cash_balance));
        $('#summary-bank-balance').text(formatCurrency(summary.bank_balance));
        $('#summary-total-in').text(formatCurrency(summary.total_in));
        $('#summary-total-out').text(formatCurrency(summary.total_out));
    }

    let table = $('#ledger-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "{{ route('ledger.index') }}",
            data: function(d) {
                d.date_from = $('#date_from').val();
                d.date_to = $('#date_to').val();
                d.party_id = $('#party_id').val();
                d.entry_type = $('#entry_type').val();
            },
            dataSrc: function(json) {
                updateSummary(json.summary);
                return json.data;
            }
        },
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex' },
            { data: 'entry_date', name: 'entry_date' },
            { data: 'party_name', name: 'party_name' },
            { data: 'entry_type', name: 'entry_type' },
            { data: 'debit_display', name: 'debit_display' },
            { data: 'credit_display', name: 'credit_display' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ]
    });

    $('#filter-btn').click(function() {
        table.draw();
    });

    $('#reset-btn').click(function() {
        $('#date_from').val('');
        $('#date_to').val('');
        $('#party_id').val('');
        $('#entry_type').val('');
        table.draw();
    });

    let deleteId = null;
    $(document).on('click', '.delete-btn', function() {
        deleteId = $(this).data('id');
        new bootstrap.Modal(document.getElementById('deleteModal')).show();
    });

    $('#confirm-delete').click(function() {
        $.ajax({
            url: '/admin/ledger/' + deleteId,
            type: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                bootstrap.Modal.getInstance(document.getElementById('deleteModal')).hide();
                table.draw();
                alert('Entry deleted successfully');
            },
            error: function(error) {
                alert('Error deleting entry');
            }
        });
    });
});
</script>
@endsection
