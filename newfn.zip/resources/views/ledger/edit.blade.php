@extends('layout.app')

@section('title', 'Edit Ledger Entry')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <h2>Edit Ledger Entry</h2>
        </div>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5>Entry Details</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('ledger.update', $entry->id) }}" id="entry-form">
                        @csrf
                        @method('PUT')

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="party_id" class="form-label">Party <span class="text-danger">*</span></label>
                                <select name="party_id" id="party_id" class="form-control @error('party_id') is-invalid @enderror" required>
                                    <option value="">-- Select Party --</option>
                                    @foreach ($parties as $party)
                                        <option value="{{ $party->id }}" {{ $entry->party_id == $party->id ? 'selected' : '' }}>
                                            {{ $party->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('party_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-6">
                                <label for="entry_date" class="form-label">Entry Date <span class="text-danger">*</span></label>
                                <input type="date" name="entry_date" id="entry_date" 
                                       class="form-control @error('entry_date') is-invalid @enderror"
                                       value="{{ $entry->entry_date->toDateString() }}" required>
                                @error('entry_date')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="entry_type" class="form-label">Entry Type <span class="text-danger">*</span></label>
                                <select name="entry_type" id="entry_type" class="form-control @error('entry_type') is-invalid @enderror" required>
                                    <option value="">-- Select Type --</option>
                                    <option value="SALE" {{ $entry->entry_type == 'SALE' ? 'selected' : '' }}>Sale</option>
                                    <option value="PURCHASE" {{ $entry->entry_type == 'PURCHASE' ? 'selected' : '' }}>Purchase</option>
                                    <option value="EXPENSE" {{ $entry->entry_type == 'EXPENSE' ? 'selected' : '' }}>Expense</option>
                                    <option value="PAYMENT" {{ $entry->entry_type == 'PAYMENT' ? 'selected' : '' }}>Payment</option>
                                    <option value="RECEIPT" {{ $entry->entry_type == 'RECEIPT' ? 'selected' : '' }}>Receipt</option>
                                    <option value="TRANSFER" {{ $entry->entry_type == 'TRANSFER' ? 'selected' : '' }}>Transfer</option>
                                    <option value="OPENING_BALANCE" {{ $entry->entry_type == 'OPENING_BALANCE' ? 'selected' : '' }}>Opening Balance</option>
                                </select>
                                @error('entry_type')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-6">
                                <label for="payment_method_id" class="form-label">Payment Method <span class="text-danger">*</span></label>
                                <select name="payment_method_id" id="payment_method_id" class="form-control @error('payment_method_id') is-invalid @enderror" required>
                                    <option value="">-- Select Method --</option>
                                    @foreach ($paymentMethods as $method)
                                        <option value="{{ $method->id }}" {{ $entry->payment_method_id == $method->id ? 'selected' : '' }}>
                                            {{ $method->method_name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('payment_method_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="debit_amount" class="form-label">Debit Amount (₹)</label>
                                <input type="number" name="debit_amount" id="debit_amount" step="0.01" min="0"
                                       class="form-control @error('debit_amount') is-invalid @enderror"
                                       value="{{ $entry->debit_amount }}">
                                @error('debit_amount')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-6">
                                <label for="credit_amount" class="form-label">Credit Amount (₹)</label>
                                <input type="number" name="credit_amount" id="credit_amount" step="0.01" min="0"
                                       class="form-control @error('credit_amount') is-invalid @enderror"
                                       value="{{ $entry->credit_amount }}">
                                @error('credit_amount')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="reference_number" class="form-label">Reference Number</label>
                                <input type="text" name="reference_number" id="reference_number"
                                       class="form-control @error('reference_number') is-invalid @enderror"
                                       value="{{ $entry->reference_number }}" placeholder="e.g., CHQ123, TRN456">
                                @error('reference_number')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="description" class="form-label">Description</label>
                                <input type="text" name="description" id="description"
                                       class="form-control @error('description') is-invalid @enderror"
                                       value="{{ $entry->description }}" placeholder="Brief description of the transaction">
                                @error('description')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea name="notes" id="notes" rows="3"
                                          class="form-control @error('notes') is-invalid @enderror"
                                          placeholder="Additional notes">{{ $entry->notes }}</textarea>
                                @error('notes')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Entry
                                </button>
                                <a href="{{ route('ledger.index') }}" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancel
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <!-- Info Card -->
            <div class="card mb-3">
                <div class="card-header">
                    <h5>Entry Information</h5>
                </div>
                <div class="card-body">
                    <p><strong>ID:</strong> {{ $entry->id }}</p>
                    <p><strong>Status:</strong> 
                        @if ($entry->is_reconciled)
                            <span class="badge badge-success">Reconciled</span>
                        @else
                            <span class="badge badge-warning">Pending</span>
                        @endif
                    </p>
                    <p><strong>Created By:</strong> {{ $entry->createdBy->name ?? 'System' }}</p>
                    <p><strong>Created At:</strong> {{ $entry->created_at->format('M d, Y H:i') }}</p>
                    <p><strong>Updated At:</strong> {{ $entry->updated_at->format('M d, Y H:i') }}</p>
                </div>
            </div>

            <!-- Audit Trail -->
            @if (count($auditLogs) > 0)
                <div class="card">
                    <div class="card-header">
                        <h5>Recent Changes</h5>
                    </div>
                    <div class="card-body">
                        <div class="audit-list">
                            @foreach ($auditLogs as $log)
                                <div class="mb-2 pb-2 border-bottom">
                                    <p class="mb-1"><small><strong>{{ ucfirst(strtolower($log->action)) }}</strong></small></p>
                                    <p class="mb-1"><small>By: {{ $log->user->name ?? 'System' }}</small></p>
                                    <p class="mb-0"><small class="text-muted">{{ $log->created_at->format('M d, Y H:i') }}</small></p>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>

@endsection

@section('scripts')
<script>
$(document).ready(function() {
    // Prevent entering both debit and credit
    $('#debit_amount').on('change', function() {
        if (parseFloat($(this).val()) > 0) {
            $('#credit_amount').val(0);
        }
    });

    $('#credit_amount').on('change', function() {
        if (parseFloat($(this).val()) > 0) {
            $('#debit_amount').val(0);
        }
    });

    // Form validation
    $('#entry-form').on('submit', function() {
        let debit = parseFloat($('#debit_amount').val() || 0);
        let credit = parseFloat($('#credit_amount').val() || 0);

        if (debit > 0 && credit > 0) {
            alert('Cannot enter both debit and credit amounts');
            return false;
        }

        if (debit <= 0 && credit <= 0) {
            alert('Please enter either debit or credit amount');
            return false;
        }

        return true;
    });
});
</script>
@endsection
