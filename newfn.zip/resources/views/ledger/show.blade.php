@extends('layout.app')

@section('title', 'Ledger Entry Details')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <h2>Ledger Entry #{{ $entry->id }}</h2>
                <div>
                    <a href="{{ route('ledger.edit', $entry->id) }}" class="btn btn-primary">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="{{ route('ledger.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <!-- Entry Details Card -->
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Transaction Details</h5>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label text-muted">Party</label>
                            <p class="h6">{{ $entry->party->name }}</p>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted">Entry Date</label>
                            <p class="h6">{{ $entry->entry_date->format('M d, Y') }}</p>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label text-muted">Entry Type</label>
                            <p>
                                <span class="badge badge-info">{{ $entry->entry_type }}</span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted">Payment Method</label>
                            <p class="h6">{{ $entry->paymentMethod->method_name }}</p>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label text-muted">Debit Amount</label>
                            <p class="h5 text-danger">
                                {{ $entry->debit_amount > 0 ? '₹' . number_format($entry->debit_amount, 2) : '—' }}
                            </p>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label text-muted">Credit Amount</label>
                            <p class="h5 text-success">
                                {{ $entry->credit_amount > 0 ? '₹' . number_format($entry->credit_amount, 2) : '—' }}
                            </p>
                        </div>
                    </div>

                    <hr class="my-4">

                    @if ($entry->reference_number)
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="form-label text-muted">Reference Number</label>
                                <p class="h6">{{ $entry->reference_number }}</p>
                            </div>
                        </div>
                    @endif

                    @if ($entry->description)
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="form-label text-muted">Description</label>
                                <p>{{ $entry->description }}</p>
                            </div>
                        </div>
                    @endif

                    @if ($entry->notes)
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label class="form-label text-muted">Notes</label>
                                <p>{{ $entry->notes }}</p>
                            </div>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Reconciliation Card -->
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Reconciliation Status</h5>
                        @if ($entry->is_reconciled)
                            <span class="badge badge-success">Reconciled</span>
                        @else
                            <span class="badge badge-warning">Pending</span>
                        @endif
                    </div>
                </div>
                <div class="card-body">
                    @if ($entry->is_reconciled)
                        <div class="alert alert-success" role="alert">
                            <i class="fas fa-check-circle"></i> This entry has been reconciled.
                        </div>
                        @if ($entry->reconciliation_date)
                            <p class="mb-0">
                                <strong>Reconciled on:</strong> {{ $entry->reconciliation_date->format('M d, Y H:i') }}
                            </p>
                        @endif
                    @else
                        <div class="alert alert-info" role="alert">
                            <i class="fas fa-exclamation-circle"></i> This entry is pending reconciliation.
                        </div>
                        <form action="{{ route('ledger.reconcile', $entry->id) }}" method="POST" style="display:inline;">
                            @csrf
                            <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Mark this entry as reconciled?');">
                                <i class="fas fa-check"></i> Mark as Reconciled
                            </button>
                        </form>
                    @endif
                </div>
            </div>

            <!-- Audit Trail Card -->
            @if (count($auditLogs) > 0)
                <div class="card">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Audit Trail</h5>
                    </div>
                    <div class="card-body">
                        <div class="timeline">
                            @foreach ($auditLogs as $index => $log)
                                <div class="timeline-item">
                                    <div class="timeline-marker 
                                        @if ($log->action === 'CREATE') bg-success
                                        @elseif ($log->action === 'UPDATE') bg-info
                                        @else bg-danger
                                        @endif">
                                        <i class="fas 
                                            @if ($log->action === 'CREATE') fa-plus
                                            @elseif ($log->action === 'UPDATE') fa-pencil-alt
                                            @else fa-trash
                                            @endif"></i>
                                    </div>
                                    <div class="timeline-content">
                                        <h6 class="mb-1">{{ ucfirst(strtolower($log->action)) }}</h6>
                                        <p class="mb-1 text-muted small">
                                            By {{ $log->user->name ?? 'System' }} 
                                            • {{ $log->created_at->format('M d, Y H:i:s') }}
                                        </p>
                                        @if ($log->old_values || $log->new_values)
                                            <details class="mt-2">
                                                <summary class="cursor-pointer text-primary small">View details</summary>
                                                <div class="mt-2 bg-light p-2 rounded">
                                                    @if ($log->old_values)
                                                        <p class="mb-2"><strong>Previous Values:</strong></p>
                                                        <table class="table table-sm table-bordered mb-2">
                                                            @foreach ($log->old_values as $field => $value)
                                                                <tr>
                                                                    <td class="w-25"><small>{{ $field }}</small></td>
                                                                    <td><small>{{ $value }}</small></td>
                                                                </tr>
                                                            @endforeach
                                                        </table>
                                                    @endif
                                                    @if ($log->new_values)
                                                        <p class="mb-2"><strong>New Values:</strong></p>
                                                        <table class="table table-sm table-bordered">
                                                            @foreach ($log->new_values as $field => $value)
                                                                <tr>
                                                                    <td class="w-25"><small>{{ $field }}</small></td>
                                                                    <td><small>{{ $value }}</small></td>
                                                                </tr>
                                                            @endforeach
                                                        </table>
                                                    @endif
                                                </div>
                                            </details>
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif
        </div>

        <div class="col-md-4">
            <!-- Status Card -->
            <div class="card mb-3">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Entry Status</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label text-muted">Status</label>
                        <p>
                            @if ($entry->is_reconciled)
                                <span class="badge badge-success badge-lg">Reconciled</span>
                            @else
                                <span class="badge badge-warning badge-lg">Pending</span>
                            @endif
                        </p>
                    </div>

                    <hr class="my-3">

                    <div class="mb-3">
                        <label class="form-label text-muted">Entry ID</label>
                        <p class="h6">{{ $entry->id }}</p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted">Created By</label>
                        <p class="h6">{{ $entry->createdBy->name ?? 'System' }}</p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted">Created At</label>
                        <p class="h6">{{ $entry->created_at->format('M d, Y H:i:s') }}</p>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted">Last Updated</label>
                        <p class="h6">{{ $entry->updated_at->format('M d, Y H:i:s') }}</p>
                    </div>

                    @if ($entry->deleted_at)
                        <div class="alert alert-danger">
                            <strong>Deleted:</strong> {{ $entry->deleted_at->format('M d, Y H:i:s') }}
                        </div>
                    @endif
                </div>
            </div>

            <!-- Party Information -->
            <div class="card mb-3">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Party Information</h5>
                </div>
                <div class="card-body">
                    <p class="mb-2">
                        <strong>{{ $entry->party->name }}</strong>
                    </p>
                    @if ($entry->party->email)
                        <p class="mb-2">
                            <i class="fas fa-envelope"></i> {{ $entry->party->email }}
                        </p>
                    @endif
                    @if ($entry->party->phone)
                        <p class="mb-2">
                            <i class="fas fa-phone"></i> {{ $entry->party->phone }}
                        </p>
                    @endif
                   
                </div>
            </div>

            <!-- Summary Card -->
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Transaction Summary</h5>
                </div>
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-6">
                            <small class="text-muted">Debit:</small>
                        </div>
                        <div class="col-6 text-right">
                            <strong class="text-danger">
                                {{ $entry->debit_amount > 0 ? '₹' . number_format($entry->debit_amount, 2) : '—' }}
                            </strong>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <small class="text-muted">Credit:</small>
                        </div>
                        <div class="col-6 text-right">
                            <strong class="text-success">
                                {{ $entry->credit_amount > 0 ? '₹' . number_format($entry->credit_amount, 2) : '—' }}
                            </strong>
                        </div>
                    </div>
                    <hr class="my-2">
                    <div class="row">
                        <div class="col-6">
                            <small class="text-muted">Net Amount:</small>
                        </div>
                        <div class="col-6 text-right">
                            <strong>
                                ₹{{ number_format(abs($entry->debit_amount - $entry->credit_amount), 2) }}
                                @if ($entry->debit_amount > $entry->credit_amount)
                                    <small class="text-danger">(Debit)</small>
                                @else
                                    <small class="text-success">(Credit)</small>
                                @endif
                            </strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.timeline {
    position: relative;
    padding: 20px 0;
}

.timeline-item {
    display: flex;
    margin-bottom: 30px;
    position: relative;
}

.timeline-item:last-child::before {
    display: none;
}

.timeline-item::before {
    content: '';
    position: absolute;
    left: 19px;
    top: 50px;
    bottom: -30px;
    width: 2px;
    background: #dee2e6;
}

.timeline-marker {
    width: 40px;
    height: 40px;
    background: #007bff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    margin-right: 20px;
    flex-shrink: 0;
    font-size: 16px;
}

.timeline-content {
    flex: 1;
    padding-bottom: 20px;
}

.cursor-pointer {
    cursor: pointer;
    text-decoration: underline;
}

.cursor-pointer:hover {
    color: #0056b3 !important;
}
</style>
@endsection
