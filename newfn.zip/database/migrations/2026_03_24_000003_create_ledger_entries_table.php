<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ledger_entries', function (Blueprint $table) {
            $table->id();
            $table->date('entry_date')->index();
            $table->enum('entry_type', [
                'SALE', 'PURCHASE', 'EXPENSE', 'PAYMENT',
                'RECEIPT', 'TRANSFER', 'OPENING_BALANCE'
            ]);
            $table->bigInteger('transaction_id')->nullable();
            $table->foreignId('party_id')->constrained()->onDelete('cascade');
            $table->foreignId('created_by')->constrained('users')->onDelete('restrict');
            $table->decimal('debit_amount', 15, 2)->default(0);
            $table->decimal('credit_amount', 15, 2)->default(0);
            $table->foreignId('payment_method_id')->nullable()->constrained()->onDelete('set null');
            $table->string('reference_number')->nullable();
            $table->text('description')->nullable();
            $table->text('notes')->nullable();
            $table->string('attachment_url')->nullable();
            $table->boolean('is_reconciled')->default(false);
            $table->timestamp('reconciliation_date')->nullable();
            $table->timestamps();
            $table->softDeletes();

            // Indexes for performance
            $table->index(['entry_date', 'party_id']);
            $table->index('created_by');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ledger_entries');
    }
};
