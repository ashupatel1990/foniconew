<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('reconciliations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('account_id')->constrained('cash_bank_ledgers')->onDelete('cascade');
            $table->date('reconciliation_date');
            $table->date('statement_date');
            $table->decimal('statement_balance', 15, 2);
            $table->decimal('system_balance', 15, 2);
            $table->decimal('difference', 15, 2)->default(0);
            $table->enum('reconciliation_status', ['PENDING', 'PARTIAL', 'COMPLETE'])->default('PENDING');
            $table->text('notes')->nullable();
            $table->foreignId('cleared_by_id')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamps();

            $table->index(['account_id', 'reconciliation_date']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reconciliations');
    }
};
