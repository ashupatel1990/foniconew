<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('recurring_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('party_id')->constrained()->onDelete('cascade');
            $table->enum('frequency', ['DAILY', 'WEEKLY', 'MONTHLY', 'QUARTERLY', 'YEARLY']);
            $table->date('start_date');
            $table->date('end_date')->nullable();
            $table->decimal('amount', 15, 2);
            $table->enum('transaction_type', ['CREDIT', 'DEBIT']);
            $table->text('description')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->date('next_due_date');
            $table->timestamps();

            $table->index(['is_active', 'next_due_date']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('recurring_transactions');
    }
};
